# Organização do frontend

O servidor entrega somente o conteúdo de `public/`. A API permanece em `api/`, e o `.env` continua na raiz do projeto.

```text
public/
  index.html, login.html, senha-temporaria.html
  admin.html, eng.html, tec.html
  imagem/                 Imagens usadas pelas páginas
  css/
    base/                 Estilos globais
    components/           Dashboard, formulários, calendário e navegação
    pages/                Estilos específicos de cada página
    vendor/               CSS de bibliotecas externas
  js/
    core/                 Autenticação/API e utilitários de apresentação
    components/           Calendários e comportamento visual compartilhado
    features/             Talhões, mapas, colheitas, relatórios e chatbot
    pages/
      inicio/             Entrada e redirecionamento inicial
      login/              Formulário de autenticação
      senha-temporaria/   Troca da senha provisória
      admin/              Cadastro, operação de campo, mapa e telemetria
      eng/                Mapa, geometria, plantio e telemetria
      tec/                Mapa, registros de campo e telemetria
    vendor/               Bibliotecas externas e respectivas licenças
tests/
  frontend.spec.js        Testes de navegação e integração dos módulos
```

Nos três painéis, `index.js` configura os eventos e inicia o carregamento. `estado.js` mantém os dados exclusivos do painel. Os outros módulos exportam funções por responsabilidade e declaram suas dependências com `import`. O editor de mapa do administrador importa a renderização do mapa diretamente.

`core/dom.js` concentra os utilitários de texto e escape de HTML usados pelos painéis. Os componentes e recursos compartilhados existentes continuam como scripts clássicos; carregue `core/auth.js` antes dos recursos que usam `FrutLog`, e `features/talhoes.js` antes de `features/mapa-talhoes.js`. Os módulos dos painéis são carregados com `type="module"`, após essas dependências.

Para acrescentar uma funcionalidade, coloque a lógica no módulo correspondente e conecte seus eventos no `index.js` do painel. Evite criar funções globais ou repetir estado entre arquivos. Estilos de uma única página ficam em `css/pages/`; estilos reutilizáveis ficam em `css/components/`.

## Executar

Na raiz do projeto:

```powershell
npm.cmd install
npm.cmd start
```

Abra `http://localhost:3000`. Os endereços continuam sendo `/login.html`, `/admin.html`, `/eng.html` e `/tec.html`. Não inclua `/public` na URL. O frontend deve ser acessado pelo servidor Node para usar a API em `/api`.

## Validar

```powershell
npm.cmd test
```

Os testes iniciam e encerram um servidor próprio na porta 4317 e usam Chrome em modo headless. Para usar o Chromium do Playwright:

```powershell
npx.cmd playwright install chromium
$env:PLAYWRIGHT_CHANNEL = "chromium"
npm.cmd test
```

Os testes simulam a API e os serviços externos. Verificam os arquivos das páginas, a integração dos módulos, a seleção de talhões, os controles de senha e o editor de mapa, sem consultar ou modificar o banco real. Não validam as credenciais do `.env`, a conexão ao Supabase nem a renderização das bibliotecas de gráficos externas.
