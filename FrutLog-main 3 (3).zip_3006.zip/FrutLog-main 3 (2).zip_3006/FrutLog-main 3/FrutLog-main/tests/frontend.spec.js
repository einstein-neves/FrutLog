﻿const { test, expect } = require("@playwright/test");

const talhao = {
  id: "1",
  codigo: "T1",
  nome: "Talhão de teste",
  area_hectares: 2,
  coordenadas: [
    [20, 20],
    [180, 20],
    [180, 180],
    [20, 180],
    [20, 20],
  ],
};
const painel = {
  talhoes: [{ id: "T1", situacao: "Normal", area: "2 hectares" }],
  sensores: [],
  plantios: [],
  inspecoes: [],
  ocorrencias: [],
  problemasSensores: [],
  tarefas: [],
  alertas: [],
};

async function preparar(page, perfil) {
  const erros = [];
  page.on("pageerror", (e) => erros.push(e.message));
  page.on("response", (r) => {
    if (r.url().startsWith("http://127.0.0.1:4317/") && r.status() >= 400)
      erros.push(`${r.status()} ${r.url()}`);
  });
  await page.route("**/*", async (route) => {
    const url = new URL(route.request().url());
    if (url.origin !== "http://127.0.0.1:4317") {
      // External dashboards and CDNs are independent of the local module graph.
      if (url.hostname === "cdn.jsdelivr.net")
        return route.fulfill({
          contentType: "application/javascript",
          body: "window.Chart = class { constructor(canvas, options) { this.data = options.data; } destroy() {} update() {} };",
        });
      return route.fulfill({ body: "", contentType: "text/plain" });
    }
    if (!url.pathname.startsWith("/api/")) return route.continue();
    const respostas = {
      "/api/talhoes": { talhoes: [talhao] },
      "/api/painel-engenheiro": painel,
      "/api/painel-tecnico": painel,
      "/api/funcionarios": { usuarios: [] },
      "/api/sensores": { sensores: [] },
      "/api/colheitas/anual": { colheitas: [] },
      "/api/telemetria/diaria": {
        leituras: [],
        mensal: [],
        desde: "2026-01-01",
      },
      "/api/telemetria/esp32-mensal": { mensal: [] },
      "/api/telemetria/thingspeak": { feeds: [] },
      "/api/relatorios-diarios": { relatorios: [] },
    };
    return route.fulfill({
      json: respostas[url.pathname] || { sucesso: true },
    });
  });
  if (perfil)
    await page.addInitScript((perfil) => {
      sessionStorage.setItem(
        "frutlog_sessao",
        JSON.stringify({ id: 1, matricula: "teste", nome: "Teste", perfil }),
      );
      sessionStorage.setItem("frutlog_token", "token-de-teste");
    }, perfil);
  return erros;
}

for (const [pagina, perfil] of [
  ["login.html", null],
  ["admin.html", "admin"],
  ["eng.html", "engenheiro"],
  ["tec.html", "tecnico"],
  ["senha-temporaria.html", "admin"],
]) {
  test(`carrega ${pagina} e seus arquivos`, async ({ page }) => {
    const erros = await preparar(page, perfil);
    await page.goto(`/${pagina}`, { waitUntil: "networkidle" });
    await expect(page).toHaveURL(new RegExp(`${pagina}$`));
    if (
      ["admin", "engenheiro", "tecnico"].includes(perfil) &&
      pagina !== "senha-temporaria.html"
    ) {
      await expect(page.locator('svg polygon[data-talhao="T1"]')).toHaveCount(
        1,
      );
      if (perfil === "admin")
        await page.locator('.menu a[href="#mapa-fazenda"]').click();
      await page.locator('svg polygon[data-talhao="T1"]').click();
      const modulo =
        perfil === "engenheiro"
          ? "eng"
          : perfil === "tecnico"
            ? "tec"
            : "admin";
      await page.evaluate(async (modulo) => {
        const { estado } = await import(`/js/pages/${modulo}/estado.js`);
        if (modulo === "eng" && estado.talhaoSelecionado !== "T1")
          throw Error("Seleção do talhão não sincronizou");
        if (modulo === "tec" && estado.talhaoSelecionadoId !== "T1")
          throw Error("Seleção do talhão não sincronizou");
      }, modulo);
    }
    expect(erros).toEqual([]);
  });
}

test("login mantém os controles de senha", async ({ page }) => {
  await preparar(page);
  await page.goto("/login.html");
  await page.locator("#senha").fill("Teste123");
  await page.locator("#togglePassword").click();
  await expect(page.locator("#senha")).toHaveAttribute("type", "text");
  await page.locator("#togglePassword").click();
  await expect(page.locator("#senha")).toHaveAttribute("type", "password");
});

test("editor do administrador pode abrir e cancelar", async ({ page }) => {
  const erros = await preparar(page, "admin");
  await page.goto("/admin.html", { waitUntil: "networkidle" });
  await page.locator('.menu a[href="#mapa-fazenda"]').click();
  await page
    .getByRole("button", { name: "Editar Talhões", exact: true })
    .click();
  await page.getByRole("button", { name: "Cancelar", exact: true }).click();
  await expect(page.locator('svg polygon[data-talhao="T1"]')).toHaveCount(1);
  expect(erros).toEqual([]);
});

test("servidor publica apenas arquivos do frontend", async ({ request }) => {
  for (const arquivo of [
    "/.env",
    "/package.json",
    "/server.js",
    "/tmp/frontend-tools/package.json",
  ]) {
    const resposta = await request.get(arquivo);
    expect([403, 404]).toContain(resposta.status());
  }
});

test("chatbot envia identificador de conversa e permite reiniciar", async ({
  page,
}) => {
  const erros = await preparar(page, "admin");
  const enviados = [];
  await page.route("**/api/chatbot/perguntar", async (route) => {
    enviados.push(route.request().postDataJSON());
    await route.fulfill({
      json: { resposta: "Sensor T1 consultado com sucesso." },
    });
  });
  await page.goto("/admin.html", { waitUntil: "networkidle" });
  await page.locator("#chatbot").click();
  for (const pergunta of ["Como está T1?", "E os sensores dele?"]) {
    await page.locator("#pergunta-chatbot").fill(pergunta);
    await page
      .locator("#form-chatbot")
      .evaluate((form) => form.requestSubmit());
    await expect(page.locator("#pergunta-chatbot")).toBeEnabled();
  }
  expect(enviados).toHaveLength(2);
  expect(enviados[0].conversationId).toBe(enviados[1].conversationId);
  await page.locator("#nova-conversa-chatbot").click();
  await expect(page.locator("#mensagens-chatbot")).not.toContainText(
    "Como está T1?",
  );
  await page.locator("#pergunta-chatbot").fill("Quais são os alertas abertos?");
  await page.locator("#form-chatbot").evaluate((form) => form.requestSubmit());
  await expect(page.locator("#pergunta-chatbot")).toBeEnabled();
  expect(enviados).toHaveLength(3);
  expect(enviados[2].conversationId).not.toBe(enviados[0].conversationId);
  expect(erros).toEqual([]);
});

for (const [perfil, pagina, pergunta, section] of [
  ["admin", "admin.html", "Como cadastrar um sensor?", "sensores-admin"],
  ["engenheiro", "eng.html", "Como cadastrar um plantio?", "cadastro-plantio"],
  ["tecnico", "tec.html", "Como registrar uma inspeção?", "aba-inspecoes"],
]) {
  test(`tutorial no painel ${perfil} abre a seção correta`, async ({
    page,
  }) => {
    const { tutorialResponse } = require("../api/chatbot/tutorials");
    const erros = await preparar(page, perfil);
    await page.route("**/api/chatbot/perguntar", async (route) => {
      const dados = route.request().postDataJSON();
      await route.fulfill({ json: tutorialResponse(dados.pergunta, perfil) });
    });
    await page.goto(`/${pagina}`, { waitUntil: "networkidle" });
    await page.locator("#chatbot").click();
    await page.locator("#pergunta-chatbot").fill(pergunta);
    await page
      .locator("#form-chatbot")
      .evaluate((form) => form.requestSubmit());
    await expect(page.locator("#pergunta-chatbot")).toBeEnabled();
    await expect(page.locator("#mensagens-chatbot")).toContainText("1.");
    await page.getByRole("link", { name: "Abrir a seção do tutorial" }).click();
    await expect(page.locator(`#${section}`)).toBeVisible();
    await expect(page.locator("#painel-chatbot")).toBeHidden();
    expect(erros).toEqual([]);
  });
}

test("edição de funcionário preserva profissão com o campo oculto", async ({
  page,
}) => {
  const erros = await preparar(page, "admin");
  const funcionario = {
    id: 2,
    matricula: "T00002",
    nome: "Pessoa Teste",
    cargo: "Técnico",
    profissao: "Agricultor",
    perfil: "tecnico",
    status: "ativo",
    ativo: true,
  };
  let payload;
  await page.route("**/api/funcionarios", (route) =>
    route.fulfill({ json: { usuarios: [funcionario] } }),
  );
  await page.route("**/api/funcionarios/2", async (route) => {
    payload = route.request().postDataJSON();
    await route.fulfill({ json: { sucesso: true } });
  });
  await page.goto("/admin.html", { waitUntil: "networkidle" });
  await page.locator('[data-editar-funcionario="2"]').click();
  await page.locator("#funcionario-nome").fill("Nome atualizado");
  await page.locator("#btn-salvar-funcionario").click();
  await expect(page.locator("#mensagem-funcionario")).toContainText(
    "Funcionário atualizado",
  );
  expect(payload).not.toHaveProperty("profissao");
  await expect(page.locator("#tabela-funcionarios")).toContainText(
    "Agricultor",
  );
  expect(erros).toEqual([]);
});
