﻿const { defineConfig } = require("@playwright/test");
module.exports = defineConfig({
  testDir: "./tests",
  testMatch: "**/*.spec.js",
  workers: 1,
  use: {
    baseURL: "http://127.0.0.1:4317",
    channel: process.env.PLAYWRIGHT_CHANNEL || "chrome",
    headless: true,
  },
  webServer: {
    command: "node server.js",
    url: "http://127.0.0.1:4317/login.html",
    env: { PORT: "4317" },
    reuseExistingServer: false,
  },
});
