# Chatbot FrutLog

O assistente web do painel Admin envia perguntas a `POST /api/chatbot/perguntar`, com memória curta no backend e contexto operacional filtrado. Consulte [a documentação do assistente web](../documentacao/chatbot.md).

A integração Python desta pasta é independente e consulta `GET /api/chatbot/contexto`. Essa rota retorna as dez ocorrências mais recentes e o estado/leitura dos sensores da fazenda; não utiliza os filtros nem a memória do assistente web.

O script interativo `chatboot.py` pode incluir o mesmo contexto real nas respostas. Configure `FRUTLOG_API_URL` (por padrão `http://localhost:3000/api`) e `FRUTLOG_API_TOKEN` no ambiente local antes de iniciar o script. O token deve ser um JWT de sessão FrutLog válido, expira após oito horas e não deve ser salvo no repositório. A ausência do token é informada no contexto enviado ao modelo; falhas de consulta à API são exibidas explicitamente.

O script continua solicitando a chave Groq via entrada oculta. Não armazene chaves Groq, tokens FrutLog ou credenciais nos arquivos do projeto.
