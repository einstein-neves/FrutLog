document.addEventListener("DOMContentLoaded", () => {
  const sessao = FrutLog.obterSessao();
  if (!sessao || document.getElementById("painel-chatbot")) return;
  const sugestoes = {
    admin: [
      "Como cadastrar um funcionário?",
      "Como cadastrar um sensor?",
      "Como registrar uma colheita?",
      "Quais tutoriais estão disponíveis?",
    ],
    engenheiro: [
      "Como criar um talhão?",
      "Como cadastrar um plantio?",
      "Como dividir um talhão?",
      "Como consultar relatórios?",
    ],
    tecnico: [
      "Como registrar uma inspeção?",
      "Como registrar uma ocorrência?",
      "Como enviar o relatório diário?",
      "Como registrar problema no sensor?",
    ],
  };
  if (!sugestoes[sessao.perfil]) return;
  const container = document.createElement("div");
  container.className = "assistente-frutlog";
  container.innerHTML = `
    <section id="painel-chatbot" class="painel-chatbot" aria-label="Assistente FrutLog" hidden>
      <header class="cabecalho-chatbot">
        <div class="chatbot-identidade">
          <span class="chatbot-avatar" aria-hidden="true"><i class="fa-solid fa-robot"></i><i class="fa-solid fa-leaf chatbot-folha"></i></span>
          <div><strong>Assistente FrutLog</strong><span>Aprenda a usar o seu painel</span></div>
        </div>
        <div class="acoes-cabecalho-chatbot">
          <button id="nova-conversa-chatbot" type="button" aria-label="Iniciar nova conversa" title="Nova conversa"><i class="fa-solid fa-rotate" aria-hidden="true"></i></button>
          <button id="fechar-chatbot" type="button" aria-label="Fechar assistente"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
        </div>
      </header>
      <div id="mensagens-chatbot" class="mensagens-chatbot" aria-live="polite">
        <article class="mensagem-chatbot resposta"><span class="autor-mensagem">FrutLog</span><div class="conteudo-mensagem">Olá! Pergunte como realizar uma tarefa no sistema. Vou mostrar os passos e indicar a seção do seu painel.</div></article>
        <div class="sugestoes-chatbot" aria-label="Perguntas sugeridas"></div>
      </div>
      <form id="form-chatbot" class="form-chatbot">
        <label class="sr-only" for="pergunta-chatbot">Sua pergunta</label>
        <textarea id="pergunta-chatbot" name="pergunta" maxlength="1000" rows="1" autocomplete="off" placeholder="Como faço para…" required></textarea>
        <button type="submit" aria-label="Enviar pergunta"><i class="fa-solid fa-paper-plane" aria-hidden="true"></i><span>Enviar</span></button>
      </form>
      <p class="rodape-chatbot">Tutoriais das funções do FrutLog. Você realiza as ações na tela.</p>
    </section>
    <button id="chatbot" class="chatbot" type="button" aria-label="Abrir assistente" aria-expanded="false" aria-controls="painel-chatbot"><i class="fa-solid fa-robot" aria-hidden="true"></i><span class="chatbot-sinal" aria-hidden="true"></span></button>`;
  for (const texto of sugestoes[sessao.perfil]) {
    const botao = document.createElement("button");
    botao.type = "button";
    botao.className = "sugestao-chatbot";
    botao.textContent = texto;
    container.querySelector(".sugestoes-chatbot").append(botao);
  }
  document.body.append(container);
});
