/* =========================================================
   FRUTLOG - ASSISTENTE COM CONTEXTO OPERACIONAL
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {
  const botao = document.getElementById("chatbot");
  const painel = document.getElementById("painel-chatbot");
  const botaoFechar = document.getElementById("fechar-chatbot");
  const formulario = document.getElementById("form-chatbot");
  const campoPergunta = document.getElementById("pergunta-chatbot");
  const mensagens = document.getElementById("mensagens-chatbot");
  if (!botao || !painel || !formulario || !campoPergunta || !mensagens) return;
  const novaConversa = document.getElementById("nova-conversa-chatbot");
  const criarConversa = () =>
    typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  let conversationId = criarConversa();
  let enviando = false;

  novaConversa?.addEventListener("click", () => {
    if (enviando) return;
    conversationId = criarConversa();
    mensagens.replaceChildren();
    adicionarMensagem(
      "Nova conversa iniciada. Sobre qual talhão, sensor ou assunto você quer perguntar?",
    );
    campoPergunta.focus();
  });

  function adicionarTextoFormatado(destino, texto) {
    const linhas = String(texto || "").split("\n");
    linhas.forEach((linha, indice) => {
      if (indice) destino.appendChild(document.createElement("br"));
      const partes = linha.split(/(\*\*[^*]+\*\*)/g);
      partes.forEach((parte) => {
        if (parte.startsWith("**") && parte.endsWith("**")) {
          const destaque = document.createElement("strong");
          destaque.textContent = parte.slice(2, -2);
          destino.appendChild(destaque);
        } else {
          destino.appendChild(document.createTextNode(parte));
        }
      });
    });
  }

  function rolarParaFim() {
    mensagens.scrollTop = mensagens.scrollHeight;
  }

  function adicionarMensagem(texto, tipo = "resposta", links = []) {
    const mensagem = document.createElement("article");
    mensagem.className = `mensagem-chatbot ${tipo}`;
    const autor = document.createElement("span");
    autor.className = "autor-mensagem";
    autor.textContent = tipo === "pergunta" ? "Você" : "FrutLog";
    const conteudo = document.createElement("div");
    conteudo.className = "conteudo-mensagem";
    adicionarTextoFormatado(conteudo, texto);
    mensagem.append(autor, conteudo);
    for (const item of links) {
      if (
        typeof item?.href !== "string" ||
        !/^(admin|eng|tec)\.html#[a-z0-9-]+$/.test(item.href)
      )
        continue;
      const url = new URL(item.href, window.location.href);
      const paginas = {
        admin: "admin.html",
        engenheiro: "eng.html",
        tecnico: "tec.html",
      };
      if (
        url.pathname.split("/").pop() !== paginas[FrutLog.obterSessao()?.perfil]
      )
        continue;
      const link = document.createElement("a");
      link.href = item.href;
      link.className = "link-tutorial-chatbot";
      link.textContent = item.label || "Abrir seção";
      link.addEventListener("click", (evento) => {
        if (url.pathname !== window.location.pathname) return;
        const menu = [...document.querySelectorAll(".menu a[href]")].find(
          (a) => a.hash === url.hash,
        );
        if (!menu) return;
        evento.preventDefault();
        menu.click();
        alternar(false);
        document
          .getElementById(url.hash.slice(1))
          ?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      mensagem.append(link);
    }
    mensagens.appendChild(mensagem);
    rolarParaFim();
  }

  function indicadorDigitando() {
    const indicador = document.createElement("div");
    indicador.className = "chatbot-digitando";
    indicador.setAttribute("aria-label", "Assistente analisando dados");
    indicador.innerHTML = "<span></span><span></span><span></span>";
    mensagens.appendChild(indicador);
    rolarParaFim();
    return indicador;
  }

  function alternar(aberto) {
    painel.hidden = !aberto;
    botao.setAttribute("aria-expanded", String(aberto));
    botao.classList.toggle("chatbot-aberto", aberto);
    if (aberto) campoPergunta.focus();
  }

  botao.addEventListener("click", () => alternar(painel.hidden));
  botaoFechar?.addEventListener("click", () => alternar(false));
  document.querySelectorAll(".sugestao-chatbot").forEach((sugestao) => {
    sugestao.addEventListener("click", () => {
      campoPergunta.value = sugestao.textContent;
      formulario.requestSubmit();
    });
  });

  campoPergunta.addEventListener("keydown", (evento) => {
    if (evento.key === "Enter" && !evento.shiftKey) {
      evento.preventDefault();
      formulario.requestSubmit();
    }
  });

  formulario.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    const pergunta = campoPergunta.value.trim();
    if (!pergunta || enviando) return;
    enviando = true;
    if (novaConversa) novaConversa.disabled = true;

    adicionarMensagem(pergunta, "pergunta");
    campoPergunta.value = "";
    campoPergunta.disabled = true;
    const enviar = formulario.querySelector('[type="submit"]');
    if (enviar) enviar.disabled = true;
    const digitando = indicadorDigitando();
    try {
      const resultado = await FrutLog.apiFetch("/chatbot/perguntar", {
        method: "POST",
        body: JSON.stringify({ pergunta, conversationId }),
      });
      adicionarMensagem(resultado.resposta, "resposta", resultado.links || []);
    } catch (erro) {
      adicionarMensagem(`Não foi possível responder agora: ${erro.message}`);
    } finally {
      enviando = false;
      if (novaConversa) novaConversa.disabled = false;
      digitando.remove();
      campoPergunta.disabled = false;
      if (enviar) enviar.disabled = false;
      campoPergunta.focus();
    }
  });
});
