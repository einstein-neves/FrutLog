// Estado exclusivo deste painel, compartilhado pelos seus módulos.
export const estado = {};

estado.talhoes = FrutLogTalhoes.obterTalhoes();

estado.historicoInspecoes = [];

estado.historicoOcorrencias = [];

estado.historicoProblemasSensores = [];

estado.sensoresDoServidor = [];

estado.painelTecnico = {};

estado.graficoMetricas = null;

estado.graficoClimaMensalTecnico = null;

estado.telemetriaDiaria = [];

estado.telemetriaMensal = [];

estado.talhaoSelecionadoId = null;

estado.telemetriaMensalEsp32 = [];
