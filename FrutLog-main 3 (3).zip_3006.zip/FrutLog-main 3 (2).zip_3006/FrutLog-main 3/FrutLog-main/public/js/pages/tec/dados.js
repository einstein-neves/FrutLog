import { estado } from "./estado.js";
import { carregarGraficoMetricas, preencherFiltroTelemetria } from "./telemetria.js";
import {
  atualizarSelectSensoresInspecao,
  carregarAlertas,
  carregarHistoricoInspecoes,
  carregarHistoricoOcorrencias,
  carregarHistoricoProblemasSensores,
  carregarSensores,
  carregarTarefasDia,
} from "./registros.js";
import { exibirMensagem } from "./interface.js";
import { carregarTalhoes } from "./mapa.js";

export function atualizarTalhoesMonitorados() {
  if (FrutLog.AUTENTICACAO_API_ATIVA) return;
  estado.talhoes = estado.talhoes.map((feature) => FrutLogTalhoes.aplicarMonitoramento(feature));
}

export async function carregarPainelTecnico() {
  const [painel, talhoesServidor] = await Promise.all([
    FrutLog.apiFetch("/painel-tecnico"),
    FrutLogMapaTalhoes.carregarMapaTalhoes("tecnico"),
  ]);
  estado.painelTecnico = painel;
  estado.sensoresDoServidor = painel.sensores || [];
  estado.talhoes = talhoesServidor;
  atualizarSelectSensoresInspecao();

  const plantioPorTalhao = new Map(
    (painel.plantios || []).map((plantio) => [plantio.talhao, plantio]),
  );
  const monitoramentoPorTalhao = new Map(
    (painel.talhoes || []).map((talhao) => [talhao.id, talhao]),
  );
  const sensoresPorTalhao = new Map();
  estado.sensoresDoServidor.forEach((sensor) => {
    if (!sensoresPorTalhao.has(sensor.talhao)) sensoresPorTalhao.set(sensor.talhao, []);
    sensoresPorTalhao.get(sensor.talhao).push(sensor);
  });

  estado.talhoes = estado.talhoes.map((feature) => {
    const codigo = feature.properties.codigo;
    const resumoTalhao = monitoramentoPorTalhao.get(codigo);
    const plantio = plantioPorTalhao.get(codigo);
    const sensores = sensoresPorTalhao.get(codigo) || [];
    const sensorAtivo = (tipo) =>
      sensores.find((item) => item.tipo === tipo && item.status !== "Inativo");
    const temperatura = sensorAtivo("temperatura");
    const umidadeSolo = sensorAtivo("umidadeSolo");
    const umidadeAr = sensorAtivo("umidadeAr");
    const props = {
      ...feature.properties,
      produto: plantio?.produto || feature.properties.produto || "--",
      variedade: plantio?.variedade || feature.properties.variedade || "--",
      solo: plantio?.solo || feature.properties.solo || "--",
      plantio: plantio?.plantado_em || feature.properties.plantio || "--",
      colheita: plantio?.previsao_colheita || feature.properties.colheita || "--",
      area: `${feature.properties.area_hectares ?? feature.properties.area ?? "--"}${feature.properties.area_hectares ? " hectares" : ""}`,
      sensor: resumoTalhao?.sensor || sensores[0]?.sensor || "Não associado",
      status: resumoTalhao?.situacao || "Sem leitura",
      prioridade: resumoTalhao?.prioridade || "Aguardando leitura de sensor.",
      diaria: {
        ...feature.properties.diaria,
        temperatura: temperatura?.valor ?? "--",
        umidadeSolo: umidadeSolo?.valor ?? "--",
        umidadeAr: umidadeAr?.valor ?? "--",
      },
      monitoramento: {
        temperaturaAtual: temperatura?.valor ?? null,
        temperaturaMaxima: feature.properties.parametros?.temperaturaMaxima ?? null,
      },
    };
    return { ...feature, properties: props };
  });

  estado.historicoInspecoes = painel.inspecoes || [];
  estado.historicoOcorrencias = painel.ocorrencias || [];
  estado.historicoProblemasSensores = painel.problemasSensores || [];
  exibirMensagem("mensagem-dados-tecnicos", "Dados sincronizados com o servidor.", "sucesso");
  preencherFiltroTelemetria();
}

export function obterSensores() {
  if (FrutLog.AUTENTICACAO_API_ATIVA) return estado.sensoresDoServidor;
  atualizarTalhoesMonitorados();

  return estado.talhoes.map((feature) => {
    const props = feature.properties;
    const monitoramento = props.monitoramento || {};

    return {
      sensor: props.sensor || "Não associado",
      talhao: props.codigo,
      status: props.sensor === "Não associado" ? "Atencao" : monitoramento.status || props.status,
      comunicacao: props.apontamentoTecnico?.data || "--",
      leitura:
        monitoramento.temperaturaAtual !== null && monitoramento.temperaturaAtual !== undefined
          ? `${monitoramento.temperaturaAtual} C`
          : "--",
    };
  });
}

export function obterTarefasDia() {
  if (FrutLog.AUTENTICACAO_API_ATIVA) return estado.painelTecnico.tarefas || [];
  atualizarTalhoesMonitorados();

  return estado.talhoes
    .filter(
      (feature) =>
        feature.properties.status !== "Normal" || feature.properties.sensor === "Não associado",
    )
    .map((feature) => ({
      talhao: feature.properties.codigo,
      prioridade: feature.properties.status === "Critico" ? "Critico" : "Atencao",
      atividade: feature.properties.prioridade || "Verificar situação do talhão.",
    }));
}

export function obterAlertas() {
  if (FrutLog.AUTENTICACAO_API_ATIVA) {
    return (estado.painelTecnico.alertas || []).map((alerta) => ({
      nivel: alerta.severidade || "atencao",
      titulo: alerta.titulo,
      texto: alerta.mensagem,
    }));
  }
  atualizarTalhoesMonitorados();

  return estado.talhoes
    .filter(
      (feature) =>
        feature.properties.status !== "Normal" || feature.properties.sensor === "Não associado",
    )
    .map((feature) => ({
      nivel: feature.properties.status === "Critico" ? "critico" : "atencao",
      titulo: `Talhão ${feature.properties.codigo} exige acompanhamento`,
      texto:
        feature.properties.sensor === "Não associado"
          ? "Talhão sem sensor associado após configuração ou divisão."
          : feature.properties.prioridade,
    }));
}

export async function atualizarDadosAposRegistro() {
  await carregarPainelTecnico();
  carregarTalhoes();
  carregarTarefasDia();
  carregarHistoricoInspecoes();
  carregarHistoricoOcorrencias();
  carregarSensores();
  carregarHistoricoProblemasSensores();
  carregarAlertas();
  carregarGraficoMetricas();
}
