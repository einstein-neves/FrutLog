import {
  dataLocalISO,
  escaparHtml,
  exibirMensagem,
  formatarData,
  normalizarClasse,
} from "./interface.js";
import { estado } from "./estado.js";
import {
  atualizarDadosAposRegistro,
  obterAlertas,
  obterSensores,
  obterTarefasDia,
} from "./dados.js";
import { renderizarTelemetriaDiaria } from "./telemetria.js";

export function configurarRelatorioDiario() {
  const formulario = document.getElementById("form-relatorio-diario");
  formulario?.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    const dados = Object.fromEntries(new FormData(formulario));
    const botao = formulario.querySelector('[type="submit"]');
    if (botao) botao.disabled = true;
    try {
      if (!FrutLog.AUTENTICACAO_API_ATIVA) {
        throw new Error("O envio de relatórios requer a API autenticada.");
      }
      const resposta = await FrutLog.apiFetch("/relatorios-diarios", {
        method: "POST",
        body: JSON.stringify(dados),
      });
      exibirMensagem(
        "mensagem-relatorio-diario",
        `Relatório registrado e disponível para Engenharia e Administração (${formatarData(resposta.relatorio.data_relatorio)}).`,
        "sucesso",
      );
      formulario.reset();
      document.getElementById("relatorio-data").value = dataLocalISO();
    } catch (erro) {
      exibirMensagem("mensagem-relatorio-diario", erro.message, "erro");
    } finally {
      if (botao) botao.disabled = false;
    }
  });
}

export function preencherSelectTalhoes(select) {
  if (!select) return;

  const atual = select.value;
  const opcoes = estado.talhoes
    .map((feature) => {
      const codigo = escaparHtml(feature.properties.codigo);
      return `<option value="${codigo}">${codigo}</option>`;
    })
    .join("");
  select.innerHTML = `<option value="">${opcoes ? "Selecione o talhão" : "Nenhum talhão carregado"}</option>${opcoes}`;
  if (estado.talhoes.some((feature) => feature.properties.codigo === atual)) select.value = atual;
}

export function atualizarSelectSensoresInspecao() {
  const select = document.getElementById("inspecao-sensor");
  const codigoTalhao = document.getElementById("inspecao-talhao")?.value;
  if (!select) return;
  const sensores = estado.sensoresDoServidor.filter(
    (sensor) => sensor.ativo && sensor.talhao === codigoTalhao,
  );
  select.innerHTML =
    '<option value="">Sem sensor associado</option>' +
    sensores
      .map((sensor) => {
        const status = sensor.status === "Online" ? "Online" : "Cadastrado, aguardando leitura";
        return `<option value="${escaparHtml(sensor.id)}">${escaparHtml(sensor.sensor)} - ${escaparHtml(sensor.tipo)} (${status})</option>`;
      })
      .join("");
}

export function carregarTarefasDia() {
  const lista = document.getElementById("lista-tarefas");
  if (!lista) return;

  const tarefasDia = obterTarefasDia();

  if (!tarefasDia.length) {
    lista.innerHTML =
      '<article class="tarefa-card"><strong>Sem tarefas pendentes</strong><p>Não há tarefas atribuídas no momento.</p></article>';
    return;
  }

  lista.innerHTML = tarefasDia
    .map(
      (tarefa) => `
    <article class="tarefa-card ${normalizarClasse(tarefa.prioridade)}">
      <span class="badge-status ${normalizarClasse(tarefa.prioridade)}">Talhão ${escaparHtml(tarefa.talhao)}</span>
      <strong>${escaparHtml(FrutLog.textoInterface(tarefa.prioridade))}</strong>
      <p>${escaparHtml(tarefa.atividade)}</p>
    </article>
  `,
    )
    .join("");
}

export function carregarHistoricoInspecoes() {
  const tabela = document.getElementById("tabela-inspecoes");
  if (!tabela) return;

  tabela.innerHTML = estado.historicoInspecoes
    .map(
      (inspecao) => `
    <tr>
      <td>${formatarData(inspecao.data)}</td>
      <td>${escaparHtml(inspecao.talhao)}</td>
      <td>${escaparHtml(inspecao.sensor || "--")}</td>
      <td><span class="status-sensor ${normalizarClasse(inspecao.situacao)}">${escaparHtml(FrutLog.textoInterface(inspecao.situacao))}</span></td>
      <td>${escaparHtml(inspecao.problemas || "Sem ocorrência")}</td>
      <td>${escaparHtml(inspecao.observacoes || "-")}</td>
    </tr>
  `,
    )
    .join("");
}

export function carregarHistoricoOcorrencias() {
  const tabela = document.getElementById("tabela-ocorrencias");
  if (!tabela) return;

  if (!estado.historicoOcorrencias.length) {
    tabela.innerHTML = '<tr><td colspan="3">Nenhuma ocorrência registrada.</td></tr>';
    return;
  }

  tabela.innerHTML = estado.historicoOcorrencias
    .map(
      (ocorrencia) => `
    <tr>
      <td>${escaparHtml(ocorrencia.talhao)}</td>
      <td>${escaparHtml(ocorrencia.tipo || ocorrencia.problema)}</td>
      <td>${escaparHtml(ocorrencia.observacao || "-")}</td>
    </tr>
  `,
    )
    .join("");
}

export function carregarHistoricoProblemasSensores() {
  const tabela = document.getElementById("tabela-problemas-sensores");
  if (!tabela) return;

  if (!estado.historicoProblemasSensores.length) {
    tabela.innerHTML = '<tr><td colspan="5">Nenhum problema de sensor registrado.</td></tr>';
    return;
  }

  tabela.innerHTML = estado.historicoProblemasSensores
    .map(
      (problema) => `
    <tr>
      <td>${escaparHtml(problema.sensor)}</td>
      <td>${escaparHtml(problema.talhao)}</td>
      <td>${formatarData(problema.data)}</td>
      <td>${escaparHtml(problema.problema)}</td>
      <td>${escaparHtml(problema.observacao || "-")}</td>
    </tr>
  `,
    )
    .join("");
}

export function carregarSensores() {
  const tabela = document.getElementById("tabela-sensores");
  const selectSensor = document.getElementById("problema-sensor-id");
  const sensores = obterSensores();

  if (tabela) {
    if (!sensores.length) {
      tabela.innerHTML = '<tr><td colspan="5">Nenhum sensor cadastrado.</td></tr>';
    } else
      tabela.innerHTML = sensores
        .map(
          (item) => `
      <tr>
        <td>${escaparHtml(item.sensor)}</td>
        <td>${escaparHtml(item.talhao)}</td>
        <td><span class="status-sensor ${normalizarClasse(item.status)}">${escaparHtml(FrutLog.textoInterface(item.status))}</span></td>
        <td>${escaparHtml(formatarData(item.comunicacao))}</td>
        <td>${escaparHtml(item.leitura)}</td>
      </tr>
    `,
        )
        .join("");
  }

  if (selectSensor) {
    selectSensor.innerHTML =
      '<option value="">Sensor ausente / não cadastrado</option>' +
      sensores
        .filter((item) => item.ativo)
        .map(
          (item) =>
            `<option value="${escaparHtml(item.sensor)}">${escaparHtml(item.sensor)}</option>`,
        )
        .join("");
  }
}

export function carregarAlertas() {
  const lista = document.getElementById("lista-alertas");
  if (!lista) return;

  const alertas = obterAlertas();

  if (!alertas.length) {
    lista.innerHTML =
      '<article class="alerta-tecnico"><strong>Sem alertas</strong><p>Nenhum alerta importante registrado.</p></article>';
    return;
  }

  lista.innerHTML = alertas
    .map(
      (alerta) => `
    <article class="alerta-tecnico ${alerta.nivel}">
      <strong>${alerta.titulo}</strong>
      <p>${alerta.texto}</p>
    </article>
  `,
    )
    .join("");
}

export function obterDadosFormulario(formulario) {
  return Object.fromEntries(new FormData(formulario));
}

export async function registrarInspecao(evento) {
  evento.preventDefault();
  const dados = obterDadosFormulario(evento.currentTarget);

  try {
    if (!dados.data || !/^\d{4}-\d{2}-\d{2}$/.test(dados.data)) {
      throw new Error("Selecione uma data valida.");
    }

    await FrutLog.apiFetch("/inspecoes", {
      method: "POST",
      body: JSON.stringify({
        talhao: dados.talhao,
        data: dados.data,
        situacao: dados.situacao,
        sensor_id: dados.sensor_id || null,
        problemas: dados.problemas || "Sem ocorrência",
        observacoes: dados.observacoes || "-",
      }),
    });
    await atualizarDadosAposRegistro();
    exibirMensagem("mensagem-inspecao", "Inspeção registrada com sucesso.");
    evento.currentTarget.reset();
    document.getElementById("inspecao-data").value = dataLocalISO();
  } catch (erro) {
    exibirMensagem("mensagem-inspecao", erro.message, "erro");
  }
}

export async function registrarOcorrencia(evento) {
  evento.preventDefault();
  const dados = obterDadosFormulario(evento.currentTarget);

  try {
    await FrutLog.apiFetch("/ocorrencias", {
      method: "POST",
      body: JSON.stringify({
        talhao: dados.talhao,
        tipo: dados.tipo,
        observacao: dados.observacao || "-",
      }),
    });
    await atualizarDadosAposRegistro();
    exibirMensagem("mensagem-ocorrencia", "Ocorrência registrada com sucesso.");
    evento.currentTarget.reset();
  } catch (erro) {
    exibirMensagem("mensagem-ocorrencia", erro.message, "erro");
  }
}

export async function registrarProblemaSensor(evento) {
  evento.preventDefault();
  const dados = obterDadosFormulario(evento.currentTarget);

  try {
    if (!dados.data || !/^\d{4}-\d{2}-\d{2}$/.test(dados.data)) {
      throw new Error("Selecione uma data valida.");
    }

    await FrutLog.apiFetch("/sensores/problemas", {
      method: "POST",
      body: JSON.stringify({
        sensor: dados.sensor,
        talhao: dados.talhao,
        data: dados.data,
        problema: dados.problema,
        observacao: dados.observacao || "-",
      }),
    });
    await atualizarDadosAposRegistro();
    exibirMensagem("mensagem-problema-sensor", "Problema de sensor registrado com sucesso.");
    evento.currentTarget.reset();
    document.getElementById("problema-sensor-data").value = dataLocalISO();
  } catch (erro) {
    exibirMensagem("mensagem-problema-sensor", erro.message, "erro");
  }
}

export function configurarFormularios() {
  document.getElementById("form-inspecao")?.addEventListener("submit", registrarInspecao);
  document
    .getElementById("inspecao-talhao")
    ?.addEventListener("change", atualizarSelectSensoresInspecao);
  atualizarSelectSensoresInspecao();
  document.getElementById("form-ocorrencia")?.addEventListener("submit", registrarOcorrencia);
  document
    .getElementById("form-problema-sensor")
    ?.addEventListener("submit", registrarProblemaSensor);
  document
    .getElementById("filtro-talhao-telemetria")
    ?.addEventListener("change", renderizarTelemetriaDiaria);
}
