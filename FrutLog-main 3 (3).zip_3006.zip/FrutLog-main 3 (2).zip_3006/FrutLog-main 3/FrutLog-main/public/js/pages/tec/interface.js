export { escaparHtml, preencherTexto } from "../../core/dom.js";

export function dataLocalISO() {
  const hoje = new Date();
  return `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, "0")}-${String(hoje.getDate()).padStart(2, "0")}`;
}

export function configurarAbas() {
  const abas = [...document.querySelectorAll(".aba-tecnico")];
  const links = [...document.querySelectorAll(".menu .nav-link")];
  const ativar = (abaAtiva) => {
    abas.forEach((aba) => {
      const ativa = aba === abaAtiva;
      aba.classList.toggle("ativa", ativa);
      aba.setAttribute("aria-selected", String(ativa));
      aba.tabIndex = ativa ? 0 : -1;
      document.getElementById(aba.getAttribute("aria-controls")).hidden = !ativa;
    });
    links.forEach((link) => {
      const ativo = link.hash === `#${abaAtiva.getAttribute("aria-controls")}`;
      link.classList.toggle("active", ativo);
      if (ativo) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    });
  };

  abas.forEach((aba, indice) => {
    aba.addEventListener("click", () => ativar(aba));
    aba.addEventListener("keydown", (evento) => {
      let proximo = indice;
      if (evento.key === "ArrowRight") proximo = (indice + 1) % abas.length;
      else if (evento.key === "ArrowLeft") proximo = (indice - 1 + abas.length) % abas.length;
      else if (evento.key === "Home") proximo = 0;
      else if (evento.key === "End") proximo = abas.length - 1;
      else return;
      evento.preventDefault();
      abas[proximo].focus();
      ativar(abas[proximo]);
    });
  });
  links.forEach((link) =>
    link.addEventListener("click", (evento) => {
      const aba = abas.find((item) => item.getAttribute("aria-controls") === link.hash.slice(1));
      if (!aba) return;
      evento.preventDefault();
      ativar(aba);
      history.replaceState(null, "", link.hash);
    }),
  );
  if (abas.length) {
    const abaInicial = abas.find(
      (aba) => `#${aba.getAttribute("aria-controls")}` === window.location.hash,
    );
    ativar(abaInicial || abas[0]);
  }
}

export function verificarSessao() {
  return FrutLog.verificarSessao(["tecnico"]);
}

export function normalizarClasse(texto) {
  return String(texto)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

export function formatarData(dataISO) {
  if (!dataISO) return "--";
  const data = String(dataISO).match(/^(\d{4})-(\d{2})-(\d{2})/);
  return data ? `${data[3]}/${data[2]}/${data[1]}` : dataISO;
}

export function exibirMensagem(id, texto, tipo = "sucesso") {
  const elemento = document.getElementById(id);
  if (!elemento) return;

  elemento.textContent = texto;
  elemento.className = `mensagem-feedback ${tipo}`;
}
