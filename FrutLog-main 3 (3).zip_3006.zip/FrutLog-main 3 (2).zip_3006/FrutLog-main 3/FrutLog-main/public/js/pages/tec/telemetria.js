import { estado } from "./estado.js";
import { escaparHtml, formatarData } from "./interface.js";
import { obterSensores } from "./dados.js";

export function preencherFiltroTelemetria() {
  const select = document.getElementById("filtro-talhao-telemetria");
  if (!select) return;
  const selecionado = select.value;
  const codigos = estado.talhoes.map((feature) => feature.properties.codigo);
  select.innerHTML =
    '<option value="">Todos os talhões</option>' +
    codigos
      .map((codigo) => `<option value="${escaparHtml(codigo)}">${escaparHtml(codigo)}</option>`)
      .join("");
  if (codigos.includes(selecionado)) select.value = selecionado;
}

export async function carregarTelemetriaDiaria() {
  const tabela = document.getElementById("tabela-telemetria-tecnico");
  if (!tabela || !FrutLog.AUTENTICACAO_API_ATIVA) return;
  const mensagem = document.getElementById("mensagem-telemetria-diaria");
  try {
    const resposta = await FrutLog.apiFetch("/telemetria/diaria");
    estado.telemetriaDiaria = resposta.leituras || [];
    estado.telemetriaMensal = resposta.mensal || [];
    try {
      estado.telemetriaMensalEsp32 =
        (await FrutLog.apiFetch("/telemetria/esp32-mensal")).mensal || [];
    } catch (erro) {
      estado.telemetriaMensalEsp32 = [];
    }
    renderizarTelemetriaDiaria();
    renderizarTelemetriaMensal();
    renderizarGraficoClimaMensalTecnico();
    if (mensagem) {
      mensagem.textContent = `Consolidado desde ${formatarData(resposta.desde)}.`;
      mensagem.className = "mensagem-feedback";
    }
  } catch (erro) {
    if (mensagem) {
      mensagem.textContent = erro.message;
      mensagem.className = "mensagem-feedback erro";
    }
    tabela.innerHTML = `<tr><td colspan="6">${escaparHtml(erro.message)}</td></tr>`;
  }
}

export function renderizarTelemetriaDiaria() {
  renderizarResumoTelemetriaDiaria();
  const tabela = document.getElementById("tabela-telemetria-tecnico");
  if (!tabela) return;
  const talhaoSelecionado = document.getElementById("filtro-talhao-telemetria")?.value || "";
  const linhas = estado.telemetriaDiaria.filter(
    (item) => !talhaoSelecionado || item.talhao === talhaoSelecionado,
  );
  if (!linhas.length) {
    tabela.innerHTML =
      '<tr><td colspan="6">Ainda não há telemetria diária para o filtro selecionado.</td></tr>';
    return;
  }
  const metricas = {
    temperatura: "Temperatura",
    umidadeAr: "Umidade do ar",
    umidadeSolo: "Umidade do solo",
    chuva: "Chuva",
  };
  tabela.innerHTML = linhas
    .map(
      (item) => `
    <tr>
      <td>${escaparHtml(formatarData(item.dia))}</td>
      <td>${escaparHtml(item.talhao)} · ${escaparHtml(metricas[item.codigo_metrica] || item.codigo_metrica)}</td>
      <td>${escaparHtml(item.valor_medio)}</td>
      <td>${escaparHtml(item.valor_minimo)}</td>
      <td>${escaparHtml(item.valor_maximo)}</td>
      <td>${escaparHtml(item.leituras_contabilizadas)}</td>
    </tr>
  `,
    )
    .join("");
}

export function renderizarResumoTelemetriaDiaria() {
  const tabela = document.getElementById("tabela-telemetria-diaria");
  if (!tabela) return;
  const filtro = document.getElementById("filtro-talhao-telemetria")?.value || "";
  const grupos = new Map();
  estado.telemetriaDiaria
    .filter((item) => !filtro || item.talhao === filtro)
    .forEach((item) => {
      const chave = JSON.stringify([item.dia, item.talhao]);
      if (!grupos.has(chave))
        grupos.set(chave, { dia: item.dia, talhao: item.talhao, valores: {} });
      grupos.get(chave).valores[item.codigo_metrica] = item.valor_medio;
    });
  const linhas = [...grupos.values()].sort(
    (a, b) =>
      String(b.dia).localeCompare(String(a.dia)) ||
      String(a.talhao).localeCompare(String(b.talhao)),
  );
  tabela.innerHTML = linhas.length
    ? linhas
        .map(
          (item) => `
    <tr><td>${escaparHtml(formatarData(item.dia))}</td><td>${escaparHtml(item.talhao)}</td>
    ${["temperatura", "umidadeAr", "umidadeSolo", "chuva"].map((metrica) => `<td>${escaparHtml(item.valores[metrica] ?? "--")}</td>`).join("")}</tr>
  `,
        )
        .join("")
    : '<tr><td colspan="6">Ainda não há telemetria diária para o filtro selecionado.</td></tr>';
}

export function renderizarTelemetriaMensal() {
  const tabela = document.getElementById("tabela-telemetria-mensal-tecnico");
  if (!tabela) return;
  if (!estado.telemetriaMensal.length) {
    tabela.innerHTML =
      '<tr><td colspan="6">Ainda não há consolidado mensal de telemetria.</td></tr>';
    return;
  }
  const metricas = {
    temperatura: "Temperatura",
    umidadeAr: "Umidade do ar",
    umidadeSolo: "Umidade do solo",
    chuva: "Chuva",
  };
  tabela.innerHTML = estado.telemetriaMensal
    .map(
      (item) => `
    <tr>
      <td>${escaparHtml(item.mes)}</td>
      <td>${escaparHtml(item.talhao)} · ${escaparHtml(metricas[item.codigo_metrica] || item.codigo_metrica)}</td>
      <td>${escaparHtml(item.valor_medio)}</td>
      <td>${escaparHtml(item.valor_minimo)}</td>
      <td>${escaparHtml(item.valor_maximo)}</td>
      <td>${escaparHtml(item.leituras_contabilizadas)}</td>
    </tr>
  `,
    )
    .join("");
}

export function renderizarGraficoClimaMensalTecnico() {
  const canvas = document.getElementById("grafico-clima-mensal-tecnico");

  if (!canvas || typeof Chart === "undefined") return;

  if (estado.graficoClimaMensalTecnico) {
    estado.graficoClimaMensalTecnico.destroy();
  }

  const dadosMensais = [...estado.telemetriaMensal, ...estado.telemetriaMensalEsp32];

  const metricas = {
    temperatura: {
      nome: "Temperatura",
      unidade: "°C",
    },
    chuva: {
      nome: "Chuva",
      unidade: "mm",
    },
    umidadeAr: {
      nome: "Umidade do ar",
      unidade: "%",
    },
    umidadeSolo: {
      nome: "Umidade do solo",
      unidade: "%",
    },
  };

  const meses = [...new Set(dadosMensais.map((item) => item.mes).filter(Boolean))].sort();

  const dados = meses.map((mes) => {
    const resultado = { mes };

    Object.keys(metricas).forEach((codigo) => {
      const leituras = dadosMensais
        .filter(
          (item) =>
            item.mes === mes &&
            item.codigo_metrica === codigo &&
            Number.isFinite(Number(item.valor_medio)),
        )
        .map((item) => Number(item.valor_medio));

      resultado[codigo] = leituras.length
        ? leituras.reduce((soma, valor) => soma + valor, 0) / leituras.length
        : null;
    });

    return resultado;
  });

  estado.graficoClimaMensalTecnico = new Chart(canvas, {
    type: "line",
    data: {
      labels: dados.map((item) => item.mes),
      datasets: [
        {
          label: "Temperatura (°C)",
          data: dados.map((item) => item.temperatura),
          tension: 0.3,
          borderWidth: 2,
        },
        {
          label: "Chuva (mm)",
          data: dados.map((item) => item.chuva),
          tension: 0.3,
          borderWidth: 2,
        },
        {
          label: "Umidade do ar (%)",
          data: dados.map((item) => item.umidadeAr),
          tension: 0.3,
          borderWidth: 2,
        },
        {
          label: "Umidade do solo (%)",
          data: dados.map((item) => item.umidadeSolo),
          tension: 0.3,
          borderWidth: 2,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

export function carregarGraficoMetricas() {
  const select = document.getElementById("filtro-metrica-tecnico");
  const canvas = document.getElementById("grafico-metricas-tecnico");
  const mensagem = document.getElementById("mensagem-grafico-metricas");
  if (!select || !canvas || typeof Chart === "undefined") return;

  const metricas = [
    ...new Set(
      obterSensores()
        .map((sensor) => sensor.tipo)
        .filter(Boolean),
    ),
  ];
  const atual = select.value;
  const nomes = {
    temperatura: "Temperatura",
    umidadeSolo: "Umidade do solo",
    umidadeAr: "Umidade do ar",
    chuva: "Chuva",
  };
  select.innerHTML = metricas.length
    ? metricas
        .map(
          (metrica) =>
            `<option value="${escaparHtml(metrica)}">${escaparHtml(nomes[metrica] || metrica)}</option>`,
        )
        .join("")
    : '<option value="">Sem métricas</option>';
  if (metricas.includes(atual)) select.value = atual;

  const metricaAtual = select.value;
  const leituras = obterSensores().filter(
    (sensor) =>
      sensor.tipo === metricaAtual &&
      sensor.status !== "Inativo" &&
      sensor.valor !== null &&
      sensor.valor !== undefined &&
      sensor.valor !== "" &&
      Number.isFinite(Number(sensor.valor)),
  );
  if (estado.graficoMetricas) estado.graficoMetricas.destroy();
  estado.graficoMetricas = new Chart(canvas, {
    type: "bar",
    data: {
      labels: leituras.map((sensor) => `${sensor.sensor} (${sensor.unidade || ""})`),
      datasets: [
        {
          label: nomes[metricaAtual] || "Leitura",
          data: leituras.map((sensor) => Number(sensor.valor)),
          backgroundColor: "#2e7d32",
          borderRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } },
    },
  });

  if (mensagem) {
    mensagem.textContent = leituras.length
      ? `${leituras.length} leitura(s) disponível(is) para esta métrica.`
      : "Ainda não há leituras para a métrica selecionada.";
  }

  select.onchange = carregarGraficoMetricas;
}
