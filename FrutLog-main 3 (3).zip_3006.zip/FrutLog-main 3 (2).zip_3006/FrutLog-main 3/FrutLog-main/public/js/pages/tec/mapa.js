import { estado } from "./estado.js";
import { escaparHtml, normalizarClasse, preencherTexto } from "./interface.js";
import { atualizarTalhoesMonitorados } from "./dados.js";
import { atualizarSelectSensoresInspecao, preencherSelectTalhoes } from "./registros.js";

export function obterPontos(feature) {
  return FrutLogTalhoes.obterPontos(feature);
}

export function pontosParaString(pontos) {
  return pontos.map((ponto) => `${ponto[0]},${ponto[1]}`).join(" ");
}

export function carregarTalhoes() {
  const lista = document.getElementById("lista-talhoes");

  atualizarTalhoesMonitorados();
  renderizarBotoesTalhao();
  renderizarMapa();

  if (lista) {
    lista.innerHTML = estado.talhoes.length
      ? estado.talhoes
          .map((feature) => {
            const props = feature.properties;
            return `
        <article class="talhao-card ${normalizarClasse(props.status)}">
          <h3>Talhão ${escaparHtml(props.codigo)}</h3>
          <p><strong>Situação:</strong> ${escaparHtml(FrutLog.textoInterface(props.status))}</p>
          <p><strong>Cultura:</strong> ${escaparHtml(props.produto)} ${escaparHtml(props.variedade)}</p>
          <p><strong>Área:</strong> ${escaparHtml(props.area)}</p>
          <button class="btn-filtro" type="button" data-selecionar-talhao="${escaparHtml(props.codigo)}">Ver no mapa</button>
        </article>
      `;
          })
          .join("")
      : '<article class="tarefa-card"><strong>Nenhum talhão cadastrado</strong><p>Os talhões aparecerão aqui após o cadastro e sincronização.</p></article>';
  }

  ["inspecao-talhao", "ocorrencia-talhao", "problema-sensor-talhao"].forEach((id) =>
    preencherSelectTalhoes(document.getElementById(id)),
  );
  atualizarSelectSensoresInspecao();
}

export function renderizarBotoesTalhao() {
  const botoesTalhao = document.getElementById("botoes-talhao");
  if (!botoesTalhao) return;

  if (!estado.talhoes.some((feature) => feature.properties.codigo === estado.talhaoSelecionadoId)) {
    estado.talhaoSelecionadoId = estado.talhoes[0]?.properties.codigo || null;
  }
  botoesTalhao.innerHTML = estado.talhoes
    .map((feature) => {
      const codigo = feature.properties.codigo;
      const ativo = codigo === estado.talhaoSelecionadoId ? " active" : "";
      return `<button class="btn-talhao${ativo}" type="button" data-talhao="${escaparHtml(codigo)}">${escaparHtml(codigo)}</button>`;
    })
    .join("");
}

export function renderizarMapa() {
  const svgMapa = document.getElementById("camada-talhoes");
  if (!svgMapa) return;

  atualizarTalhoesMonitorados();
  const pendentes = estado.talhoes.filter((feature) => feature.properties.geometriaPendente).length;
  preencherTexto(
    "mensagem-geometria-talhoes",
    !estado.talhoes.length
      ? "Nenhum talhão retornado pelo servidor. Verifique os cadastros e a fazenda vinculada."
      : pendentes
        ? `${pendentes} talhão(es) ainda sem limites desenhados no mapa. A Engenharia pode concluir o desenho.`
        : `${estado.talhoes.length} talhão(es) carregado(s) do servidor.`,
  );

  FrutLogMapaTalhoes.renderizarMapaTalhoes(svgMapa, estado.talhoes, {
    selectedCode: estado.talhaoSelecionadoId,
    statusFor: (feature) => feature.properties.status,
    onSelect: (feature) => selecionarTalhao(feature.properties.codigo),
  });
}

export function selecionarTalhao(idTalhao) {
  atualizarTalhoesMonitorados();
  const talhao = estado.talhoes.find((item) => item.properties.codigo === idTalhao);
  if (!talhao) return;

  estado.talhaoSelecionadoId = idTalhao;
  const props = talhao.properties;
  const monitoramento = props.monitoramento || {};

  document.querySelectorAll(".btn-talhao").forEach((botao) => {
    botao.classList.toggle("active", botao.dataset.talhao === idTalhao);
  });

  document.querySelectorAll(".talhao-mapa").forEach((area) => {
    area.classList.toggle("selecionado", area.dataset.talhao === idTalhao);
  });

  preencherTexto("tecnico-titulo-talhao", `Detalhes: Talhão ${props.codigo}`);
  preencherTexto("tecnico-talhao-produto", props.produto || "--");
  preencherTexto("tecnico-talhao-variedade", props.variedade || "--");
  preencherTexto("tecnico-talhao-area", props.area);
  preencherTexto("tecnico-talhao-solo", props.solo || "--");
  preencherTexto("tecnico-talhao-plantio", props.plantio || "--");
  preencherTexto("tecnico-talhao-colheita", props.colheita || "--");
  preencherTexto("tecnico-talhao-sensor", props.sensor || "Não associado");
  preencherTexto(
    "tecnico-talhao-limite",
    monitoramento.temperaturaMaxima !== null && monitoramento.temperaturaMaxima !== undefined
      ? `${monitoramento.temperaturaMaxima} C`
      : "--",
  );
  preencherTexto(
    "tecnico-talhao-temperatura",
    monitoramento.temperaturaAtual !== null && monitoramento.temperaturaAtual !== undefined
      ? `${monitoramento.temperaturaAtual} C`
      : "--",
  );
  preencherTexto(
    "tecnico-talhao-umidade",
    props.diaria?.umidadeAr
      ? `${props.diaria.umidadeAr}% ar / ${props.diaria.umidadeSolo || "--"}% solo`
      : "--",
  );
  preencherTexto("tecnico-talhao-prioridade", props.prioridade || "Rotina de acompanhamento");

  const badge = document.getElementById("tecnico-talhao-status");
  if (badge) {
    badge.textContent = FrutLog.textoInterface(props.status);
    badge.className = `badge-status ${classeStatusMapa(props.status)}`;
  }
}

export function classeStatusMapa(status) {
  const normalizado = normalizarClasse(status).replace(/\s+/g, "-");
  return ["normal", "atencao", "critico", "sem-leitura"].includes(normalizado)
    ? normalizado
    : "normal";
}

export function configurarMapaTalhoes() {
  document.getElementById("botoes-talhao")?.addEventListener("click", (evento) => {
    const botao = evento.target.closest(".btn-talhao");
    if (botao) selecionarTalhao(botao.dataset.talhao);
  });
  document.getElementById("lista-talhoes")?.addEventListener("click", (evento) => {
    const botao = evento.target.closest("[data-selecionar-talhao]");
    if (botao) selecionarTalhao(botao.dataset.selecionarTalhao);
  });
}
