import { estado } from "./estado.js";
import { configurarAbas, dataLocalISO, exibirMensagem, verificarSessao } from "./interface.js";
import {
  carregarAlertas,
  carregarHistoricoInspecoes,
  carregarHistoricoOcorrencias,
  carregarHistoricoProblemasSensores,
  carregarSensores,
  carregarTarefasDia,
  configurarFormularios,
  configurarRelatorioDiario,
} from "./registros.js";
import { carregarPainelTecnico } from "./dados.js";
import { carregarGraficoMetricas, carregarTelemetriaDiaria } from "./telemetria.js";
import { carregarTalhoes, configurarMapaTalhoes, selecionarTalhao } from "./mapa.js";

document.addEventListener("DOMContentLoaded", async () => {
  verificarSessao();
  FrutLog.configurarLogout();
  configurarAbas();
  configurarRelatorioDiario();
  document.getElementById("relatorio-data").value = dataLocalISO();
  if (FrutLog.AUTENTICACAO_API_ATIVA) {
    try {
      await carregarPainelTecnico();
      await carregarTelemetriaDiaria();
    } catch (erro) {
      console.error("Falha ao carregar o painel do técnico:", erro);
      exibirMensagem("mensagem-dados-tecnicos", erro.message, "erro");
    }
  }
  carregarTalhoes();
  configurarMapaTalhoes();
  carregarTarefasDia();
  carregarHistoricoInspecoes();
  carregarHistoricoOcorrencias();
  carregarSensores();
  carregarHistoricoProblemasSensores();
  carregarAlertas();
  carregarGraficoMetricas();
  configurarFormularios();
  selecionarTalhao(estado.talhoes[0]?.properties.codigo || "");

  if (FrutLog.AUTENTICACAO_API_ATIVA) {
    window.setInterval(async () => {
      try {
        await carregarPainelTecnico();
        await carregarTelemetriaDiaria();
        carregarTalhoes();
        carregarTarefasDia();
        carregarHistoricoInspecoes();
        carregarHistoricoOcorrencias();
        carregarSensores();
        carregarHistoricoProblemasSensores();
        carregarAlertas();
        carregarGraficoMetricas();
        selecionarTalhao(
          document.querySelector(".btn-talhao.active")?.dataset.talhao ||
            estado.talhoes[0]?.properties.codigo,
        );
      } catch (erro) {
        console.error("Falha ao sincronizar o painel do técnico:", erro);
        exibirMensagem("mensagem-dados-tecnicos", erro.message, "erro");
      }
    }, 15000);
  }
  window.addEventListener("frutlog:talhoes-atualizados", async () => {
    try {
      await carregarPainelTecnico();
      carregarTalhoes();
      carregarTarefasDia();
      selecionarTalhao(
        document.querySelector(".btn-talhao.active")?.dataset.talhao ||
          estado.talhoes[0]?.properties.codigo,
      );
    } catch (erro) {
      exibirMensagem("mensagem-dados-tecnicos", erro.message, "erro");
    }
  });
  window.addEventListener("focus", () => {
    if (FrutLog.AUTENTICACAO_API_ATIVA) {
      window.dispatchEvent(new Event("frutlog:talhoes-atualizados"));
    }
  });
});
