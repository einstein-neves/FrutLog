import { estado } from "./estado.js";
import { exibirMensagem } from "./interface.js";
import { preencherSelectTalhoes } from "./sensores.js";

export function renderizarMapaAdmin() {
  if (window.FrutLogEditorAdmin?.ativo()) return;
  const mapa = document.getElementById("mapa-talhoes-admin");
  if (!mapa || typeof FrutLogTalhoes === "undefined") return;
  const features = FrutLogTalhoes.obterTalhoes();
  const estados = new Map(
    (estado.painelTecnico.talhoes || []).map((item) => [item.id, item.situacao || item.status]),
  );
  exibirMensagem(
    "mensagem-mapa-admin",
    features.length
      ? `${features.length} talhão(es) carregado(s) do servidor.`
      : "Nenhum talhão retornado pelo servidor. Verifique os cadastros e a fazenda vinculada.",
  );
  const renderizados = FrutLogMapaTalhoes.renderizarMapaTalhoes(mapa, features, {
    statusFor: (feature) => estados.get(feature.properties.codigo) || feature.properties.status,
    onSelect: (feature, evento, poligono) => {
      const codigo = feature.properties.codigo;
      mapa
        .querySelectorAll(".talhao-mapa")
        .forEach((item) => item.classList.toggle("selecionado", item === poligono));
      const dados = (estado.painelTecnico.talhoes || []).find((item) => item.id === codigo);
      exibirMensagem(
        "mensagem-dados-tecnicos",
        dados
          ? `Talhão ${codigo}: ${dados.situacao || "sem situacao"}; leitura ${dados.leitura || "indisponivel"}.`
          : `Talhão ${codigo} selecionado.`,
      );
    },
  });
  exibirMensagem(
    "mensagem-mapa-admin",
    renderizados
      ? `${renderizados} divisão(oes) de talhão renderizada(s) com dados do servidor.`
      : "Os talhões foram carregados, mas nenhum possui coordenadas validas para desenhar.",
  );
}

export async function carregarMapaAdmin() {
  if (window.FrutLogEditorAdmin?.ativo()) return;
  await FrutLogMapaTalhoes.carregarMapaTalhoes("admin");
  preencherSelectTalhoes();
  renderizarMapaAdmin();
}
