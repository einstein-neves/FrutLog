import { estado } from "./estado.js";
import { escaparHtml, formatarData, preencherTabela } from "./interface.js";

export function renderizarTelemetriaDiariaAdmin() {
  const metricas = {
    temperatura: "Temperatura",
    umidadeAr: "Umidade do ar",
    umidadeSolo: "Umidade do solo",
    chuva: "Chuva",
  };
  preencherTabela(
    "tabela-telemetria-admin",
    7,
    estado.telemetriaDiariaAdmin.map(
      (item) => `
    <tr>
      <td>${formatarData(item.dia)}</td>
      <td>${escaparHtml(item.talhao || "--")}</td>
      <td>${escaparHtml(metricas[item.codigo_metrica] || item.codigo_metrica)}</td>
      <td>${escaparHtml(item.valor_medio)}</td>
      <td>${escaparHtml(item.valor_minimo)}</td>
      <td>${escaparHtml(item.valor_maximo)}</td>
      <td>${escaparHtml(item.leituras_contabilizadas)}</td>
    </tr>
  `,
    ),
  );
}

export function configurarGraficos() {
  document.querySelectorAll("[data-unidade-admin]").forEach((botao) => {
    botao.addEventListener("click", () => {
      estado.unidadeColheita = botao.dataset.unidadeAdmin;
      document
        .querySelectorAll("[data-unidade-admin]")
        .forEach((item) => item.classList.toggle("active", item === botao));
      renderizarGraficoColheita();
    });
  });
  renderizarGraficoClima();
}

export function definirColheitasAnuais(colheitas) {
  estado.colheitasAnuais = Array.isArray(colheitas) ? colheitas : [];
  if (
    estado.colheitasAnuais.length &&
    !estado.colheitasAnuais.some((item) => item.unidade === estado.unidadeColheita)
  ) {
    estado.unidadeColheita = estado.colheitasAnuais[0].unidade;
    document.querySelectorAll("[data-unidade-admin]").forEach((botao) => {
      botao.classList.toggle("active", botao.dataset.unidadeAdmin === estado.unidadeColheita);
    });
  }
}

export function renderizarGraficoColheita() {
  const canvas = document.getElementById("grafico-colheita-anual");
  if (!canvas || typeof Chart === "undefined") return;
  if (estado.graficoColheita) estado.graficoColheita.destroy();
  const dados = estado.colheitasAnuais.filter((item) => item.unidade === estado.unidadeColheita);
  const unidadeLabel = { t: "Toneladas", sc: "Sacas", kg: "Quilogramas", cx: "Caixas" };
  const unidade = unidadeLabel[estado.unidadeColheita] || estado.unidadeColheita;
  const mensagem = document.getElementById("mensagem-colheita-admin");
  if (!dados.length) {
    estado.graficoColheita = null;
    if (mensagem) mensagem.textContent = "Ainda não há registros de colheita para esta unidade.";
    ["resumo-colheita-ultima", "resumo-colheita-menor", "resumo-colheita-maior"].forEach((id) => {
      document.getElementById(id).textContent = "--";
    });
    return;
  }
  if (mensagem) mensagem.textContent = "";

  estado.graficoColheita = new Chart(canvas, {
    type: "bar",
    data: {
      labels: dados.map((item) => item.ano),
      datasets: [
        {
          label: unidade[0].toUpperCase() + unidade.slice(1),
          data: dados.map((item) => item.quantidade),
          backgroundColor: "#2e7d32",
          borderRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } },
    },
  });

  const menor = dados.reduce((a, b) => (a.quantidade < b.quantidade ? a : b));
  const maior = dados.reduce((a, b) => (a.quantidade > b.quantidade ? a : b));
  const ultima = dados.reduce((a, b) => (a.ano > b.ano ? a : b));
  document.getElementById("resumo-colheita-ultima").textContent =
    `${ultima.ano}: ${ultima.quantidade} ${unidade}`;
  document.getElementById("resumo-colheita-menor").textContent =
    `${menor.ano}: ${menor.quantidade} ${unidade}`;
  document.getElementById("resumo-colheita-maior").textContent =
    `${maior.ano}: ${maior.quantidade} ${unidade}`;
}

export function renderizarGraficoLeituras() {
  const canvas = document.getElementById("grafico-leituras-sensores");
  if (!canvas || typeof Chart === "undefined") return;
  const dados = estado.sensores.filter(
    (item) =>
      item.ativo !== false &&
      item.valor !== null &&
      item.valor !== undefined &&
      item.valor !== "" &&
      Number.isFinite(Number(item.valor)),
  );
  if (estado.graficoLeituras) estado.graficoLeituras.destroy();
  estado.graficoLeituras = new Chart(canvas, {
    type: "bar",
    data: {
      labels: dados.map((item) => item.sensor || item.id_externo),
      datasets: [
        {
          label: "Última leitura",
          data: dados.map((item) => Number(item.valor)),
          backgroundColor: "#1976d2",
          borderRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } },
    },
  });
}

export function renderizarGraficoClima() {
  const canvas = document.getElementById("grafico-clima-mensal");

  if (!canvas || typeof Chart === "undefined") {
    return;
  }

  if (estado.graficoClima) {
    estado.graficoClima.destroy();
  }

  const nomesMeses = [
    "Jan",
    "Fev",
    "Mar",
    "Abr",
    "Mai",
    "Jun",
    "Jul",
    "Ago",
    "Set",
    "Out",
    "Nov",
    "Dez",
  ];

  const dadosMensais = [...estado.telemetriaMensalAdmin, ...estado.telemetriaMensalEsp32];

  // "2026-10" -> "Out/2026"
  const rotuloMes = (mes) => {
    const [ano, numero] = String(mes).split("-");
    return `${nomesMeses[Number(numero) - 1] || numero}/${ano}`;
  };

  // Consolidado mensal vindo da API (os valores diarios do ESP32 ja foram agrupados por mes).
  const meses = [...new Set(dadosMensais.map((item) => item.mes).filter(Boolean))].sort();

  // Media do mes para a metrica (media entre as fontes/talhoes que mediram naquele mes).
  const mediaDoMes = (mes, codigo) => {
    const valores = dadosMensais
      .filter(
        (item) =>
          item.mes === mes &&
          item.codigo_metrica === codigo &&
          Number.isFinite(Number(item.valor_medio)),
      )
      .map((item) => Number(item.valor_medio));

    return valores.length
      ? Number((valores.reduce((soma, valor) => soma + valor, 0) / valores.length).toFixed(2))
      : null;
  };

  const serie = (codigo) => meses.map((mes) => mediaDoMes(mes, codigo));

  estado.graficoClima = new Chart(canvas, {
    type: "line",
    data: {
      labels: meses.map(rotuloMes),

      datasets: [
        {
          label: "Temperatura (°C)",
          data: serie("temperatura"),
          borderColor: "#c62828",
          backgroundColor: "rgba(198, 40, 40, 0.12)",
          tension: 0.35,
          spanGaps: true,
        },
        {
          label: "Chuva (mm)",
          data: serie("chuva"),
          borderColor: "#f9a825",
          backgroundColor: "rgba(249, 168, 37, 0.12)",
          tension: 0.35,
          spanGaps: true,
        },
        {
          label: "Umidade do ar (%)",
          data: serie("umidadeAr"),
          borderColor: "#1565c0",
          backgroundColor: "rgba(21, 101, 192, 0.12)",
          tension: 0.35,
          spanGaps: true,
        },
        {
          label: "Umidade do solo (%)",
          data: serie("umidadeSolo"),
          borderColor: "#388e3c",
          backgroundColor: "rgba(56, 142, 60, 0.12)",
          tension: 0.35,
          spanGaps: true,
        },
      ],
    },

    options: {
      responsive: true,
      maintainAspectRatio: false,

      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

export async function carregarEsp32Mensal() {
  try {
    const resposta = await FrutLog.apiFetch("/telemetria/esp32-mensal");
    estado.telemetriaMensalEsp32 = resposta.mensal || [];
    renderizarGraficoClima();
  } catch (erro) {
    console.error("ESP32 mensal:", erro.message);
  }
}
