// Estado exclusivo deste painel, compartilhado pelos seus módulos.
export const estado = {};

estado.funcionarios = [];

estado.sensores = [];

estado.colheitasAnuais = [];

estado.painelTecnico = {
  talhoes: [],
  inspecoes: [],
  plantios: [],
  ocorrencias: [],
  problemasSensores: [],
  tarefas: [],
  alertas: [],
};

estado.graficoColheita = null;

estado.graficoLeituras = null;

estado.unidadeColheita = "t";

estado.graficoClima = null;

estado.telemetriaDiariaAdmin = [];

estado.telemetriaMensalAdmin = [];

estado.telemetriaMensalEsp32 = [];
