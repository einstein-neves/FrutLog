import { estado } from "./estado.js";
import {
  escaparHtml,
  exibirMensagem,
  formatarData,
  mostrarLinhasVazias,
  normalizarStatus,
  preencherTabela,
} from "./interface.js";
import { preencherSelectTalhoes, renderizarSensores } from "./sensores.js";
import { renderizarFuncionarios } from "./funcionarios.js";
import {
  carregarEsp32Mensal,
  definirColheitasAnuais,
  renderizarGraficoClima,
  renderizarGraficoColheita,
  renderizarTelemetriaDiariaAdmin,
} from "./telemetria.js";
import { carregarMapaAdmin, renderizarMapaAdmin } from "./mapa.js";

export function renderizarPainelTecnico() {
  const talhoes = estado.painelTecnico.talhoes || [];
  const inspecoes = estado.painelTecnico.inspecoes || [];
  const plantios = estado.painelTecnico.plantios || [];
  const ocorrencias = estado.painelTecnico.ocorrencias || [];
  const problemas =
    estado.painelTecnico.problemasSensores || estado.painelTecnico.problemas_sensores || [];
  const tarefas = estado.painelTecnico.tarefas || [];
  const alertas = estado.painelTecnico.alertas || [];

  document.getElementById("resumo-total-talhoes").textContent = talhoes.length;
  document.getElementById("resumo-total-sensores").textContent =
    estado.sensores.length || (estado.painelTecnico.sensores || []).length;
  document.getElementById("resumo-total-inspecoes").textContent = inspecoes.length;
  document.getElementById("resumo-total-tarefas").textContent = tarefas.length;
  document.getElementById("resumo-total-alertas").textContent = alertas.length;

  preencherTabela(
    "tabela-talhoes-admin",
    7,
    talhoes.map(
      (talhao) => `
    <tr>
      <td>${escaparHtml(talhao.id || talhao.talhao)}</td>
      <td>${escaparHtml(talhao.cultura || talhao.produto || "--")}</td>
      <td>${escaparHtml(talhao.area || "--")}</td>
      <td>${escaparHtml(talhao.sensor || "--")}</td>
      <td>${escaparHtml(talhao.leitura || "--")}</td>
      <td><span class="badge-status ${normalizarStatus(talhao.situacao || talhao.status)}">${escaparHtml(FrutLog.textoInterface(talhao.situacao || talhao.status || "--"))}</span></td>
      <td>${escaparHtml(FrutLog.textoInterface(talhao.prioridade || "--"))}</td>
    </tr>`,
    ),
  );
  preencherTabela(
    "tabela-inspecoes-admin",
    6,
    inspecoes.map(
      (item) => `
    <tr><td>${formatarData(item.data)}</td><td>${escaparHtml(item.talhao)}</td>
      <td>${escaparHtml(item.sensor || "--")}</td>
      <td><span class="badge-status ${normalizarStatus(item.situacao)}">${escaparHtml(FrutLog.textoInterface(item.situacao))}</span></td>
      <td>${escaparHtml(item.problemas || "Sem ocorrência")}</td><td>${escaparHtml(item.observacoes || "--")}</td></tr>`,
    ),
  );
  preencherTabela(
    "tabela-plantios-admin",
    5,
    plantios.map(
      (item) => `
    <tr><td>${escaparHtml(item.talhao || item.talhao_id || "--")}</td>
      <td>${escaparHtml([item.produto || item.cultura, item.variedade].filter(Boolean).join(" / ") || "--")}</td>
      <td>${escaparHtml(item.area ?? item.area_plantada_hectares ?? "--")}</td>
      <td>${formatarData(item.dataPlantio || item.plantado_em)}</td>
      <td>${formatarData(item.dataColheita || item.previsao_colheita)}</td></tr>`,
    ),
  );
  preencherTabela(
    "tabela-ocorrencias-admin",
    4,
    ocorrencias.map(
      (item) => `
    <tr><td>${formatarData(item.data)}</td><td>${escaparHtml(item.talhao)}</td>
      <td>${escaparHtml(item.tipo)}</td><td>${escaparHtml(item.observacao || "--")}</td></tr>`,
    ),
  );
  preencherTabela(
    "tabela-problemas-admin",
    5,
    problemas.map(
      (item) => `
    <tr><td>${formatarData(item.data)}</td><td>${escaparHtml(item.sensor || "--")}</td>
      <td>${escaparHtml(item.talhao || "--")}</td><td>${escaparHtml(item.problema)}</td>
      <td>${escaparHtml(item.observacao || "--")}</td></tr>`,
    ),
  );

  const linhasAlertas = [
    ...tarefas.map(
      (item) =>
        `<tr><td>${escaparHtml(item.talhao || "--")}</td><td>${escaparHtml(FrutLog.textoInterface(item.prioridade || "Tarefa"))}</td><td>${escaparHtml(item.atividade || "--")}</td><td>Pendente</td></tr>`,
    ),
    ...alertas.map(
      (item) =>
        `<tr><td>${escaparHtml(item.titulo || item.talhao || "--")}</td><td>${escaparHtml(FrutLog.textoInterface(item.severidade || item.nivel || "--"))}</td><td>${escaparHtml(item.mensagem || item.texto || item.titulo || "--")}</td><td>${escaparHtml(FrutLog.textoInterface(item.status || "Aberto"))}</td></tr>`,
    ),
  ];
  preencherTabela("tabela-alertas-admin", 4, linhasAlertas);
  preencherSelectTalhoes();
}

export async function carregarDadosConectados() {
  const resultados = await Promise.allSettled([
    FrutLog.apiFetch("/funcionarios"),
    FrutLog.apiFetch("/sensores"),
    FrutLog.apiFetch("/painel-tecnico"),
    FrutLog.apiFetch("/colheitas/anual"),
    FrutLog.apiFetch("/telemetria/diaria"),
  ]);
  const erros = [];

  if (resultados[0].status === "fulfilled") {
    estado.funcionarios = resultados[0].value.usuarios || [];
    renderizarFuncionarios();
  } else {
    erros.push(`Funcionários: ${resultados[0].reason.message}`);
    mostrarLinhasVazias("tabela-funcionarios", 7, "Falha ao carregar funcionários.");
  }

  if (resultados[1].status === "fulfilled") {
    estado.sensores = resultados[1].value.sensores || [];
    renderizarSensores();
    renderizarGraficoClima();
  } else {
    erros.push(`Sensores: ${resultados[1].reason.message}`);
    mostrarLinhasVazias("tabela-sensores-admin", 6, "Falha ao carregar sensores.");
  }

  if (resultados[2].status === "fulfilled") {
    estado.painelTecnico = resultados[2].value;
    renderizarPainelTecnico();
  } else {
    erros.push(`Dados de campo: ${resultados[2].reason.message}`);
    exibirMensagem("mensagem-dados-tecnicos", resultados[2].reason.message, "erro");
  }

  if (resultados[3].status === "fulfilled") {
    definirColheitasAnuais(resultados[3].value.colheitas);
  } else {
    erros.push(`Colheitas: ${resultados[3].reason.message}`);
  }
  if (resultados[4].status === "fulfilled") {
    estado.telemetriaDiariaAdmin = resultados[4].value.leituras || [];
    estado.telemetriaMensalAdmin = resultados[4].value.mensal || [];
    renderizarTelemetriaDiariaAdmin();
    renderizarGraficoClima();
  } else {
    erros.push(`Telemetria diária: ${resultados[4].reason.message}`);
    mostrarLinhasVazias("tabela-telemetria-admin", 7, "Falha ao carregar telemetria diária.");
  }

  renderizarGraficoColheita();
  renderizarGraficoClima();
  if (erros.length) {
    exibirMensagem("mensagem-carregamento-admin", erros.join(" | "), "erro");
  } else {
    exibirMensagem("mensagem-carregamento-admin", "Dados atualizados do servidor.", "sucesso");
  }

  if (!window.sincronizacaoAdminIniciada) {
    carregarEsp32Mensal();
    window.sincronizacaoAdminIniciada = true;
    window.setInterval(atualizarDadosCampoConectados, 15000);
  }
}

export async function atualizarDadosCampoConectados() {
  const resultados = await Promise.allSettled([
    FrutLog.apiFetch("/painel-tecnico"),
    FrutLog.apiFetch("/sensores"),
    FrutLog.apiFetch("/colheitas/anual"),
    FrutLog.apiFetch("/telemetria/diaria"),
    carregarMapaAdmin(),
  ]);
  const erros = [];

  if (resultados[0].status === "fulfilled") {
    estado.painelTecnico = resultados[0].value;
    renderizarPainelTecnico();
    renderizarMapaAdmin();
  } else {
    erros.push(`Dados de campo: ${resultados[0].reason.message}`);
  }

  if (resultados[1].status === "fulfilled") {
    estado.sensores = resultados[1].value.sensores || [];
    renderizarSensores();
    renderizarGraficoClima();
  } else {
    erros.push(`Sensores: ${resultados[1].reason.message}`);
  }

  if (resultados[2].status === "fulfilled") {
    definirColheitasAnuais(resultados[2].value.colheitas);
    renderizarGraficoColheita();
  } else {
    erros.push(`Colheitas: ${resultados[2].reason.message}`);
  }

  if (resultados[3].status === "fulfilled") {
    estado.telemetriaDiariaAdmin = resultados[3].value.leituras || [];
    estado.telemetriaMensalAdmin = resultados[3].value.mensal || [];
    renderizarTelemetriaDiariaAdmin();
    renderizarGraficoClima();
  } else {
    erros.push(`Telemetria diária: ${resultados[3].reason.message}`);
  }

  if (resultados[4].status === "rejected") {
    erros.push(`Geometrias: ${resultados[4].reason.message}`);
  }

  if (erros.length) {
    console.error("Falha ao sincronizar dados operacionais:", erros.join(" | "));
    exibirMensagem("mensagem-carregamento-admin", erros.join(" | "), "erro");
  } else {
    exibirMensagem("mensagem-carregamento-admin", "Dados atualizados do servidor.", "sucesso");
  }
}
