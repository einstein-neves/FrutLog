import { estado } from "./estado.js";
import {
  escaparHtml,
  exibirMensagem,
  mostrarLinhasVazias,
} from "./interface.js";
import { renderizarSensores } from "./sensores.js";
import { renderizarGraficoLeituras } from "./telemetria.js";

export function gerarSenhaTemporaria() {
  const caracteres =
    "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%";
  const limiteSemVies = 256 - (256 % caracteres.length);
  let senha = "";
  while (senha.length < 10) {
    const bytes = window.crypto.getRandomValues(new Uint8Array(16));
    for (const byte of bytes) {
      if (byte < limiteSemVies) senha += caracteres[byte % caracteres.length];
      if (senha.length === 10) break;
    }
  }
  return senha;
}

export function configurarFormularioFuncionario() {
  const formulario = document.getElementById("form-funcionario");
  const campoId = document.getElementById("funcionario-id");
  const campoMatricula = document.getElementById("funcionario-matricula");
  const campoSenha = document.getElementById("funcionario-senha");
  const botaoGerarSenha = document.getElementById("btn-gerar-senha");
  const botaoMostrarSenha = document.getElementById("btn-mostrar-senha");
  const botaoCopiarSenha = document.getElementById("btn-copiar-senha");
  const botaoSalvar = document.getElementById("btn-salvar-funcionario");
  const botaoCancelar = document.getElementById(
    "btn-cancelar-edicao-funcionario",
  );

  if (campoMatricula) {
    campoMatricula.value = "Gerada ao cadastrar";
    campoMatricula.required = false;
  }
  if (campoSenha) {
    campoSenha.value = gerarSenhaTemporaria();
    campoSenha.type = "text";
  }
  botaoGerarSenha?.addEventListener("click", () => {
    if (campoSenha) campoSenha.value = gerarSenhaTemporaria();
  });
  botaoMostrarSenha?.addEventListener("click", () => {
    const mostrar = campoSenha.type === "password";
    campoSenha.type = mostrar ? "text" : "password";
    botaoMostrarSenha.textContent = mostrar ? "Ocultar senha" : "Mostrar senha";
  });
  botaoCopiarSenha?.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(campoSenha.value);
      exibirMensagem(
        "mensagem-funcionario",
        "Senha provisória copiada.",
        "sucesso",
      );
    } catch (erro) {
      exibirMensagem(
        "mensagem-funcionario",
        `Não foi possível copiar a senha: ${erro.message}`,
        "erro",
      );
    }
  });
  botaoCancelar?.addEventListener("click", () => {
    formulario.reset();
    campoId.value = "";
    campoMatricula.value = "Gerada ao cadastrar";
    campoSenha.required = true;
    campoSenha.type = "text";
    botaoMostrarSenha.textContent = "Ocultar senha";
    campoSenha.placeholder = "8 a 10 caracteres";
    campoSenha.value = gerarSenhaTemporaria();
    botaoCancelar.hidden = true;
    botaoSalvar.innerHTML =
      '<i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Cadastrar Funcionário';
    exibirMensagem("mensagem-funcionario", "");
  });

  formulario?.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    const dados = Object.fromEntries(new FormData(formulario));
    const mensagemId = "mensagem-funcionario";

    const editando = Boolean(dados.id);
    const senhaProvisoriaUsada = dados.senha;
    if (
      (!editando || dados.senha) &&
      (typeof dados.senha !== "string" ||
        dados.senha.length < 8 ||
        dados.senha.length > 10)
    ) {
      exibirMensagem(
        mensagemId,
        "A senha provisória deve possuir entre 8 e 10 caracteres.",
        "erro",
      );
      campoSenha?.focus();
      return;
    }

    const botao = formulario.querySelector('[type="submit"]');
    if (botao) botao.disabled = true;
    try {
      const payload = {
        nome: dados.nome,
        cargo: dados.cargo,
        ...(dados.profissao === undefined
          ? {}
          : { profissao: dados.profissao }),
        perfil: dados.perfil,
        status: dados.status,
      };
      if (dados.senha) payload.senha = dados.senha;
      if (editando) {
        await FrutLog.apiFetch(
          `/funcionarios/${encodeURIComponent(dados.id)}`,
          {
            method: "PUT",
            body: JSON.stringify(payload),
          },
        );
        estado.funcionarios = estado.funcionarios.map((item) =>
          String(item.id) === String(dados.id)
            ? {
                ...item,
                ...payload,
                status: payload.status,
                ativo: payload.status === "ativo",
              }
            : item,
        );
        exibirMensagem(mensagemId, "Funcionário atualizado.", "sucesso");
      } else {
        const resposta = await FrutLog.apiFetch("/funcionarios", {
          method: "POST",
          body: JSON.stringify({ ...payload, senha: dados.senha }),
        });
        const novoFuncionario = {
          id: resposta.id,
          matricula: resposta.matricula,
          nome: dados.nome,
          cargo: dados.cargo,
          profissao: dados.profissao,
          perfil: dados.perfil,
          status: dados.status,
          ativo: dados.status === "ativo",
        };
        estado.funcionarios.push(novoFuncionario);
        exibirMensagem(
          mensagemId,
          `Funcionário cadastrado. Matrícula: ${novoFuncionario.matricula}. A senha deverá ser alterada no primeiro acesso.`,
          "sucesso",
        );
      }
      renderizarFuncionarios();
      formulario.reset();
      campoId.value = "";
      campoMatricula.value = "Gerada ao cadastrar";
      campoSenha.required = true;
      campoSenha.placeholder = "8 a 10 caracteres";
      campoSenha.value = editando
        ? gerarSenhaTemporaria()
        : senhaProvisoriaUsada;
      campoSenha.type = "text";
      botaoMostrarSenha.textContent = "Ocultar senha";
      botaoCancelar.hidden = true;
      botaoSalvar.innerHTML =
        '<i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Cadastrar Funcionário';
      if (!editando) {
        exibirMensagem(
          mensagemId,
          "Funcionário cadastrado. A senha provisória usada continua visivel abaixo para ser copiada; o funcionário deverá altera-la no primeiro acesso.",
          "sucesso",
        );
      }
    } catch (erro) {
      exibirMensagem(mensagemId, erro.message, "erro");
    } finally {
      if (botao) botao.disabled = false;
    }
  });
}

export function carregarFuncionarios() {
  const tabela = document.getElementById("tabela-funcionarios");
  if (!tabela) return;
  const termo =
    document
      .getElementById("filtro-funcionarios")
      ?.value.trim()
      .toLocaleLowerCase("pt-BR") || "";
  const statusFiltro =
    document.getElementById("filtro-status-funcionarios")?.value || "todos";
  const filtrados = estado.funcionarios.filter((funcionario) => {
    const ativo = funcionario.status
      ? funcionario.status === "ativo"
      : funcionario.ativo === true;
    const combinaStatus =
      statusFiltro === "todos" || (statusFiltro === "ativo" ? ativo : !ativo);
    const texto = [
      funcionario.matricula,
      funcionario.nome,
      funcionario.cargo,
      funcionario.profissao,
      funcionario.perfil,
    ]
      .join(" ")
      .toLocaleLowerCase("pt-BR");
    return combinaStatus && texto.includes(termo);
  });

  if (!filtrados.length) {
    mostrarLinhasVazias("tabela-funcionarios", 7);
    return;
  }

  tabela.innerHTML = filtrados
    .map((funcionario) => {
      const ativo = funcionario.status
        ? funcionario.status === "ativo"
        : funcionario.ativo === true;
      const status = ativo ? "ativo" : funcionario.status || "inativo";
      const textoStatus =
        status === "excluido" ? "Excluido" : ativo ? "Ativo" : "Inativo";
      return `
      <tr>
        <td>${escaparHtml(funcionario.matricula)}</td>
        <td>${escaparHtml(funcionario.nome)}</td>
        <td>${escaparHtml(funcionario.cargo)}</td>
        <td>${escaparHtml(funcionario.profissao || "--")}</td>
        <td>${escaparHtml(FrutLog.textoInterface(funcionario.perfil))}</td>
        <td><span class="badge-status ${status}">${textoStatus}</span></td>
        <td>
          <button class="btn-acao-admin" type="button" data-alternar-funcionario="${escaparHtml(funcionario.id)}" ${String(funcionario.id) === String(FrutLog.obterSessao()?.id) ? "disabled" : ""} aria-label="${ativo ? "Desativar" : "Ativar"} ${escaparHtml(funcionario.nome)}">${ativo ? "Desativar" : "Ativar"}</button>
          <button class="btn-acao-admin" type="button" data-editar-funcionario="${escaparHtml(funcionario.id)}" ${String(funcionario.id) === String(FrutLog.obterSessao()?.id) ? "disabled" : ""} aria-label="Editar ${escaparHtml(funcionario.nome)}">Editar</button>
          <button class="btn-acao-admin btn-excluir-admin" type="button" data-excluir-funcionario="${escaparHtml(funcionario.id)}" ${String(funcionario.id) === String(FrutLog.obterSessao()?.id) ? "disabled" : ""} aria-label="Excluir ${escaparHtml(funcionario.nome)}">Excluir</button>
        </td>
      </tr>`;
    })
    .join("");
}

export function configurarFiltrosFuncionarios() {
  document
    .getElementById("filtro-funcionarios")
    ?.addEventListener("input", carregarFuncionarios);
  document
    .getElementById("filtro-status-funcionarios")
    ?.addEventListener("change", carregarFuncionarios);
}

export function configurarAcoesTabelas() {
  document
    .getElementById("tabela-funcionarios")
    ?.addEventListener("click", async (evento) => {
      const botaoStatus = evento.target.closest("[data-alternar-funcionario]");
      if (botaoStatus) {
        const id = botaoStatus.dataset.alternarFuncionario;
        const funcionario = estado.funcionarios.find(
          (item) => String(item.id) === String(id),
        );
        if (!funcionario) return;

        const status = (
          funcionario.status
            ? funcionario.status === "ativo"
            : funcionario.ativo === true
        )
          ? "inativo"
          : "ativo";
        botaoStatus.disabled = true;
        try {
          await FrutLog.apiFetch(`/funcionarios/${encodeURIComponent(id)}`, {
            method: "PATCH",
            body: JSON.stringify({ status }),
          });
          estado.funcionarios = estado.funcionarios.map((item) =>
            String(item.id) === String(id)
              ? { ...item, status, ativo: status === "ativo" }
              : item,
          );
          renderizarFuncionarios();
          exibirMensagem(
            "mensagem-funcionario",
            `Funcionário ${status === "ativo" ? "ativado" : "desativado"}.`,
            "sucesso",
          );
        } catch (erro) {
          botaoStatus.disabled = false;
          exibirMensagem("mensagem-funcionario", erro.message, "erro");
        }
        return;
      }

      const botaoEditar = evento.target.closest("[data-editar-funcionario]");
      if (botaoEditar) {
        const funcionario = estado.funcionarios.find(
          (item) => String(item.id) === botaoEditar.dataset.editarFuncionario,
        );
        if (!funcionario) return;
        document.getElementById("funcionario-id").value = funcionario.id;
        document.getElementById("funcionario-matricula").value =
          funcionario.matricula;
        document.getElementById("funcionario-nome").value = funcionario.nome;
        document.getElementById("funcionario-cargo").value = funcionario.cargo;
        const campoProfissao = document.getElementById("funcionario-profissao");
        if (campoProfissao) campoProfissao.value = funcionario.profissao || "";
        document.getElementById("funcionario-perfil").value =
          funcionario.perfil;
        document.getElementById("funcionario-status").value =
          funcionario.status || (funcionario.ativo ? "ativo" : "inativo");
        document.getElementById("funcionario-senha").value = "";
        document.getElementById("funcionario-senha").required = false;
        document.getElementById("funcionario-senha").type = "text";
        document.getElementById("btn-mostrar-senha").textContent =
          "Ocultar senha";
        document.getElementById("funcionario-senha").placeholder =
          "Deixe vazio para manter a senha atual";
        document.getElementById("btn-cancelar-edicao-funcionario").hidden =
          false;
        document.getElementById("btn-salvar-funcionario").innerHTML =
          '<i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Salvar Alteracoes';
        exibirMensagem(
          "mensagem-funcionario",
          "Opcionalmente, defina uma nova senha provisória; o funcionário precisara troca-la no próximo acesso.",
        );
        document
          .getElementById("form-funcionario")
          .scrollIntoView({ behavior: "smooth", block: "start" });
        return;
      }
      const botao = evento.target.closest("[data-excluir-funcionario]");
      if (!botao) return;
      const id = botao.dataset.excluirFuncionario;
      const funcionario = estado.funcionarios.find(
        (item) => String(item.id) === String(id),
      );
      if (
        !funcionario ||
        !window.confirm(
          `Excluir ${funcionario.nome} do sistema? Esta ação não pode ser desfeita.`,
        )
      )
        return;

      botao.disabled = true;
      try {
        await FrutLog.apiFetch(`/funcionarios/${encodeURIComponent(id)}`, {
          method: "DELETE",
        });
        estado.funcionarios = estado.funcionarios.filter(
          (item) => String(item.id) !== String(id),
        );
        renderizarFuncionarios();
        exibirMensagem(
          "mensagem-funcionario",
          "Funcionário excluido.",
          "sucesso",
        );
      } catch (erro) {
        botao.disabled = false;
        exibirMensagem("mensagem-funcionario", erro.message, "erro");
      }
    });

  document
    .getElementById("tabela-sensores-admin")
    ?.addEventListener("click", async (evento) => {
      const botaoAlternar = evento.target.closest("[data-alternar-sensor]");
      if (botaoAlternar) {
        const id = botaoAlternar.dataset.alternarSensor;
        const sensor = estado.sensores.find(
          (item) => String(item.id) === String(id),
        );
        if (!sensor) return;
        botaoAlternar.disabled = true;
        try {
          await FrutLog.apiFetch(`/sensores/${encodeURIComponent(id)}`, {
            method: "PATCH",
            body: JSON.stringify({
              status: sensor.ativo ? "inativo" : "ativo",
            }),
          });
          const resposta = await FrutLog.apiFetch("/sensores");
          estado.sensores = resposta.sensores || [];
          renderizarSensores();
          renderizarGraficoLeituras();
          exibirMensagem(
            "mensagem-sensor",
            `Sensor ${sensor.ativo ? "desativado" : "ativado"}.`,
            "sucesso",
          );
        } catch (erro) {
          botaoAlternar.disabled = false;
          exibirMensagem("mensagem-sensor", erro.message, "erro");
        }
        return;
      }
      const botao = evento.target.closest("[data-excluir-sensor]");
      if (!botao) return;
      const id = botao.dataset.excluirSensor;
      const sensor = estado.sensores.find(
        (item) => String(item.id) === String(id),
      );
      if (
        !sensor ||
        !window.confirm(
          `Excluir o sensor ${sensor.sensor}? O histórico de leituras associado também será apagado.`,
        )
      )
        return;

      botao.disabled = true;
      try {
        await FrutLog.apiFetch(`/sensores/${encodeURIComponent(id)}`, {
          method: "DELETE",
        });
        estado.sensores = estado.sensores.filter(
          (item) => String(item.id) !== String(id),
        );
        renderizarSensores();
        renderizarGraficoLeituras();
        exibirMensagem(
          "mensagem-sensor",
          "Sensor e leituras historicas associadas excluidos.",
          "sucesso",
        );
      } catch (erro) {
        botao.disabled = false;
        exibirMensagem("mensagem-sensor", erro.message, "erro");
      }
    });
}

export function renderizarFuncionarios() {
  carregarFuncionarios();
}
