import { exibirMensagem } from "./interface.js";
import {
  configurarAcoesTabelas,
  configurarFiltrosFuncionarios,
  configurarFormularioFuncionario,
} from "./funcionarios.js";
import { configurarFormularioSensor, preencherSelectTalhoes } from "./sensores.js";
import { carregarMapaAdmin, renderizarMapaAdmin } from "./mapa.js";
import {
  configurarGraficos,
  definirColheitasAnuais,
  renderizarGraficoColheita,
} from "./telemetria.js";
import { atualizarDadosCampoConectados, carregarDadosConectados } from "./dados.js";

document.addEventListener("DOMContentLoaded", async () => {
  FrutLog.verificarSessao(["admin"]);
  FrutLog.configurarLogout();
  FrutLog.configurarAbasSidebar();
  configurarFormularioFuncionario();
  configurarFormularioSensor();
  configurarFiltrosFuncionarios();
  configurarAcoesTabelas();
  configurarGraficos();
  preencherSelectTalhoes();
  window.addEventListener("frutlog:colheitas-atualizadas", async () => {
    try {
      const resposta = await FrutLog.apiFetch("/colheitas/anual");
      definirColheitasAnuais(resposta.colheitas);
      renderizarGraficoColheita();
    } catch (erro) {
      exibirMensagem("mensagem-colheita-admin", erro.message, "erro");
    }
  });
  window.addEventListener("frutlog:talhoes-atualizados", atualizarDadosCampoConectados);
  const inicializacoes = await Promise.allSettled([carregarDadosConectados(), carregarMapaAdmin()]);
  const errosInicializacao = inicializacoes
    .filter((resultado) => resultado.status === "rejected")
    .map((resultado) => resultado.reason?.message || String(resultado.reason));
  renderizarMapaAdmin();
  if (errosInicializacao.length) {
    exibirMensagem(
      "mensagem-carregamento-admin",
      `Falha ao carregar os dados: ${errosInicializacao.join(" | ")}`,
      "erro",
    );
  }
});

window.addEventListener("focus", atualizarDadosCampoConectados);
