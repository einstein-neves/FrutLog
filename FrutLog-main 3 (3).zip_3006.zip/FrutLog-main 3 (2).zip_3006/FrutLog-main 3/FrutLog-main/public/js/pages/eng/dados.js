import { estado } from "./estado.js";
import {
  atualizarControlesEdicao,
  obterFeature,
  renderizarBotoesTalhao,
  renderizarMapa,
  selecionarTalhao,
} from "./mapa.js";
import { atualizarSelectCadastro } from "./plantio.js";
import { exibirMensagemEdicao } from "./interface.js";
import { carregarGraficoColheita, renderizarGraficoClimaMensalEngenheiro } from "./telemetria.js";

export async function carregarDadosPainel() {
  const talhoesServidor = await FrutLogMapaTalhoes.carregarMapaTalhoes("engenheiro");
  estado.talhoes = talhoesServidor;
  estado.mapaApiPronto = true;
  estado.talhaoSelecionado =
    obterFeature(estado.talhaoSelecionado)?.properties.codigo ||
    estado.talhoes[0]?.properties.codigo ||
    "";
  estado.codigosIniciais = new Set(estado.talhoes.map((feature) => feature.properties.codigo));
  atualizarSelectCadastro();
  renderizarBotoesTalhao();
  if (estado.talhaoSelecionado) selecionarTalhao(estado.talhaoSelecionado);
  else renderizarMapa();
  atualizarControlesEdicao();

  const [resultadoPainel, resultadoColheitas, resultadoTelemetria] = await Promise.allSettled([
    FrutLog.apiFetch("/painel-engenheiro"),
    FrutLog.apiFetch("/colheitas/anual"),
    FrutLog.apiFetch("/telemetria/diaria"),
  ]);
  const erros = [];
  const painel = resultadoPainel.status === "fulfilled" ? resultadoPainel.value : {};
  if (resultadoPainel.status === "rejected") {
    erros.push(`Dados do painel: ${resultadoPainel.reason?.message || resultadoPainel.reason}`);
  }
  if (resultadoColheitas.status === "fulfilled") {
    estado.colheitas = resultadoColheitas.value.colheitas || [];
  } else {
    estado.colheitas = [];
    erros.push(
      `Histórico de colheitas: ${resultadoColheitas.reason?.message || resultadoColheitas.reason}`,
    );
  }
  try {
    estado.telemetriaMensalEsp32 =
      (await FrutLog.apiFetch("/telemetria/esp32-mensal")).mensal || [];
  } catch (erro) {
    estado.telemetriaMensalEsp32 = [];
  }
  if (resultadoTelemetria.status === "fulfilled") {
    estado.telemetriaMensalEngenheiro = resultadoTelemetria.value.mensal || [];
    renderizarGraficoClimaMensalEngenheiro();
  } else {
    estado.telemetriaMensalEngenheiro = [];
    erros.push(`Telemetria: ${resultadoTelemetria.reason?.message || resultadoTelemetria.reason}`);
  }

  const sensoresPorTalhao = new Map();
  estado.sensoresDoPainel = painel.sensores || [];
  (painel.sensores || []).forEach((sensor) => {
    if (!sensoresPorTalhao.has(sensor.talhao)) sensoresPorTalhao.set(sensor.talhao, []);
    sensoresPorTalhao.get(sensor.talhao).push(sensor);
  });
  const talhoesMonitorados = new Map((painel.talhoes || []).map((talhao) => [talhao.id, talhao]));
  const inspecaoPorTalhao = new Map();
  (painel.inspecoes || []).forEach((item) => {
    if (!inspecaoPorTalhao.has(item.talhao)) inspecaoPorTalhao.set(item.talhao, item);
  });
  const ciclosPorTalhao = new Map((painel.plantios || []).map((item) => [item.talhao, item]));

  estado.talhoes = talhoesServidor.map((feature) => {
    const codigo = feature.properties.codigo;
    const sensores = sensoresPorTalhao.get(codigo) || [];
    const sensorPorTipo = (tipo) =>
      sensores.find((sensor) => sensor.tipo === tipo && sensor.status !== "Inativo");
    const temperatura = sensorPorTipo("temperatura");
    const umidadeAr = sensorPorTipo("umidadeAr");
    const umidadeSolo = sensorPorTipo("umidadeSolo");
    const chuva = sensorPorTipo("chuva");
    const ciclo = ciclosPorTalhao.get(codigo);
    const leituraCampo = inspecaoPorTalhao.get(codigo);
    const resumo = talhoesMonitorados.get(codigo);
    return {
      ...feature,
      properties: {
        ...feature.properties,
        status: resumo?.situacao || "Sem leitura",
        prioridade: resumo?.prioridade || "Sem leitura registrada.",
        sensor: resumo?.sensor || sensores[0]?.sensor || "Não associado",
        produto: ciclo?.produto || "--",
        variedade: ciclo?.variedade || "--",
        solo: ciclo?.solo || "--",
        plantio: ciclo?.plantado_em || "--",
        colheita: ciclo?.previsao_colheita || "--",
        diaria: {
          temperatura: temperatura?.valor ?? null,
          umidadeAr: umidadeAr?.valor ?? null,
          umidadeSolo: umidadeSolo?.valor ?? null,
          chuva: chuva?.valor ?? null,
        },
        mensal: [],
        apontamentoTecnico: {
          data: leituraCampo?.data || "--",
          tecnico: "--",
          problema: leituraCampo?.problemas || "Nenhuma inspeção registrada.",
          recomendacao: leituraCampo?.observacoes || "--",
        },
        monitoramento: {
          temperaturaAtual: temperatura?.valor ?? null,
          temperaturaMaxima: null,
        },
      },
    };
  });
  if (
    estado.colheitas.length &&
    !estado.colheitas.some((item) => item.unidade === estado.unidadeAtual)
  ) {
    estado.unidadeAtual = estado.colheitas[0].unidade;
    estado.filtrosGrafico.forEach((botao) => {
      botao.classList.toggle("active", botao.dataset.unidade === estado.unidadeAtual);
    });
  }
  estado.talhaoSelecionado =
    obterFeature(estado.talhaoSelecionado)?.properties.codigo ||
    estado.talhoes[0]?.properties.codigo ||
    "";
  atualizarSelectCadastro();
  renderizarBotoesTalhao();
  if (estado.talhaoSelecionado) selecionarTalhao(estado.talhaoSelecionado);
  else renderizarMapa();
  carregarGraficoColheita();
  if (erros.length) {
    exibirMensagemEdicao(`Talhões carregados. ${erros.join(" | ")}`, "erro");
  }
}
