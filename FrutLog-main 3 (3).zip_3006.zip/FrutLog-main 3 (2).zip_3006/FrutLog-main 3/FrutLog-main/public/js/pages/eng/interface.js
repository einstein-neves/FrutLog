export { preencherTexto } from "../../core/dom.js";

import { estado } from "./estado.js";

export function classeStatus(status) {
  return String(status)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, "-");
}

export function formatarData(dataISO) {
  if (!dataISO) return "--";
  const [ano, mes, dia] = dataISO.split("-");
  return dia && mes && ano ? `${dia}/${mes}/${ano}` : dataISO;
}

export function exibirMensagemEdicao(texto, tipo = "sucesso") {
  if (!estado.mensagemEdicao) return;
  estado.mensagemEdicao.textContent = texto;
  estado.mensagemEdicao.className = `mensagem-feedback ${tipo}`;
}
