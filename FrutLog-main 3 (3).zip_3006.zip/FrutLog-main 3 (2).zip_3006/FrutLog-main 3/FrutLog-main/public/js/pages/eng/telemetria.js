import { estado } from "./estado.js";
import { preencherTexto } from "./interface.js";

export function atualizarTabelaDiaria(dados) {
  const tabela = document.getElementById("tabela-telemetria-diaria");
  if (!tabela) return;

  tabela.innerHTML = `
      <tr>
        <td>${dados.temperatura || "--"}</td>
        <td>${dados.umidadeAr || "--"}</td>
        <td>${dados.umidadeSolo || "--"}</td>
        <td>${dados.chuva || "--"}</td>
      </tr>
    `;
}

export function atualizarTabelaMensal(dadosMensais) {
  const tabela = document.getElementById("tabela-talhao-mensal");
  if (!tabela) return;

  if (!dadosMensais.length) {
    tabela.innerHTML = '<tr><td colspan="6">Sem consolidado mensal para este talhão.</td></tr>';
    return;
  }

  tabela.innerHTML = dadosMensais
    .map(
      (item) => `
      <tr>
        <td>${item.temp}</td>
        <td>${item.umidAr}</td>
        <td>${item.umidSolo}</td>
        <td>${item.chuva}</td>
        <td>${item.prev}</td>
        <td>${item.qtd}</td>
      </tr>
    `,
    )
    .join("");
}

export function renderizarGraficoClimaMensalEngenheiro() {
  const canvas = document.getElementById("grafico-clima-mensal-engenheiro");

  if (!canvas || typeof Chart === "undefined") return;

  if (estado.graficoClimaMensalEngenheiro) {
    estado.graficoClimaMensalEngenheiro.destroy();
  }
  const dadosMensais = [...estado.telemetriaMensalEngenheiro, ...estado.telemetriaMensalEsp32];

  const metricas = {
    temperatura: {
      nome: "Temperatura",
    },
    chuva: {
      nome: "Chuva",
    },
    umidadeAr: {
      nome: "Umidade do ar",
    },
    umidadeSolo: {
      nome: "Umidade do solo",
    },
  };

  const meses = [...new Set(dadosMensais.map((item) => item.mes).filter(Boolean))].sort();

  const dados = meses.map((mes) => {
    const resultado = { mes };

    Object.keys(metricas).forEach((codigo) => {
      const leituras = dadosMensais
        .filter(
          (item) =>
            item.mes === mes &&
            item.codigo_metrica === codigo &&
            Number.isFinite(Number(item.valor_medio)),
        )
        .map((item) => Number(item.valor_medio));

      resultado[codigo] = leituras.length
        ? leituras.reduce((soma, valor) => soma + valor, 0) / leituras.length
        : null;
    });

    return resultado;
  });

  estado.graficoClimaMensalEngenheiro = new Chart(canvas, {
    type: "line",
    data: {
      labels: dados.map((item) => item.mes),
      datasets: [
        {
          label: "Temperatura (°C)",
          data: dados.map((item) => item.temperatura),
          tension: 0.3,
          borderWidth: 2,
        },
        {
          label: "Chuva (mm)",
          data: dados.map((item) => item.chuva),
          tension: 0.3,
          borderWidth: 2,
        },
        {
          label: "Umidade do ar (%)",
          data: dados.map((item) => item.umidadeAr),
          tension: 0.3,
          borderWidth: 2,
        },
        {
          label: "Umidade do solo (%)",
          data: dados.map((item) => item.umidadeSolo),
          tension: 0.3,
          borderWidth: 2,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

export function atualizarResumoColheita() {
  const unidades = estado.colheitas.filter((item) => item.unidade === estado.unidadeAtual);
  if (!unidades.length) {
    [
      "resumo-ultima-data",
      "resumo-ultima-valor",
      "resumo-menor-data",
      "resumo-menor-valor",
      "resumo-maior-data",
      "resumo-maior-valor",
    ].forEach((id) => preencherTexto(id, "--"));
    ["resumo-ultima-media", "resumo-menor-media", "resumo-maior-media"].forEach((id) =>
      preencherTexto(id, ""),
    );
    return;
  }
  const menor = unidades.reduce((a, b) => (a.quantidade < b.quantidade ? a : b));
  const maior = unidades.reduce((a, b) => (a.quantidade > b.quantidade ? a : b));
  const ultima = unidades.reduce((a, b) => (a.ano > b.ano ? a : b));
  const unidade =
    estado.unidadeAtual === "sc"
      ? "sacas"
      : estado.unidadeAtual === "t"
        ? "toneladas"
        : estado.unidadeAtual;

  preencherTexto("resumo-ultima-data", ultima.ano);
  preencherTexto("resumo-ultima-valor", `${ultima.quantidade} ${unidade}`);
  preencherTexto("resumo-menor-data", menor.ano);
  preencherTexto("resumo-menor-valor", `${menor.quantidade} ${unidade}`);
  preencherTexto("resumo-maior-data", maior.ano);
  preencherTexto("resumo-maior-valor", `${maior.quantidade} ${unidade}`);
}

export function carregarGraficoColheita() {
  const canvas = document.getElementById("graficoColheita");
  if (!canvas || typeof Chart === "undefined") return;

  if (estado.graficoColheita) estado.graficoColheita.destroy();
  const dados = estado.colheitas.filter((item) => item.unidade === estado.unidadeAtual);
  const rotulosUnidade = { t: "Toneladas", sc: "Sacas", kg: "Quilogramas", cx: "Caixas" };
  const rotulo = rotulosUnidade[estado.unidadeAtual] || estado.unidadeAtual;
  const mensagem = document.getElementById("mensagem-colheita");
  if (!dados.length) {
    estado.graficoColheita = null;
    if (mensagem) mensagem.textContent = "Ainda não há dados de colheita para esta unidade.";
    atualizarResumoColheita();
    return;
  }
  if (mensagem) mensagem.textContent = "";

  estado.graficoColheita = new Chart(canvas, {
    type: "bar",
    data: {
      labels: dados.map((item) => item.ano),
      datasets: [
        {
          label: rotulo,
          data: dados.map((item) => item.quantidade),
          backgroundColor: "#2e7d32",
          borderRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } },
    },
  });

  atualizarResumoColheita();
}
