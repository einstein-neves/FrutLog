export function ladoDaLinha(ponto, linhaInicio, linhaFim) {
  return (
    (linhaFim[0] - linhaInicio[0]) * (ponto[1] - linhaInicio[1]) -
    (linhaFim[1] - linhaInicio[1]) * (ponto[0] - linhaInicio[0])
  );
}

export function calcularIntersecaoLinha(inicio, fim, linhaInicio, linhaFim) {
  const distanciaInicio = ladoDaLinha(inicio, linhaInicio, linhaFim);
  const distanciaFim = ladoDaLinha(fim, linhaInicio, linhaFim);
  const divisor = distanciaInicio - distanciaFim;

  if (divisor === 0) return fim;

  const proporcao = distanciaInicio / divisor;
  return [
    Math.round(inicio[0] + (fim[0] - inicio[0]) * proporcao),
    Math.round(inicio[1] + (fim[1] - inicio[1]) * proporcao),
  ];
}

export function recortarPoligonoPorLinha(pontos, linhaInicio, linhaFim, manterPositivo) {
  const resultado = [];

  pontos.forEach((fim, index) => {
    const inicio = pontos[(index - 1 + pontos.length) % pontos.length];
    const inicioLado = ladoDaLinha(inicio, linhaInicio, linhaFim);
    const fimLado = ladoDaLinha(fim, linhaInicio, linhaFim);
    const inicioDentro = manterPositivo ? inicioLado >= 0 : inicioLado <= 0;
    const fimDentro = manterPositivo ? fimLado >= 0 : fimLado <= 0;

    if (fimDentro) {
      if (!inicioDentro)
        resultado.push(calcularIntersecaoLinha(inicio, fim, linhaInicio, linhaFim));
      resultado.push(fim);
    } else if (inicioDentro) {
      resultado.push(calcularIntersecaoLinha(inicio, fim, linhaInicio, linhaFim));
    }
  });

  return removerPontosDuplicados(resultado);
}

export function removerPontosDuplicados(pontos) {
  return pontos.filter((ponto, index) => {
    const anterior = pontos[index - 1];
    const primeiro = index === pontos.length - 1 ? pontos[0] : null;
    const repeteAnterior = anterior && anterior[0] === ponto[0] && anterior[1] === ponto[1];
    const repetePrimeiro = primeiro && primeiro[0] === ponto[0] && primeiro[1] === ponto[1];
    return !repeteAnterior && !repetePrimeiro;
  });
}

export function calcularAreaPoligono(pontos) {
  return (
    Math.abs(
      pontos.reduce((soma, ponto, indice) => {
        const proximo = pontos[(indice + 1) % pontos.length];
        return soma + ponto[0] * proximo[1] - proximo[0] * ponto[1];
      }, 0),
    ) / 2
  );
}
