import { estado } from "./estado.js";
import { exibirMensagemEdicao, preencherTexto } from "./interface.js";
import {
  aplicarAreaTalhao,
  ativarOuDesativarEdicao,
  atualizarControlesEdicao,
  atualizarVertice,
  cancelarAlteracoesMapa,
  concluirCriacao,
  dividirTalhaoSelecionado,
  excluirTalhaoSelecionado,
  iniciarCriacao,
  iniciarDivisao,
  moverTalhao,
  obterPontoSvg,
  renderizarBotoesTalhao,
  renderizarMapa,
  salvarAlteracoesMapa,
  selecionarTalhao,
} from "./mapa.js";
import { atualizarSelectCadastro, atualizarSensoresDoTalhao, registrarPlantio } from "./plantio.js";
import { carregarDadosPainel } from "./dados.js";
import { carregarGraficoColheita } from "./telemetria.js";

document.addEventListener("DOMContentLoaded", async () => {
  FrutLog.verificarSessao(["engenheiro"]);
  FrutLog.configurarLogout();
  FrutLog.configurarAbasSidebar();
  estado.btnEditar?.addEventListener("click", ativarOuDesativarEdicao);
  document.getElementById("btn-recarregar-mapa")?.addEventListener("click", async (evento) => {
    if (estado.modoEdicao) {
      exibirMensagemEdicao("Salve ou cancele a edição antes de recarregar o mapa.", "erro");
      return;
    }
    const botao = evento.currentTarget;
    botao.disabled = true;
    exibirMensagemEdicao("Carregando talhões do servidor...");
    try {
      await carregarDadosPainel();
      exibirMensagemEdicao("Mapa carregado. Clique em Editar Talhões para ajustar os limites.");
    } catch (erro) {
      exibirMensagemEdicao(`Falha ao carregar o mapa: ${erro.message}`, "erro");
    } finally {
      botao.disabled = false;
      atualizarControlesEdicao();
    }
  });
  estado.btnCriar?.addEventListener("click", iniciarCriacao);
  estado.btnConcluirDesenho?.addEventListener("click", concluirCriacao);
  estado.btnDividir?.addEventListener("click", iniciarDivisao);
  estado.btnExcluir?.addEventListener("click", excluirTalhaoSelecionado);
  estado.btnSalvar?.addEventListener("click", salvarAlteracoesMapa);
  estado.btnCancelar?.addEventListener("click", cancelarAlteracoesMapa);
  estado.btnAplicarArea?.addEventListener("click", aplicarAreaTalhao);
  estado.svgMapa?.addEventListener("click", (evento) => {
    if (!estado.modoCriacao && !estado.modoDivisao) return;

    const ponto = obterPontoSvg(evento);

    if (estado.modoDivisao) {
      estado.pontosDivisao.push(ponto);

      if (estado.pontosDivisao.length === 2) {
        dividirTalhaoSelecionado(estado.pontosDivisao[0], estado.pontosDivisao[1]);
        return;
      }

      renderizarMapa();
      exibirMensagemEdicao("Agora clique no segundo ponto da linha de divisão.");
      return;
    }

    estado.pontosCriacao.push(ponto);
    atualizarControlesEdicao();
    renderizarMapa();
  });
  estado.svgMapa?.addEventListener("dblclick", (evento) => {
    evento.preventDefault();
    concluirCriacao();
  });
  window.addEventListener("pointermove", (evento) => {
    atualizarVertice(evento);
    moverTalhao(evento);
  });
  window.addEventListener("pointerup", () => {
    estado.verticeArrastado = null;
    estado.talhaoArrastado = null;
  });
  estado.filtrosGrafico.forEach((botao) => {
    botao.addEventListener("click", () => {
      estado.unidadeAtual = botao.dataset.unidade;
      estado.filtrosGrafico.forEach((item) => item.classList.toggle("active", item === botao));
      carregarGraficoColheita();
    });
  });
  document.getElementById("talhao")?.addEventListener("change", atualizarSensoresDoTalhao);
  estado.formularioPlantio?.addEventListener("submit", registrarPlantio);
  window.addEventListener("frutlog:colheitas-atualizadas", async () => {
    try {
      await carregarDadosPainel();
      preencherTexto("mensagem-colheita", "Colheita registrada e graficos atualizados.");
    } catch (erro) {
      preencherTexto("mensagem-colheita", erro.message);
    }
  });
  window.addEventListener("frutlog:talhoes-atualizados", async () => {
    if (estado.modoEdicao) return;
    try {
      await carregarDadosPainel();
    } catch (erro) {
      exibirMensagemEdicao(`Falha ao sincronizar talhões: ${erro.message}`, "erro");
    }
  });
  if (FrutLog.AUTENTICACAO_API_ATIVA) {
    try {
      await carregarDadosPainel();
    } catch (erro) {
      // A failure in other dashboard data must not disable an already loaded map.
      exibirMensagemEdicao(
        `Não foi possível carregar os dados do servidor: ${erro.message}`,
        "erro",
      );
    }
  }
  atualizarControlesEdicao();
  atualizarSelectCadastro();
  renderizarBotoesTalhao();
  if (estado.talhaoSelecionado) selecionarTalhao(estado.talhaoSelecionado);
  carregarGraficoColheita();
  if (FrutLog.AUTENTICACAO_API_ATIVA) {
    window.setInterval(async () => {
      if (estado.modoEdicao) return;
      try {
        await carregarDadosPainel();
      } catch (erro) {
        console.error("Falha ao atualizar o painel do Engenheiro:", erro);
        exibirMensagemEdicao(`Falha ao sincronizar o painel: ${erro.message}`, "erro");
      }
    }, 15000);
  }
});
