// Estado exclusivo deste painel, compartilhado pelos seus módulos.
export const estado = {};

estado.svgMapa = document.getElementById("camada-talhoes");

estado.mapaContainer = document.querySelector(".mapa-container");

estado.botoesTalhao = document.getElementById("botoes-talhao");

estado.formularioPlantio = document.getElementById("formulario-plantio");

estado.mensagemPlantio = document.getElementById("mensagem-plantio");

estado.mensagemEdicao = document.getElementById("mensagem-edicao-talhao");

estado.filtrosGrafico = document.querySelectorAll(".btn-filtro[data-unidade]");

estado.btnEditar = document.getElementById("btn-editar-talhoes");

estado.btnCriar = document.getElementById("btn-criar-talhao");

estado.btnConcluirDesenho = document.getElementById("btn-concluir-desenho");

estado.btnDividir = document.getElementById("btn-dividir-talhao");

estado.btnExcluir = document.getElementById("btn-excluir-talhao");

estado.btnSalvar = document.getElementById("btn-salvar-talhao");

estado.btnCancelar = document.getElementById("btn-cancelar-talhao");

estado.campoAreaTalhao = document.getElementById("talhao-area-hectares");

estado.btnAplicarArea = document.getElementById("btn-aplicar-area-talhao");

estado.talhoes = FrutLogTalhoes.obterTalhoes();

estado.talhaoSelecionado = estado.talhoes[0]?.properties.codigo || "";

estado.codigosIniciais = new Set(estado.talhoes.map((feature) => feature.properties.codigo));

estado.mapaApiPronto = !FrutLog.AUTENTICACAO_API_ATIVA;

estado.modoEdicao = false;

estado.modoCriacao = false;

estado.modoDivisao = false;

estado.pontosCriacao = [];

estado.codigoGeometriaPendente = "";

estado.pontosDivisao = [];

estado.verticeArrastado = null;

estado.talhaoArrastado = null;

estado.graficoColheita = null;

estado.graficoClimaMensalEngenheiro = null;

estado.unidadeAtual = "t";

estado.sensoresDoPainel = [];

estado.telemetriaMensalEngenheiro = [];

estado.telemetriaMensalEsp32 = [];

estado.colheitas = [];
