import { estado } from "./estado.js";
import { obterFeature } from "./mapa.js";
import { carregarDadosPainel } from "./dados.js";

export function atualizarSelectCadastro() {
  const select = document.getElementById("talhao");
  if (!select) return;

  const atual = select.value;
  const opcoes = estado.talhoes
    .map((feature) => {
      const codigo = String(feature.properties.codigo).replace(
        /[&<>"']/g,
        (caractere) =>
          ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;",
          })[caractere],
      );
      return `<option value="${codigo}">${codigo}</option>`;
    })
    .join("");
  select.innerHTML = `<option value="">${opcoes ? "Selecione o talhão" : "Nenhum talhão carregado"}</option>${opcoes}`;
  if (estado.talhoes.some((feature) => feature.properties.codigo === atual)) select.value = atual;
  atualizarSensoresDoTalhao();
}

export function atualizarSensoresDoTalhao() {
  const select = document.getElementById("sensor-associado");
  if (!select) return;
  const codigoTalhao = document.getElementById("talhao")?.value;
  const sensores = estado.sensoresDoPainel.filter(
    (sensor) => sensor.talhao === codigoTalhao && sensor.ativo,
  );
  if (!sensores.length) {
    select.innerHTML =
      '<option value="Nenhum sensor ativo cadastrado para este talhao">Nenhum sensor ativo cadastrado para este talhão</option>';
    select.disabled = true;
    return;
  }
  select.innerHTML = sensores
    .map((sensor) => {
      const situacao = sensor.status === "Online" ? "Online" : "Cadastrado, aguardando leitura";
      return `<option>${sensor.sensor} - ${sensor.tipo} (${situacao})</option>`;
    })
    .join("");
  select.disabled = false;
}

export async function registrarPlantio(evento) {
  evento.preventDefault();

  const dadosFormulario = Object.fromEntries(new FormData(estado.formularioPlantio));
  const feature = obterFeature(dadosFormulario.talhao);

  if (!feature) return;

  const botao = estado.formularioPlantio.querySelector('[type="submit"]');
  if (botao) botao.disabled = true;
  try {
    await FrutLog.apiFetch("/plantios", {
      method: "POST",
      body: JSON.stringify(dadosFormulario),
    });
    await carregarDadosPainel();
    estado.mensagemPlantio.textContent = "Plantio cadastrado no banco de dados.";
    estado.mensagemPlantio.className = "mensagem-feedback sucesso";
    estado.formularioPlantio.reset();
    FrutLog.notificarAtualizacaoTalhoes();
  } catch (erro) {
    estado.mensagemPlantio.textContent = erro.message;
    estado.mensagemPlantio.className = "mensagem-feedback erro";
  } finally {
    if (botao) botao.disabled = false;
  }
}
