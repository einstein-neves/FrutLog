import { estado } from "./estado.js";
import { classeStatus, exibirMensagemEdicao, preencherTexto } from "./interface.js";
import {
  atualizarTabelaDiaria,
  atualizarTabelaMensal,
  renderizarGraficoClimaMensalEngenheiro,
} from "./telemetria.js";
import { atualizarSelectCadastro } from "./plantio.js";
import { calcularAreaPoligono, ladoDaLinha, recortarPoligonoPorLinha } from "./geometria.js";

export function obterFeature(codigo) {
  return estado.talhoes.find((feature) => feature.properties.codigo === codigo);
}

export function obterPontos(feature) {
  return FrutLogTalhoes.obterPontos(feature);
}

export function pontosParaString(pontos) {
  return pontos.map((ponto) => `${ponto[0]},${ponto[1]}`).join(" ");
}

export function atualizarStatusTalhao(feature) {
  const monitorado = FrutLogTalhoes.aplicarMonitoramento(feature);
  feature.properties = monitorado.properties;
  return feature.properties.status;
}

export function renderizarBotoesTalhao() {
  if (!estado.botoesTalhao) return;

  estado.botoesTalhao.innerHTML = estado.talhoes
    .map((feature) => {
      const codigo = feature.properties.codigo;
      const ativo = codigo === estado.talhaoSelecionado ? " active" : "";
      return `<button class="btn-talhao${ativo}" type="button" data-talhao="${codigo}">${codigo}</button>`;
    })
    .join("");

  estado.botoesTalhao.querySelectorAll(".btn-talhao").forEach((botao) => {
    botao.addEventListener("click", () => selecionarTalhao(botao.dataset.talhao));
  });
}

export function renderizarMapa() {
  if (!estado.svgMapa) return;

  const pendentes = estado.talhoes.filter((feature) => feature.properties.geometriaPendente).length;
  preencherTexto(
    "mensagem-geometria-talhoes",
    pendentes
      ? `${pendentes} talhão(es) ainda sem geometria. Selecione cada um e use Criar para desenhar seus limites.`
      : "",
  );

  FrutLogMapaTalhoes.renderizarMapaTalhoes(estado.svgMapa, estado.talhoes, {
    selectedCode: estado.talhaoSelecionado,
    statusFor: atualizarStatusTalhao,
    onSelect: (feature, evento) => {
      if (estado.modoCriacao || estado.modoDivisao) return;
      evento.stopPropagation();
      if (!estado.talhaoArrastado?.moveu) selecionarTalhao(feature.properties.codigo);
    },
    onPolygon: (poligono, feature) => {
      const codigo = feature.properties.codigo;
      poligono.addEventListener("pointerdown", (evento) => {
        if (
          !estado.modoEdicao ||
          estado.modoCriacao ||
          estado.modoDivisao ||
          codigo !== estado.talhaoSelecionado
        )
          return;
        evento.preventDefault();
        estado.talhaoArrastado = {
          codigo,
          origem: obterPontoSvg(evento),
          moveu: false,
        };
      });

      if (estado.modoEdicao && codigo === estado.talhaoSelecionado) {
        renderizarVertices(feature);
      }
    },
  });

  /* Os overlays de edição permanecem exclusivos do Engenheiro. */
  if (estado.modoCriacao && estado.pontosCriacao.length > 0) {
    const rascunho = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
    rascunho.setAttribute("points", pontosParaString(estado.pontosCriacao));
    rascunho.classList.add("poligono-rascunho");
    estado.svgMapa.appendChild(rascunho);
  }

  if (estado.modoDivisao && estado.pontosDivisao.length > 0) {
    const linhaDivisao = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
    linhaDivisao.setAttribute("points", pontosParaString(estado.pontosDivisao));
    linhaDivisao.classList.add("linha-divisao-talhao");
    estado.svgMapa.appendChild(linhaDivisao);
  }
}

export function renderizarVertices(feature) {
  const grupo = document.createElementNS("http://www.w3.org/2000/svg", "g");
  grupo.dataset.verticesTalhao = feature.properties.codigo;

  obterPontos(feature).forEach((ponto, index) => {
    const vertice = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    vertice.setAttribute("cx", ponto[0]);
    vertice.setAttribute("cy", ponto[1]);
    vertice.setAttribute("r", "6");
    vertice.classList.add("ponto-arrastavel");
    vertice.dataset.index = String(index);
    vertice.addEventListener("pointerdown", (evento) => {
      evento.preventDefault();
      evento.stopPropagation();
      estado.verticeArrastado = { codigo: feature.properties.codigo, index };
    });
    grupo.appendChild(vertice);
  });

  estado.svgMapa.appendChild(grupo);
}

export function atualizarControlesEdicao() {
  const habilitarFerramentas = estado.modoEdicao;

  [
    estado.btnCriar,
    estado.btnDividir,
    estado.btnExcluir,
    estado.btnSalvar,
    estado.btnCancelar,
  ].forEach((botao) => {
    if (botao) botao.disabled = !habilitarFerramentas;
  });

  estado.btnEditar?.classList.toggle("active", estado.modoEdicao);
  if (estado.btnEditar) estado.btnEditar.disabled = !estado.mapaApiPronto;
  if (estado.btnEditar)
    estado.btnEditar.textContent = estado.modoEdicao ? "Encerrar Edição" : "Editar Talhões";
  if (estado.btnAplicarArea)
    estado.btnAplicarArea.disabled = !estado.modoEdicao || !estado.talhaoSelecionado;
  estado.btnCriar?.classList.toggle("active", estado.modoCriacao);
  if (estado.btnConcluirDesenho) {
    estado.btnConcluirDesenho.hidden = !estado.modoCriacao;
    estado.btnConcluirDesenho.disabled = estado.pontosCriacao.length < 3;
  }
  estado.btnDividir?.classList.toggle("active", estado.modoDivisao);
  if (estado.btnDividir)
    estado.btnDividir.textContent = estado.modoDivisao ? "Divisão Ativa" : "Dividir";
  estado.mapaContainer?.classList.toggle("modo-edicao", estado.modoEdicao);
  estado.mapaContainer?.classList.toggle("modo-divisao", estado.modoDivisao);
}

export function selecionarTalhao(codigo) {
  const feature = obterFeature(codigo);
  if (!feature) return;

  estado.talhaoSelecionado = codigo;
  const props = feature.properties;
  const status = atualizarStatusTalhao(feature);
  if (estado.campoAreaTalhao)
    estado.campoAreaTalhao.value = String(obterAreaHectares(feature) || "");

  preencherTexto("titulo-talhao", `Detalhes: Talhão ${codigo}`);
  preencherTexto("talhao-area", props.area);
  preencherTexto("talhao-solo", props.solo);
  preencherTexto("talhao-plantio", props.plantio);
  preencherTexto("talhao-colheita", props.colheita);
  preencherTexto("talhao-produto", props.produto);
  preencherTexto("talhao-variedade", props.variedade);
  preencherTexto("talhao-temperatura-maxima", `${props.parametros?.temperaturaMaxima ?? "--"} C`);
  preencherTexto("talhao-inspecao-data", props.apontamentoTecnico?.data || "--");
  preencherTexto("talhao-inspecao-tecnico", props.apontamentoTecnico?.tecnico || "--");
  preencherTexto("talhao-inspecao-problema", props.apontamentoTecnico?.problema || "--");
  preencherTexto("talhao-inspecao-recomendacao", props.apontamentoTecnico?.recomendacao || "--");

  const badge = document.getElementById("talhao-status");
  if (badge) {
    badge.textContent = FrutLog.textoInterface(status);
    badge.className = `badge-status ${classeStatus(status)}`;
  }

  atualizarTabelaDiaria(props.diaria || {});
  atualizarTabelaMensal(props.mensal || []);
  renderizarGraficoClimaMensalEngenheiro();
  renderizarBotoesTalhao();
  renderizarMapa();
}

export function obterPontoSvg(evento) {
  const ponto = estado.svgMapa.createSVGPoint();
  ponto.x = evento.clientX;
  ponto.y = evento.clientY;
  const convertido = ponto.matrixTransform(estado.svgMapa.getScreenCTM().inverse());

  return [
    Math.max(0, Math.min(500, Math.round(convertido.x))),
    Math.max(0, Math.min(400, Math.round(convertido.y))),
  ];
}

export function atualizarVertice(evento) {
  if (!estado.verticeArrastado) return;

  const feature = obterFeature(estado.verticeArrastado.codigo);
  if (!feature) return;

  const pontos = obterPontos(feature);
  pontos[estado.verticeArrastado.index] = obterPontoSvg(evento);
  feature.geometry.coordinates[0] = FrutLogTalhoes.fecharAnel(pontos);
  renderizarMapa();
}

export function moverTalhao(evento) {
  if (!estado.talhaoArrastado) return;

  const feature = obterFeature(estado.talhaoArrastado.codigo);
  if (!feature) return;

  const destino = obterPontoSvg(evento);
  const deslocamentoX = destino[0] - estado.talhaoArrastado.origem[0];
  const deslocamentoY = destino[1] - estado.talhaoArrastado.origem[1];

  if (deslocamentoX === 0 && deslocamentoY === 0) return;

  const pontos = obterPontos(feature).map((ponto) => [
    Math.max(0, Math.min(500, ponto[0] + deslocamentoX)),
    Math.max(0, Math.min(400, ponto[1] + deslocamentoY)),
  ]);

  feature.geometry.coordinates[0] = FrutLogTalhoes.fecharAnel(pontos);
  estado.talhaoArrastado.origem = destino;
  estado.talhaoArrastado.moveu = true;
  renderizarMapa();
}

export function gerarCodigoNovo() {
  let indice = estado.talhoes.length + 1;
  let codigo = `T${indice}`;

  while (obterFeature(codigo)) {
    indice += 1;
    codigo = `T${indice}`;
  }

  return codigo;
}

export function concluirCriacao() {
  if (!estado.modoCriacao || estado.pontosCriacao.length < 3) {
    exibirMensagemEdicao("Adicione pelo menos três pontos para criar um talhão.", "erro");
    return;
  }

  const areaInicial = Number(estado.campoAreaTalhao?.value);
  const codigo = estado.codigoGeometriaPendente || gerarCodigoNovo();
  const geometria = {
    type: "Polygon",
    coordinates: [FrutLogTalhoes.fecharAnel(estado.pontosCriacao)],
  };
  if (estado.codigoGeometriaPendente) {
    const feature = obterFeature(estado.codigoGeometriaPendente);
    feature.geometry = geometria;
    feature.properties.geometriaPendente = false;
    if (Number.isFinite(areaInicial) && areaInicial > 0) {
      feature.properties.area_hectares = areaInicial;
      feature.properties.area = `${areaInicial} hectares`;
    }
  } else {
    estado.talhoes.push(
      FrutLogTalhoes.criarFeature(codigo, estado.pontosCriacao, {
        ...(Number.isFinite(areaInicial) && areaInicial > 0
          ? { area_hectares: areaInicial, area: `${areaInicial} hectares` }
          : {}),
      }),
    );
  }
  estado.modoCriacao = false;
  estado.pontosCriacao = [];
  estado.codigoGeometriaPendente = "";
  selecionarTalhao(codigo);
  atualizarControlesEdicao();
  atualizarSelectCadastro();
  exibirMensagemEdicao(
    `Geometria do talhão ${codigo} atualizada. Clique em Salvar para persistir.`,
  );
}

export function ativarOuDesativarEdicao() {
  estado.modoEdicao = !estado.modoEdicao;
  estado.modoCriacao = false;
  estado.modoDivisao = false;
  estado.pontosCriacao = [];
  estado.codigoGeometriaPendente = "";
  estado.pontosDivisao = [];
  estado.verticeArrastado = null;
  estado.talhaoArrastado = null;
  atualizarControlesEdicao();
  renderizarMapa();
  exibirMensagemEdicao(
    estado.modoEdicao
      ? "Arraste os pontos para alterar a forma ou o interior para mover o talhão. Use Criar para desenhar um novo limite e Aplicar área para ajustar o tamanho. Clique em Salvar ao terminar."
      : "Modo de edição desativado.",
  );
}

export function iniciarCriacao() {
  if (!estado.modoEdicao) return;
  const featureSelecionada = obterFeature(estado.talhaoSelecionado);
  estado.codigoGeometriaPendente =
    featureSelecionada && obterPontos(featureSelecionada).length < 3
      ? estado.talhaoSelecionado
      : "";
  estado.modoCriacao = true;
  estado.modoDivisao = false;
  estado.pontosCriacao = [];
  estado.pontosDivisao = [];
  atualizarControlesEdicao();
  renderizarMapa();
  exibirMensagemEdicao(
    estado.codigoGeometriaPendente
      ? `Desenhe os limites do talhão ${estado.codigoGeometriaPendente}. Dê dois cliques para finalizar.`
      : "Clique no mapa para adicionar pontos. Dê dois cliques para finalizar.",
  );
}

export function iniciarDivisao() {
  if (!estado.modoEdicao || !estado.talhaoSelecionado) return;

  estado.modoCriacao = false;
  estado.modoDivisao = !estado.modoDivisao;
  estado.pontosCriacao = [];
  estado.codigoGeometriaPendente = "";
  estado.pontosDivisao = [];
  atualizarControlesEdicao();
  renderizarMapa();
  exibirMensagemEdicao(
    estado.modoDivisao
      ? `Clique em dois pontos atravessando o talhão ${estado.talhaoSelecionado} para dividir.`
      : "Divisão cancelada.",
  );
}

export function dividirTalhaoSelecionado(linhaInicio, linhaFim) {
  if (!estado.modoEdicao) return;

  const feature = obterFeature(estado.talhaoSelecionado);
  if (!feature) return;

  if (linhaInicio[0] === linhaFim[0] && linhaInicio[1] === linhaFim[1]) {
    exibirMensagemEdicao("Escolha dois pontos diferentes para dividir o talhão.", "erro");
    estado.pontosDivisao = [];
    renderizarMapa();
    return;
  }

  const pontos = obterPontos(feature);
  const lados = pontos.map((ponto) => ladoDaLinha(ponto, linhaInicio, linhaFim));
  const atravessaTalhao = lados.some((lado) => lado > 0) && lados.some((lado) => lado < 0);

  if (!atravessaTalhao) {
    exibirMensagemEdicao("A linha precisa atravessar o interior do talhão selecionado.", "erro");
    estado.pontosDivisao = [];
    renderizarMapa();
    return;
  }

  const parteUm = recortarPoligonoPorLinha(pontos, linhaInicio, linhaFim, true);
  const parteDois = recortarPoligonoPorLinha(pontos, linhaInicio, linhaFim, false);

  if (parteUm.length < 3 || parteDois.length < 3) {
    exibirMensagemEdicao("A linha precisa atravessar o talhão para gerar duas áreas.", "erro");
    return;
  }

  const propriedadesBase = {
    ...feature.properties,
    sensor: "Não associado",
    apontamentoTecnico: {
      data: "--",
      tecnico: "--",
      problema: "Talhão dividido. Sensor ainda não associado.",
      recomendacao: "Associar sensor ao novo talhão.",
    },
    prioridade: "Associar sensor",
  };

  const codigoBase = feature.properties.codigo;
  const codigoUm = gerarCodigoFilho(codigoBase, 1);
  const codigoDois = gerarCodigoFilho(codigoBase, 2);
  const novoUm = FrutLogTalhoes.criarFeature(codigoUm, parteUm, propriedadesBase);
  const novoDois = FrutLogTalhoes.criarFeature(codigoDois, parteDois, propriedadesBase);
  const areaBase = obterAreaHectares(feature);
  const areaUm = calcularAreaPoligono(parteUm);
  const areaDois = calcularAreaPoligono(parteDois);
  if (areaBase && areaUm + areaDois > 0) {
    const hectaresUm = (areaBase * areaUm) / (areaUm + areaDois);
    const hectaresDois = areaBase - hectaresUm;
    novoUm.properties.area_hectares = hectaresUm;
    novoUm.properties.area = `${hectaresUm.toFixed(2)} hectares`;
    novoDois.properties.area_hectares = hectaresDois;
    novoDois.properties.area = `${hectaresDois.toFixed(2)} hectares`;
  }
  novoUm.properties.codigo = codigoUm;
  novoDois.properties.codigo = codigoDois;

  estado.talhoes = estado.talhoes.filter((item) => item.properties.codigo !== codigoBase);
  estado.talhoes.push(novoUm, novoDois);
  estado.modoDivisao = false;
  estado.pontosDivisao = [];
  atualizarControlesEdicao();
  selecionarTalhao(novoUm.properties.codigo);
  atualizarSelectCadastro();
  exibirMensagemEdicao(
    `${codigoBase} dividido em ${novoUm.properties.codigo} e ${novoDois.properties.codigo}. Clique em Salvar.`,
  );
}

export function gerarCodigoFilho(codigoBase, indiceInicial) {
  let indice = indiceInicial;
  let codigo = `${codigoBase}.${indice}`;

  while (obterFeature(codigo)) {
    indice += 1;
    codigo = `${codigoBase}.${indice}`;
  }

  return codigo;
}

export function excluirTalhaoSelecionado() {
  if (!estado.modoEdicao || estado.talhoes.length <= 1) return;

  estado.talhoes = estado.talhoes.filter(
    (feature) => feature.properties.codigo !== estado.talhaoSelecionado,
  );
  estado.talhaoSelecionado = estado.talhoes[0]?.properties.codigo || "";
  selecionarTalhao(estado.talhaoSelecionado);
  atualizarSelectCadastro();
  exibirMensagemEdicao("Talhão removido do rascunho. Clique em Salvar para confirmar.");
}

export function obterAreaHectares(feature) {
  const valor =
    feature.properties.area_hectares ??
    String(feature.properties.area || "")
      .replace(/[^\d,.-]/g, "")
      .replace(",", ".");
  const area = Number(valor);
  return Number.isFinite(area) && area > 0 ? area : null;
}

export function aplicarAreaTalhao() {
  if (!estado.modoEdicao) return;
  const feature = obterFeature(estado.talhaoSelecionado);
  const area = Number(estado.campoAreaTalhao?.value);
  if (!feature || !Number.isFinite(area) || area <= 0) {
    exibirMensagemEdicao("Informe uma área valida, maior que zero hectares.", "erro");
    estado.campoAreaTalhao?.focus();
    return;
  }
  feature.properties.area_hectares = area;
  feature.properties.area = `${area} hectares`;
  preencherTexto("talhao-area", feature.properties.area);
  exibirMensagemEdicao(`Área do talhão ${estado.talhaoSelecionado} atualizada no rascunho.`);
}

export async function salvarAlteracoesMapa() {
  estado.modoCriacao = false;
  estado.modoDivisao = false;
  estado.pontosCriacao = [];
  estado.codigoGeometriaPendente = "";
  estado.pontosDivisao = [];
  const dadosTalhoes = estado.talhoes.map((feature) => ({
    ...feature,
    properties: {
      ...feature.properties,
      area_hectares: obterAreaHectares(feature),
    },
  }));

  if (dadosTalhoes.some((feature) => !feature.properties.area_hectares)) {
    exibirMensagemEdicao("Defina a área em hectares de todos os talhões antes de salvar.", "erro");
    return;
  }

  const botao = estado.btnSalvar;
  if (botao) botao.disabled = true;
  try {
    if (!estado.mapaApiPronto)
      throw new Error("As geometrias do servidor ainda não foram carregadas.");
    const resposta = await FrutLog.apiFetch("/talhoes/geometrias", {
      method: "PUT",
      body: JSON.stringify({
        talhoes: dadosTalhoes,
        removidos: [...estado.codigosIniciais].filter(
          (codigo) => !dadosTalhoes.some((feature) => feature.properties.codigo === codigo),
        ),
      }),
    });
    estado.talhoes = FrutLogTalhoes.carregarDoServidor(resposta.talhoes || []);
    estado.codigosIniciais = new Set(estado.talhoes.map((feature) => feature.properties.codigo));
    estado.talhaoSelecionado =
      obterFeature(estado.talhaoSelecionado)?.properties.codigo ||
      estado.talhoes[0]?.properties.codigo ||
      "";
    selecionarTalhao(estado.talhaoSelecionado);
    atualizarSelectCadastro();
    atualizarControlesEdicao();
    renderizarBotoesTalhao();
    renderizarMapa();
    exibirMensagemEdicao(
      "Geometrias e áreas salvas no banco. Os demais paineis receberao a atualizacao automaticamente.",
    );
    FrutLog.notificarAtualizacaoTalhoes();
  } catch (erro) {
    exibirMensagemEdicao(erro.message, "erro");
  } finally {
    if (botao && estado.modoEdicao) botao.disabled = false;
  }
}

export function cancelarAlteracoesMapa() {
  estado.talhoes = FrutLogTalhoes.obterTalhoes();
  estado.modoCriacao = false;
  estado.modoDivisao = false;
  estado.pontosCriacao = [];
  estado.codigoGeometriaPendente = "";
  estado.pontosDivisao = [];
  estado.talhaoSelecionado =
    obterFeature(estado.talhaoSelecionado)?.properties.codigo ||
    estado.talhoes[0]?.properties.codigo ||
    "";
  atualizarControlesEdicao();
  selecionarTalhao(estado.talhaoSelecionado);
  atualizarSelectCadastro();
  exibirMensagemEdicao("Alteracoes não salvas foram descartadas.");
}
