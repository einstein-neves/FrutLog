﻿const fs = require('fs');
const path = require('path');
const acorn = require('./frontend-tools/node_modules/acorn');
const scope = require('./frontend-tools/node_modules/eslint-scope');
const root = process.cwd();
const write = (p, s) => { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, s); };
for (const dir of ['css', 'js', 'imagem']) fs.renameSync(dir, `public/${dir}`);
for (const name of ['index', 'login', 'senha-temporaria', 'admin', 'eng', 'tec']) fs.renameSync(`${name}.html`, `public/${name}.html`);
const layouts = {
 admin: [
  ['interface', ['escaparHtml','formatarData','exibirMensagem','mostrarLinhasVazias','preencherTabela','normalizarStatus','classeStatusMapa']],
  ['funcionarios', ['gerarSenhaTemporaria','configurarFormularioFuncionario','carregarFuncionarios','configurarFiltrosFuncionarios','configurarAcoesTabelas','renderizarFuncionarios']],
  ['sensores', ['configurarFormularioSensor','preencherSelectTalhoes','renderizarSensores']],
  ['mapa', ['renderizarMapaAdmin','carregarMapaAdmin']],
  ['telemetria', ['renderizarTelemetriaDiariaAdmin','configurarGraficos','definirColheitasAnuais','renderizarGraficoColheita','renderizarGraficoLeituras','renderizarGraficoClima','carregarEsp32Mensal']],
  ['dados', ['carregarDadosConectados','atualizarDadosCampoConectados','renderizarPainelTecnico']],
 ],
 tec: [
  ['interface', ['dataLocalISO','configurarAbas','verificarSessao','escaparHtml','normalizarClasse','preencherTexto','formatarData','exibirMensagem']],
  ['dados', ['atualizarTalhoesMonitorados','carregarPainelTecnico','obterSensores','obterTarefasDia','obterAlertas','atualizarDadosAposRegistro']],
  ['telemetria', ['preencherFiltroTelemetria','carregarTelemetriaDiaria','renderizarTelemetriaDiaria','renderizarResumoTelemetriaDiaria','renderizarTelemetriaMensal','renderizarGraficoClimaMensalTecnico','carregarGraficoMetricas']],
  ['mapa', ['obterPontos','pontosParaString','carregarTalhoes','renderizarBotoesTalhao','renderizarMapa','selecionarTalhao','classeStatusMapa','configurarMapaTalhoes']],
  ['registros', ['configurarRelatorioDiario','preencherSelectTalhoes','atualizarSelectSensoresInspecao','carregarTarefasDia','carregarHistoricoInspecoes','carregarHistoricoOcorrencias','carregarHistoricoProblemasSensores','carregarSensores','carregarAlertas','obterDadosFormulario','registrarInspecao','registrarOcorrencia','registrarProblemaSensor','configurarFormularios']],
 ],
 eng: [
  ['interface', ['classeStatus','formatarData','preencherTexto','exibirMensagemEdicao']],
  ['mapa', ['obterFeature','obterPontos','pontosParaString','atualizarStatusTalhao','renderizarBotoesTalhao','renderizarMapa','renderizarVertices','atualizarControlesEdicao','selecionarTalhao','obterPontoSvg','atualizarVertice','moverTalhao','gerarCodigoNovo','concluirCriacao','ativarOuDesativarEdicao','iniciarCriacao','iniciarDivisao','dividirTalhaoSelecionado','gerarCodigoFilho','excluirTalhaoSelecionado','obterAreaHectares','aplicarAreaTalhao','salvarAlteracoesMapa','cancelarAlteracoesMapa']],
  ['geometria', ['ladoDaLinha','calcularIntersecaoLinha','recortarPoligonoPorLinha','removerPontosDuplicados','calcularAreaPoligono']],
  ['plantio', ['atualizarSelectCadastro','atualizarSensoresDoTalhao','registrarPlantio']],
  ['telemetria', ['atualizarTabelaDiaria','atualizarTabelaMensal','renderizarGraficoClimaMensalEngenheiro','atualizarResumoColheita','carregarGraficoColheita']],
  ['dados', ['carregarDadosPainel']],
 ],
};
for (const page of Object.keys(layouts)) {
 const old = `public/js/${page}.js`;
 let src = fs.readFileSync(old, 'utf8');
 if (page === 'eng') {
  const ast = acorn.parse(src, {ecmaVersion:2022});
  const body = ast.body[0].expression.arguments[1].body.body;
  const declarations = body.filter(n => ['VariableDeclaration','FunctionDeclaration'].includes(n.type));
  const boot = body.filter(n => !declarations.includes(n));
  src = declarations.map(n => src.slice(n.start,n.end)).join('\n\n') + '\n\ndocument.addEventListener("DOMContentLoaded", async () => {\n' + boot.map(n => src.slice(n.start,n.end)).join('\n') + '\n});\n';
 }
 const ast = acorn.parse(src, {ecmaVersion:2022, ranges:true});
 const manager = scope.analyze(ast, {ecmaVersion:2022, sourceType:'script', optimistic:true});
 const vars = manager.globalScope.variables;
 const stateNames = new Set(ast.body.filter(n=>n.type==='VariableDeclaration').flatMap(n=>n.declarations.map(d=>d.id.name)));
 const functions = ast.body.filter(n=>n.type==='FunctionDeclaration');
 const owner = new Map(layouts[page].flatMap(([group,names])=>names.map(name=>[name,group])));
 for(const f of functions) if(!owner.has(f.id.name)) throw new Error(`Unassigned ${page}: ${f.id.name}`);
 const references=[];
 const parents = new Map();
 function walk(n,p) { if(!n || typeof n!=='object') return; if(n.type) parents.set(n,p); for(const [key,v] of Object.entries(n)) { if(['range','start','end'].includes(key))continue; if(Array.isArray(v))v.forEach(x=>walk(x,n));else if(v&&typeof v==='object')walk(v,n); } }
 walk(ast,null);
 for(const v of vars) {
  const defs = new Set(v.identifiers);
  for(const r of v.references) if(!defs.has(r.identifier)) references.push({name:v.name,node:r.identifier});
 }
 function emit(nodes, group, extra='') {
  const imports=new Map();
  let content=nodes.map(n=>{
   let code=src.slice(n.start,n.end);
   const edits=[];
   for(const r of references) {
    if(r.node.start<n.start || r.node.end>n.end)continue;
    if(stateNames.has(r.name)) {
     const parent=parents.get(r.node);
     edits.push({start:r.node.start-n.start,end:r.node.end-n.start,text:parent?.type==='Property'&&parent.shorthand?`${r.name}: estado.${r.name}`:`estado.${r.name}`});
     if(group!=='estado') {if(!imports.has('estado'))imports.set('estado',new Set());imports.get('estado').add('estado');}
    } else if(owner.has(r.name)&&owner.get(r.name)!==group) {
     const from=owner.get(r.name);if(!imports.has(from))imports.set(from,new Set());imports.get(from).add(r.name);
    }
   }
   for(const e of edits.sort((a,b)=>b.start-a.start))code=code.slice(0,e.start)+e.text+code.slice(e.end);
   if(n.type==='FunctionDeclaration')code='export '+code;
   if(n.type==='VariableDeclaration') {
    // Each original declaration contains a single named binding.
    if(n.declarations.length!==1)throw new Error('Multiple declaration');
    code=code.replace(/^(let|const|var)\s+(\w+)\s*=/,'estado.$2 =');
   }
   return code;
  }).join('\n\n');
  const header=[...imports].map(([from,names])=>`import { ${[...names].sort().join(', ')} } from './${from}.js';`).join('\n');
  write(`public/js/pages/${page}/${group}.js`, `${header}${header?'\n\n':''}${extra}${content}\n`);
 }
 emit(ast.body.filter(n=>n.type==='VariableDeclaration'),'estado','// Estado exclusivo deste painel, compartilhado pelos seus módulos.\nexport const estado = {};\n\n');
 for(const [group]of layouts[page])emit(functions.filter(n=>owner.get(n.id.name)===group),group);
 emit(ast.body.filter(n=>!['VariableDeclaration','FunctionDeclaration'].includes(n.type)),'index');
 fs.unlinkSync(old);
 let html=fs.readFileSync(`public/${page}.html`,'utf8').replace(`<script src="js/${page}.js"></script>`,`<script type="module" src="js/pages/${page}/index.js"></script>`);
 if(page==='admin')html=html.replace('<script src="js/editor-mapa-admin.js"></script>','<script type="module" src="js/pages/admin/editor-mapa.js"></script>');
 write(`public/${page}.html`,html);
}
let editor=fs.readFileSync('public/js/editor-mapa-admin.js','utf8');
write('public/js/pages/admin/editor-mapa.js',`import { renderizarMapaAdmin } from './mapa.js';\n\n${editor}`);
fs.unlinkSync('public/js/editor-mapa-admin.js');
console.log('Painéis divididos em módulos ES com importações explícitas.');
