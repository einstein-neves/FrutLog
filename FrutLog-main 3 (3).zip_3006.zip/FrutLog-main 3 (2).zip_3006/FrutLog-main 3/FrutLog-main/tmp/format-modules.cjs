﻿const fs=require('fs');const path=require('path');const prettier=require('./frontend-tools/node_modules/prettier');
function walk(p){return fs.readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(p,e.name)):[path.join(p,e.name)]);}
(async()=>{for(const file of [...walk('public/js/pages').filter(f=>/[\\/](admin|eng|tec)[\\/]/.test(f)), 'public/js/core/dom.js', 'tests/frontend.spec.js','playwright.config.js']) {
fs.writeFileSync(file,await prettier.format(fs.readFileSync(file,'utf8'),{parser:'babel',printWidth:100}));
}})().catch(e=>{console.error(e);process.exitCode=1});
