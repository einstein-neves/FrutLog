﻿const fs=require('fs');const path=require('path');
const moves={
 'js/auth.js':'js/core/auth.js',
 'js/frutlog-talhoes.js':'js/features/talhoes.js',
 'js/mapa-talhoes.js':'js/features/mapa-talhoes.js',
 'js/relatorios.js':'js/features/relatorios.js',
 'js/telemetria-thingspeak.js':'js/features/telemetria-thingspeak.js',
 'js/colheitas.js':'js/features/colheitas.js',
 'js/chatbot.js':'js/features/chatbot.js',
 'js/calendarios.js':'js/components/calendarios.js',
 'js/pulse-frutlog.js':'js/components/pulse-frutlog.js',
 'js/login.js':'js/pages/login/index.js',
 'js/index.js':'js/pages/inicio/index.js',
 'js/senha-temporaria.js':'js/pages/senha-temporaria/index.js',
 'css/global.css':'css/base/global.css',
 'css/dashboard.css':'css/components/dashboard.css',
 'css/calendarios.css':'css/components/calendarios.css',
 'css/formularios.css':'css/components/formularios.css',
 'css/pulse-frutlog.css':'css/components/pulse-frutlog.css',
 'css/index.css':'css/pages/index.css',
 'css/login.css':'css/pages/login.css',
 'css/eng.css':'css/pages/eng.css',
 'css/tec.css':'css/pages/tec.css',
 'css/admin.css':'css/pages/admin.css',
};
for(const[from,to]of Object.entries(moves)) {fs.mkdirSync(path.dirname(`public/${to}`),{recursive:true});fs.renameSync(`public/${from}`,`public/${to}`);}
for(const page of fs.readdirSync('public').filter(f=>f.endsWith('.html'))) {
 const file=`public/${page}`;let s=fs.readFileSync(file,'utf8');for(const[from,to]of Object.entries(moves))s=s.split(`"${from}"`).join(`"${to}"`);
 s=s.replaceAll('class="container-iframe" style="height:300px;"','class="container-iframe container-iframe--compacto"');
 s=s.replace('style="display:flex; justify-content:space-between; align-items:center;"','class="campo-senha-cabecalho"').replace('style="margin-bottom:0;"','class="label-sem-margem"').replace('style="background:none; border:none; color:var(--cor-destaque); font-size:0.8rem; cursor:pointer; font-weight:600;"','class="btn-gerar-senha"');
 fs.writeFileSync(file,s);
}
for(const file of ['public/css/pages/index.css','public/css/pages/login.css','public/css/components/pulse-frutlog.css']) {let s=fs.readFileSync(file,'utf8');fs.writeFileSync(file,s.replaceAll('../imagem/','../../imagem/'));}
fs.appendFileSync('public/css/components/dashboard.css','\n.container-iframe--compacto { height: 300px; }\n');
fs.appendFileSync('public/css/pages/admin.css','\n.campo-senha-cabecalho { display: flex; justify-content: space-between; align-items: center; }\n.label-sem-margem { margin-bottom: 0; }\n.btn-gerar-senha { background: none; border: none; color: var(--cor-destaque); font-size: 0.8rem; cursor: pointer; font-weight: 600; }\n');
