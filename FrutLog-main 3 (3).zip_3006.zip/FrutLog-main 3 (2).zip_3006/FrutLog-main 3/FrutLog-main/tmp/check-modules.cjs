﻿const fs=require('fs');const path=require('path');const acorn=require('./frontend-tools/node_modules/acorn');const scope=require('./frontend-tools/node_modules/eslint-scope');
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const allowed=new Set(['document','window','FrutLog','FrutLogTalhoes','FrutLogMapaTalhoes','FrutLogTelemetriaThingSpeak','Chart','String','Number','Boolean','Array','Object','Set','Map','Math','Date','Intl','JSON','Promise','Error','console','FormData','CustomEvent','Event','history','confirm','alert','crypto','sessionStorage','localStorage','setTimeout','clearTimeout','URL','location','undefined','NaN','parseFloat','parseInt','fetch','requestAnimationFrame','getComputedStyle']);
for(const file of files('public/js/pages').filter(f=>/pages[\\/](admin|eng|tec)[\\/]/.test(f))) {
const s=fs.readFileSync(file,'utf8');const ast=acorn.parse(s,{ecmaVersion:2022,sourceType:'module',ranges:true});const m=scope.analyze(ast,{ecmaVersion:2022,sourceType:'module'});const unknown=[...new Set(m.globalScope.through.map(r=>r.identifier.name))].filter(n=>!allowed.has(n));if(unknown.length)console.log(file,unknown);
for(const n of ast.body.filter(n=>n.type==='ImportDeclaration')){const target=path.resolve(path.dirname(file),n.source.value);if(!fs.existsSync(target))throw Error('Missing '+target);}
}
console.log('Sintaxe e caminhos dos módulos verificados.');
