﻿const fs=require('fs');const path=require('path');
let s=fs.readFileSync('tests/frontend.spec.js','utf8').replace("const fs = require('fs');\nconst path = require('path');\n",'');
s=s.replace("await expect(page.locator('svg polygon[data-talhao=\"T1\"]')).toHaveCount(1);\n      await page.locator", "await expect(page.locator('svg polygon[data-talhao=\"T1\"]')).toHaveCount(1);\n      if(perfil === 'admin') await page.locator('.menu a[href=\"#mapa-fazenda\"]').click();\n      await page.locator");
s=s.replace("await page.getByRole('button',{name:'Editar Talhões',exact:true}).click();", "await page.locator('.menu a[href=\"#mapa-fazenda\"]').click();\n  await page.getByRole('button',{name:'Editar Talhões',exact:true}).click();");
fs.writeFileSync('tests/frontend.spec.js',s);
const acorn=require('./frontend-tools/node_modules/acorn');
for(const [page,names]of [['admin',['escaparHtml']],['tec',['escaparHtml','preencherTexto']],['eng',['preencherTexto']]]) {
 const file=`public/js/pages/${page}/interface.js`;let code=fs.readFileSync(file,'utf8');const ast=acorn.parse(code,{ecmaVersion:2022,sourceType:'module'});
 const remove=ast.body.filter(n=>n.type==='ExportNamedDeclaration'&&n.declaration?.type==='FunctionDeclaration'&&names.includes(n.declaration.id.name));
 for(const n of remove.sort((a,b)=>b.start-a.start))code=code.slice(0,n.start)+code.slice(n.end);
 code=`export { ${names.join(', ')} } from '../../core/dom.js';\n\n${code}`;
 fs.writeFileSync(file,code);
}
// Rename the local monitoring summary to distinguish it from the panel state.
const file='public/js/pages/tec/dados.js';let code=fs.readFileSync(file,'utf8').replace('const estado = monitoramentoPorTalhao.get(codigo);','const resumoTalhao = monitoramentoPorTalhao.get(codigo);').replaceAll('estado?.','resumoTalhao?.');fs.writeFileSync(file,code);
