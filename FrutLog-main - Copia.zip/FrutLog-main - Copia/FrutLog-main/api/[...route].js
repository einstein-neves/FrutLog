const crypto = require("crypto");
const { criarToken, autenticarRequisicao } = require("./session");
const { db, listarTalhoesComTemperatura, farmsForOrganization } = require("./database");
const { diagnosticarTalhoes } = require("../src/ia/predador-nucleo.js");
const { dadosRecentes, estadoSensor } = require("../src/operacao/estado-sensor");

const ROLES = ["engenheiro", "tecnico", "admin", "administrador"];
const TYPES = ["temperatura", "umidadeSolo", "umidadeAr"];
const required = ["SUPABASE_URL", "JWT_SECRET", "IOT_API_KEY", "FRONTEND_ORIGIN"];

function config() {
  const missing = required.filter((key) => !process.env[key]);
  const key = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) missing.push("SUPABASE_SECRET_KEY");
  if (missing.length) throw new Error(`Configuração ausente: ${missing.join(", ")}`);
  if (process.env.JWT_SECRET.length < 32) throw new Error("JWT_SECRET inseguro.");
  const origins = process.env.FRONTEND_ORIGIN.split(",").map((v) => v.trim()).filter(Boolean);
  origins.push(`http://localhost:${process.env.PORT || 3000}`, `http://127.0.0.1:${process.env.PORT || 3000}`);
  return {
    url: process.env.SUPABASE_URL.replace(/\/$/, ""),
    key,
    jwt: process.env.JWT_SECRET,
    iot: process.env.IOT_API_KEY,
    thingSpeak: {
      channelId: process.env.THINGSPEAK_CHANNEL_ID || "",
      readApiKey: process.env.THINGSPEAK_READ_API_KEY || "",
      fields: {
        temperatura: Number(process.env.THINGSPEAK_FIELD_TEMPERATURE) || 1,
        umidadeAr: Number(process.env.THINGSPEAK_FIELD_HUMIDITY) || 2,
        umidadeSolo: Number(process.env.THINGSPEAK_FIELD_SOIL_HUMIDITY) || 3,
      }
    },
    origins: [...new Set(origins)]
  };
}

function originFor(req, c) {
  const origin = req.headers.origin;
  return origin && c.origins.includes(origin) ? origin : undefined;
}

function reply(res, status, data, origin) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Cache-Control", "no-store");
  if (origin) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.end(JSON.stringify(data));
}

function parseBody(req, maximum = 16384) {
  return new Promise((resolve, reject) => {
    let raw = "", size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > maximum) {
        reject(new Error("Corpo muito grande."));
        req.destroy();
      } else raw += chunk;
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error("JSON inválido."));
      }
    });
    req.on("error", reject);
  });
}

function hashPassword(password) {
  const rounds = 210000;
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.pbkdf2Sync(password, salt, rounds, 32, "sha256").toString("hex");
  return `pbkdf2$${rounds}$${salt}$${hash}`;
}

function passwordOk(password, stored) {
  const [kind, rounds, salt, hash] = String(stored || "").split("$");
  if (kind !== "pbkdf2" || !/^\d+$/.test(rounds) || !salt || !/^[a-f0-9]{64}$/i.test(hash)) return false;
  const actual = crypto.pbkdf2Sync(password, salt, Number(rounds), 32, "sha256").toString("hex");
  return crypto.timingSafeEqual(Buffer.from(actual), Buffer.from(hash));
}

const hits = new Map();
const JANELA_MS = 60000;
const MAX_ENTRADAS = 10000; // teto de segurança: a memória nunca passa disso

// Limpeza: a cada minuto, apaga quem já saiu da janela de 60 s.
// Fica FORA da função rateLimit, para existir um único timer.
setInterval(() => {
  const agora = Date.now();
  for (const [chave, estado] of hits) {
    if (agora - estado.at > JANELA_MS) hits.delete(chave);
  }
}, JANELA_MS).unref(); // .unref(): o timer não impede o servidor de encerrar

function rateLimit(req, maximum, scope) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim();
  const key = `${scope}:${ip}`;
  const now = Date.now();
  const state = hits.get(key) || { at: now, count: 0 };
  if (now - state.at > JANELA_MS) {
    state.at = now;
    state.count = 0;
  }
  state.count++;

  // Teto: se o Map lotou e a chave é nova, descarta a mais antiga.
  if (!hits.has(key) && hits.size >= MAX_ENTRADAS) {
    hits.delete(hits.keys().next().value);
  }
  hits.set(key, state);
  return state.count <= maximum;
}

function text(v, max = 160) {
  return typeof v === "string" && v.trim() && v.trim().length <= max ? v.trim() : null;
}

function date(v) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v))) return null;
  const parsed = new Date(`${v}T00:00:00.000Z`);
  return Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== v ? null : v;
}

// Data de hoje no fuso do Brasil (AAAA-MM-DD). Usar toISOString() daria a data em UTC,
// que depois das 21h em Recife já é o dia seguinte e deixaria passar a data de amanhã.
function hojeNoBrasil() {
  return new Date().toLocaleDateString("sv-SE", { timeZone: "America/Sao_Paulo" });
}

function dataMaisRecente(...datas) {
  return datas
    .filter((valor) => valor && Number.isFinite(Date.parse(valor)))
    .sort((a, b) => Date.parse(b) - Date.parse(a))[0] || null;
}

function telemetryValid(d) {
  return (
    text(d.sensorId, 80) &&
    text(d.talhao, 40) &&
    TYPES.includes(d.tipo) &&
    Number.isFinite(Number(d.valor)) &&
    Math.abs(Number(d.valor)) <= 1000000 &&
    (!d.timestamp || !Number.isNaN(Date.parse(d.timestamp)))
  );
}

module.exports = async (req, res) => {
  let c;
  try {
    c = config();
  } catch (error) {
    console.error(error.message);
    return reply(res, 503, { mensagem: "API ainda não configurada." });
  }

  const origin = originFor(req, c);
  if (req.headers.origin && !origin) return reply(res, 403, { mensagem: "Origem não permitida." });
  if (req.method === "OPTIONS") {
    if (!origin) return reply(res, 403, { mensagem: "Origem não permitida." });
    res.writeHead(204, {
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-IoT-Key",
      "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
      "Access-Control-Max-Age": "600",
      Vary: "Origin"
    });
    return res.end();
  }

  const route = new URL(req.url, "http://localhost").pathname.replace(/^\/api/, "") || "/";
  const isLoginRequest = req.method === "POST" && route === "/login";
  if (!rateLimit(req, isLoginRequest ? 10 : 120, isLoginRequest ? "login" : "api")) {
    return reply(res, 429, { mensagem: "Muitas requisicoes." }, origin);
  }

  try {
    // 1. Health check
    if (req.method === "GET" && route === "/health") {
      try {
        await db(c, "organizacao", "GET", undefined, "?select=id&limit=1");
      } catch (error) {
        console.error("Health check: organizacao unavailable:", error.message);
        return reply(
          res,
          503,
          {
            sucesso: false,
            banco: false,
            esquema: false,
            mensagem: "Não foi possível consultar public.organizacao. Verifique SUPABASE_URL, a chave de serviço e schema.sql."
          },
          origin
        );
      }

      try {
        await db(c, "usuario", "GET", undefined, "?select=id&limit=1");
        return reply(res, 200, { sucesso: true, banco: true, esquema: true }, origin);
      } catch (error) {
        console.error("Health check: usuário unavailable:", error.message);
        return reply(
          res,
          503,
          {
            sucesso: false,
            banco: true,
            esquema: false,
            mensagem: "Banco conectado, mas public.usuario não está disponível na API do Supabase. Confira supabase/schema_oficial_atualizado.sql e recarregue o cache PostgREST."
          },
          origin
        );
      }
    }

    // 2. Autenticação e Login
    if (req.method === "POST" && route === "/login") {
      const d = await parseBody(req);
      const matricula = text(d.matricula, 40);
      const senha = typeof d.senha === "string" ? d.senha : "";
      if (!matricula || senha.length < 8 || senha.length > 10) {
        return reply(res, 401, { mensagem: "Matrícula ou senha inválida." }, origin);
      }

      const users = await db(
        c,
        "usuario",
        "GET",
        undefined,
        `?matricula=eq.${encodeURIComponent(matricula)}&select=id,matricula,nome_completo,perfil,senha_hash,status,senha_temporaria&limit=1`
      );
      const user = users[0];
      if (!user || user.status !== "ativo" || !passwordOk(senha, user.senha_hash)) {
        return reply(res, 401, { mensagem: "Matrícula ou senha inválida." }, origin);
      }

      const safe = {
        id: user.id,
        matricula: user.matricula,
        nome: user.nome_completo,
        perfil: user.perfil === "administrador" ? "admin" : user.perfil,
        mustChangePassword: Boolean(user.senha_temporaria)
      };
      return reply(res, 200, {
        sucesso: true,
        usuario: safe,
        token: criarToken(safe, c.jwt)
      }, origin);
    }

    // 3. Ingestão de Telemetria IoT
    if (req.method === "POST" && route === "/iot/telemetria") {
      const supplied = Buffer.from(String(req.headers["x-iot-key"] || ""));
      const expected = Buffer.from(c.iot);
      if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) {
        return reply(res, 401, { mensagem: "Credencial IoT inválida." }, origin);
      }

      const d = await parseBody(req);
      if (!telemetryValid(d)) return reply(res, 400, { mensagem: "Telemetria inválida." }, origin);

      const device = (
        await db(c, "dispositivo", "GET", undefined, `?id_externo=eq.${encodeURIComponent(d.sensorId)}&status=neq.desativado&select=id,talhao_id&limit=1`)
      )[0];
      if (!device) return reply(res, 403, { mensagem: "Dispositivo não autorizado." }, origin);

      const plot = (await db(c, "talhao", "GET", undefined, `?id=eq.${device.talhao_id}&select=codigo&limit=1`))[0];
      if (!plot || plot.codigo !== d.talhao) return reply(res, 403, { mensagem: "Dispositivo não pertence ao talhão." }, origin);

      const sensor = (
        await db(
          c,
          "sensor",
          "GET",
          undefined,
          `?dispositivo_id=eq.${device.id}&codigo_metrica=eq.${encodeURIComponent(d.tipo)}&status=eq.ativo&select=id,unidade&limit=1`
        )
      )[0];
      if (!sensor) return reply(res, 403, { mensagem: "Sensor ou métrica não autorizada." }, origin);

      const when = d.timestamp || new Date().toISOString();
      await db(c, "leitura_sensor", "POST", {
        sensor_id: sensor.id,
        dispositivo_id: device.id,
        coletado_em: when,
        valor: Number(d.valor),
        unidade: text(d.unidade, 20) || sensor.unidade,
        carga_bruta: d
      });
      await db(c, `dispositivo?id=eq.${device.id}`, "PATCH", { ultimo_sinal_em: when, status: "online" });
      return reply(res, 201, { sucesso: true }, origin);
    }

    // ---------------------------------------------------------------------
    // Catálogo de sensores para a ponte IoT (src/iot/ponte-thingspeak.js)
    // ---------------------------------------------------------------------
    // POR QUE EXISTE: antes, a ponte guardava o identificador de cada
    // dispositivo numa lista dentro do próprio código. Isso obrigava a digitar
    // o mesmo nome em DOIS lugares — na tela Sensores e no arquivo da ponte —
    // e a divergência entre eles não dava erro nenhum: a leitura simplesmente
    // nunca chegava. Com esta rota o cadastro da tela passa a ser a única
    // fonte do nome. Quem cadastra escolhe o nome; o código não conhece nome.
    //
    // POR QUE FICA ACIMA DA FRONTEIRA DE SESSÃO: quem chama é um processo de
    // servidor, não um navegador logado. Autentica com a mesma x-iot-key da
    // rota de telemetria, igual a um ESP32 faria.
    //
    // POR QUE ISSO NÃO AFROUXA A SEGURANÇA: quem tem a x-iot-key já podia
    // GRAVAR leitura por POST /iot/telemetria. Poder ler a lista de sensores
    // é estritamente menos do que isso.
    if (req.method === "GET" && route === "/iot/sensores") {
      const supplied = Buffer.from(String(req.headers["x-iot-key"] || ""));
      const expected = Buffer.from(c.iot);
      if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) {
        return reply(res, 401, { mensagem: "Credencial IoT inválida." }, origin);
      }

      // Mesma escada da rota /predador/analise: cada consulta depende dos ids
      // da anterior, por isso é sequencial e não Promise.all. O ternário com
      // length evita o `in.()` vazio, que o PostgREST rejeita como erro de
      // sintaxe em vez de devolver lista vazia.
      const sensors = await db(c, "sensor", "GET", undefined, "?status=eq.ativo&select=id,codigo_metrica,unidade,dispositivo_id");
      if (!sensors.length) return reply(res, 200, { sensores: [] }, origin);

      const devices = await db(c, "dispositivo", "GET", undefined,
        `?id=in.(${sensors.map((sensor) => sensor.dispositivo_id).join(",")})&status=neq.desativado&select=id,id_externo,talhao_id`);
      if (!devices.length) return reply(res, 200, { sensores: [] }, origin);

      const plots = await db(c, "talhao", "GET", undefined,
        `?id=in.(${devices.map((device) => device.talhao_id).join(",")})&arquivado_em=is.null&select=id,codigo`);

      const plotById = new Map(plots.map((plot) => [plot.id, plot.codigo]));
      const deviceById = new Map(devices.map((device) => [device.id, device]));

      // Sensor cujo dispositivo foi desativado, ou cujo talhão foi arquivado,
      // sai da lista: a ponte não deve continuar alimentando um talhão que
      // saiu de operação. É o mesmo critério do mapa, que só mostra ativos.
      const catalogo = sensors.reduce((lista, sensor) => {
        const device = deviceById.get(sensor.dispositivo_id);
        const codigoTalhao = device && plotById.get(device.talhao_id);
        if (codigoTalhao) {
          lista.push({
            sensorId: device.id_externo,
            talhao: codigoTalhao,
            tipo: sensor.codigo_metrica,
            unidade: sensor.unidade
          });
        }
        return lista;
      }, []);

      return reply(res, 200, { sensores: catalogo }, origin);
    }

    // Validação de Sessão para Rotas Protegidas
    const user = autenticarRequisicao(req, c.jwt);
    if (!user) return reply(res, 401, { mensagem: "Não autorizado." }, origin);

    // Recheck mutable account privileges before any write, so an old token
    // cannot keep changing data after an account is blocked or its role changes.
    if (req.method !== "GET") {
      const currentUser = (await db(
        c,
        "usuario",
        "GET",
        undefined,
        `?id=eq.${encodeURIComponent(user.sub)}&select=id,perfil,status&limit=1`
      ))[0];
      const currentRole = currentUser?.perfil === "administrador" ? "admin" : currentUser?.perfil;
      if (!currentUser || currentUser.status !== "ativo" || currentRole !== user.perfil) {
        return reply(res, 401, { mensagem: "Sessao revogada ou perfil alterado. Faca login novamente." }, origin);
      }
    }

    if (req.method === "GET" && route === "/chatbot/contexto") {
      const farms = await farmsForOrganization(c);
      if (!farms.length) {
        return reply(res, 200, { consultado_em: new Date().toISOString(), ocorrencias: [], sensores: [] }, origin);
      }
      const plots = await db(
        c,
        "talhao",
        "GET",
        undefined,
        `?fazenda_id=in.(${farms.map((farm) => farm.id).join(",")})&select=id,codigo`
      );
      if (!plots.length) {
        return reply(res, 200, { consultado_em: new Date().toISOString(), ocorrencias: [], sensores: [] }, origin);
      }
      const plotIds = plots.map((plot) => plot.id);
      const [occurrences, devices] = await Promise.all([
        db(
          c,
          "ocorrencia",
          "GET",
          undefined,
          `?talhao_id=in.(${plotIds.join(",")})&select=talhao_id,tipo,observacao,registrado_em&order=registrado_em.desc&limit=10`
        ),
        db(
          c,
          "dispositivo",
          "GET",
          undefined,
          `?talhao_id=in.(${plotIds.join(",")})&select=id,id_externo,talhao_id,status,ultimo_sinal_em`
        ),
      ]);
      const deviceIds = devices.map((device) => device.id);
      const sensors = deviceIds.length
        ? await db(
          c,
          "sensor",
          "GET",
          undefined,
          `?dispositivo_id=in.(${deviceIds.join(",")})&select=id,id_externo,dispositivo_id,codigo_metrica,unidade,status`
        )
        : [];
      const sensorIds = sensors.map((sensor) => sensor.id);
      const readings = sensorIds.length
        ? await db(
          c,
          "v_ultima_leitura_sensor",
          "GET",
          undefined,
          `?sensor_id=in.(${sensorIds.join(",")})&select=sensor_id,valor,unidade,coletado_em`
        )
        : [];
      const plotById = new Map(plots.map((plot) => [plot.id, plot.codigo]));
      const deviceById = new Map(devices.map((device) => [device.id, device]));
      const readingBySensor = new Map(readings.map((reading) => [reading.sensor_id, reading]));
      const recentOccurrences = occurrences.map((occurrence) => ({
        talhao: plotById.get(occurrence.talhao_id) || null,
        tipo: occurrence.tipo,
        observacao: occurrence.observacao,
        data: occurrence.registrado_em,
      }));
      const sensorStatuses = sensors.map((sensor) => {
        const device = deviceById.get(sensor.dispositivo_id);
        const reading = readingBySensor.get(sensor.id);
        const status = sensor.status !== "ativo"
          ? "Inativo"
          : device?.status === "online"
            ? "Online"
            : device?.status === "manutencao"
              ? "Manutencao"
              : device?.status === "desativado"
                ? "Desativado"
                : "Offline";
        return {
          sensor: sensor.id_externo,
          talhao: device ? plotById.get(device.talhao_id) || null : null,
          metrica: sensor.codigo_metrica,
          unidade: sensor.unidade,
          status,
          leitura: reading ? `${reading.valor} ${reading.unidade || sensor.unidade}` : "Sem leitura",
          coletado_em: reading?.coletado_em || device?.ultimo_sinal_em || null,
        };
      });

      return reply(res, 200, {
        consultado_em: new Date().toISOString(),
        ocorrencias: recentOccurrences,
        sensores: sensorStatuses,
      }, origin);
    }

    // começando a add  rotas para o predados-nucleo.js

    if (req.method === "GET" && route === "/predador/analise") {
      // O tecnico entra aqui junto com engenheiro e admin: e ele quem esta no
      // campo e age sobre o alerta, entao negar o diagnostico a ele seria
      // esconder a informacao de quem vai usa-la. A rota e somente leitura e ja
      // limitada a organizacao do usuario (farmsForOrganization logo abaixo),
      // entao abrir para o tecnico nao expoe talhao de outra fazenda.
      if (!["engenheiro", "tecnico", "admin"].includes(user.perfil)) {
        return reply(res, 403, { mensagem: "Acesso negado." }, origin);
      }
      //passo 2.2 os dados reais 

      const farms = await farmsForOrganization(c);
      if (!farms.length) {
        return reply(res, 200, { consultado_em: new Date().toISOString(), talhoes: [] }, origin);
      }

      const talhoes = await listarTalhoesComTemperatura(
        c,
        `?fazenda_id=in.(${farms.map((farm) => farm.id).join(",")})&arquivado_em=is.null&select=id,codigo,nome,temperatura_maxima&order=codigo`
      );

      const talhaoIds = talhoes.map((talhao) => talhao.id);
      const dispositivos = talhaoIds.length
        ? await db(c, "dispositivo", "GET", undefined,
          `?talhao_id=in.(${talhaoIds.join(",")})&select=id,id_externo,talhao_id,status`)
        : [];

      const dispositivoIds = dispositivos.map((dispositivo) => dispositivo.id);
      const sensores = dispositivoIds.length
        ? await db(c, "sensor", "GET", undefined,
          `?dispositivo_id=in.(${dispositivoIds.join(",")})&status=eq.ativo&select=id,dispositivo_id,codigo_metrica,unidade,status`)
        : [];

      const sensorIds = sensores.map((sensor) => sensor.id);
      const ultimasLeituras = sensorIds.length
        ? await db(c, "v_ultima_leitura_sensor", "GET", undefined,
          `?sensor_id=in.(${sensorIds.join(",")})&select=sensor_id,valor,unidade,qualidade,coletado_em`)
        : [];

      const regras = await db(c, "regra_alerta", "GET", undefined, "?habilitado=is.true&select=*");

      // Quais talhoes tem cultura plantada agora. Sem isso o nucleo julgaria
      // um talhao colhido contra o teto de temperatura da cultura anterior.
      const ciclos = talhaoIds.length
        ? await db(c, "ciclo_cultura", "GET", undefined, `?talhao_id=in.(${talhaoIds.join(",")})&status=eq.ativo&select=id,talhao_id,status`)
        : [];

      const resultados = diagnosticarTalhoes({ talhoes, dispositivos, sensores, ultimasLeituras, regras, ciclos });

      return reply(res, 200, {
        consultado_em: new Date().toISOString(),
        talhoes: resultados,
      }, origin);
    }




    //rota do predador/analise fim 





    if (route === "/alterar-senha" && req.method === "POST") {
      const d = await parseBody(req);
      if (
        typeof d.senhaAtual !== "string" ||
        d.senhaAtual.length < 8 ||
        d.senhaAtual.length > 10 ||
        typeof d.novaSenha !== "string" ||
        d.novaSenha.length < 8 ||
        d.novaSenha.length > 10 ||
        d.novaSenha === d.senhaAtual
      ) {
        return reply(res, 400, { mensagem: "Informe a senha atual e uma senha nova diferente, ambas entre 8 e 10 caracteres." }, origin);
      }

      const current = (await db(
        c,
        "usuario",
        "GET",
        undefined,
        `?id=eq.${encodeURIComponent(user.sub)}&select=id,matricula,nome_completo,perfil,senha_hash,status&limit=1`
      ))[0];
      if (!current || current.status !== "ativo" || !passwordOk(d.senhaAtual, current.senha_hash)) {
        return reply(res, 401, { mensagem: "Senha atual inválida." }, origin);
      }

      await db(c, `usuario?id=eq.${encodeURIComponent(user.sub)}`, "PATCH", {
        senha_hash: hashPassword(d.novaSenha),
        senha_temporaria: false
      });

      const updatedUser = {
        id: current.id,
        matricula: current.matricula,
        nome: current.nome_completo,
        perfil: current.perfil === "administrador" ? "admin" : current.perfil,
        mustChangePassword: false
      };
      return reply(res, 200, {
        sucesso: true,
        usuario: updatedUser,
        token: criarToken(updatedUser, c.jwt)
      }, origin);
    }

    if (user.mustChangePassword) {
      return reply(res, 403, {
        mensagem: "Altere sua senha provisória antes de continuar.",
        codigo: "SENHA_PROVISORIA"
      }, origin);
    }

    if (req.method === "GET" && route === "/telemetria/thingspeak") {
      if (!c.thingSpeak.channelId) {
        return reply(res, 503, {
          mensagem: "ThingSpeak não configurado. Defina THINGSPEAK_CHANNEL_ID no servidor.",
          codigo: "THINGSPEAK_NAO_CONFIGURADO"
        }, origin);
      }

      const feedUrl = new URL(
        `https://api.thingspeak.com/channels/${encodeURIComponent(c.thingSpeak.channelId)}/feeds.json`
      );
      feedUrl.searchParams.set("results", "60");
      if (c.thingSpeak.readApiKey) feedUrl.searchParams.set("api_key", c.thingSpeak.readApiKey);

      let feedResponse;
      try {
        feedResponse = await fetch(feedUrl, { signal: AbortSignal.timeout(10000) });
      } catch (error) {
        console.error("Falha ao consultar ThingSpeak:", error.message);
        return reply(res, 502, { mensagem: "ThingSpeak indisponível no momento." }, origin);
      }
      if (!feedResponse.ok) {
        console.error(`ThingSpeak respondeu HTTP ${feedResponse.status}.`);
        return reply(res, 502, { mensagem: "ThingSpeak recusou a consulta do canal configurado." }, origin);
      }
      const feed = await feedResponse.json();
      if (!Array.isArray(feed.feeds)) {
        return reply(res, 502, { mensagem: "Resposta inválida do canal ThingSpeak." }, origin);
      }
      return reply(res, 200, {
        channel: {
          id: feed.channel?.id,
          name: feed.channel?.name || "Canal ThingSpeak"
        },
        fields: c.thingSpeak.fields,
        feeds: feed.feeds.map((item) => ({
          created_at: item.created_at,
          values: Object.fromEntries(
            Object.entries(c.thingSpeak.fields).map(([metric, field]) => [
              metric,
              item[`field${field}`] === null || item[`field${field}`] === undefined
                ? null
                : Number(item[`field${field}`])
            ])
          )
        }))
      }, origin);
    }

    if (req.method === "GET" && route === "/colheitas/anual") {
      if (!["engenheiro", "admin"].includes(user.perfil)) {
        return reply(res, 403, { mensagem: "Sem permissão." }, origin);
      }
      const harvests = await db(
        c,
        "colheita",
        "GET",
        undefined,
        "?arquivado_em=is.null&select=ano,quantidade,unidade&order=ano&limit=10000"
      );
      const annual = new Map();
      harvests.forEach((row) => {
        const key = `${row.ano}:${row.unidade}`;
        const item = annual.get(key) || { ano: row.ano, unidade: row.unidade, quantidade: 0 };
        item.quantidade += Number(row.quantidade);
        annual.set(key, item);
      });
      return reply(
        res,
        200,
        { colheitas: [...annual.values()].sort((a, b) => a.ano - b.ano || a.unidade.localeCompare(b.unidade)) },
        origin
      );
    }

    if (req.method === "GET" && route === "/telemetria/esp32-mensal") {
      if (!c.thingSpeak.channelId) return reply(res, 200, { mensal: [] }, origin);
      try {
        const agora = new Date();
        const hoje = agora.toISOString().slice(0, 10);
        const inicio = new Date(Date.UTC(agora.getUTCFullYear(), agora.getUTCMonth() - 11, 1)).toISOString().slice(0, 10);
        const fim = agora.toISOString().slice(0, 19).replace("T", " ");
        const base = `https://api.thingspeak.com/channels/${encodeURIComponent(c.thingSpeak.channelId)}/feeds.json`;
        const chaveLeitura = c.thingSpeak.readApiKey ? `&api_key=${encodeURIComponent(c.thingSpeak.readApiKey)}` : "";
        const campos = Object.entries(c.thingSpeak.fields);
        const valido = (valor) => valor !== null && valor !== undefined && valor !== "" && Number.isFinite(Number(valor));

        // 1) Média diária: serve para descobrir em quais dias o ESP32 enviou dados.
        const resposta = await fetch(
          `${base}?average=daily&start=${encodeURIComponent(`${inicio} 00:00:00`)}&end=${encodeURIComponent(fim)}${chaveLeitura}`,
          { signal: AbortSignal.timeout(10000) }
        );
        if (!resposta.ok) return reply(res, 200, { mensal: [] }, origin);
        const corpo = await resposta.json();
        const feedsDiarios = (corpo.feeds || []).filter((feed) => campos.some(([, campo]) => valido(feed[`field${campo}`])));

        // 2) Leituras brutas de cada dia com dados: dão mínimo, máximo e quantidade de leituras.
        //    Dias passados não mudam, então ficam guardados em memória; o dia de hoje é consultado de novo a cada 60 s.
        if (!globalThis.__cacheEsp32Dias) globalThis.__cacheEsp32Dias = new Map();
        const cache = globalThis.__cacheEsp32Dias;
        const estatisticasDoDia = async (dia) => {
          const guardado = cache.get(dia);
          if (guardado && (dia < hoje || Date.now() - guardado.em < 60000)) return guardado.estatisticas;
          const brutas = await fetch(
            `${base}?results=8000&start=${encodeURIComponent(`${dia} 00:00:00`)}&end=${encodeURIComponent(`${dia} 23:59:59`)}${chaveLeitura}`,
            { signal: AbortSignal.timeout(10000) }
          );
          if (!brutas.ok) throw new Error(`ThingSpeak respondeu HTTP ${brutas.status} para ${dia}`);
          const dados = await brutas.json();
          const estatisticas = {};
          (dados.feeds || []).forEach((feed) => {
            campos.forEach(([metrica, campo]) => {
              const bruto = feed[`field${campo}`];
              if (!valido(bruto)) return;
              const numero = Number(bruto);
              const item = estatisticas[metrica] || { soma: 0, n: 0, min: numero, max: numero };
              item.soma += numero;
              item.n += 1;
              item.min = Math.min(item.min, numero);
              item.max = Math.max(item.max, numero);
              estatisticas[metrica] = item;
            });
          });
          cache.set(dia, { estatisticas, em: Date.now() });
          return estatisticas;
        };

        const meses = new Map();
        let completo = true;
        const dias = feedsDiarios.map((feed) => String(feed.created_at).slice(0, 10));
        try {
          for (let i = 0; i < dias.length; i += 4) {
            const lote = dias.slice(i, i + 4);
            const resultados = await Promise.all(lote.map(estatisticasDoDia));
            resultados.forEach((estatisticas, indice) => {
              const mes = lote[indice].slice(0, 7);
              Object.entries(estatisticas).forEach(([metrica, dado]) => {
                const chave = `${metrica}:${mes}`;
                const item = meses.get(chave) || { mes, codigo_metrica: metrica, soma: 0, n: 0, min: dado.min, max: dado.max };
                item.soma += dado.soma;
                item.n += dado.n;
                item.min = Math.min(item.min, dado.min);
                item.max = Math.max(item.max, dado.max);
                meses.set(chave, item);
              });
            });
          }
        } catch (erro) {
          // Se as leituras brutas falharem, volta para a média das médias diárias (sem mínimo, máximo e leituras).
          console.error("ThingSpeak: leituras brutas indisponíveis, usando só a média diária:", erro.message);
          completo = false;
          meses.clear();
          feedsDiarios.forEach((feed) => {
            const mes = String(feed.created_at).slice(0, 7);
            campos.forEach(([metrica, campo]) => {
              const bruto = feed[`field${campo}`];
              if (!valido(bruto)) return;
              const chave = `${metrica}:${mes}`;
              const item = meses.get(chave) || { mes, codigo_metrica: metrica, soma: 0, n: 0 };
              item.soma += Number(bruto);
              item.n += 1;
              meses.set(chave, item);
            });
          });
        }
        const mensal = [...meses.values()].map((item) => ({
          mes: item.mes,
          codigo_metrica: item.codigo_metrica,
          valor_medio: Number((item.soma / item.n).toFixed(2)),
          ...(completo ? {
            valor_minimo: Number(item.min.toFixed(2)),
            valor_maximo: Number(item.max.toFixed(2)),
            leituras_contabilizadas: item.n
          } : {})
        }));
        return reply(res, 200, { mensal }, origin);
      } catch (error) {
        console.error("ThingSpeak mensal indisponível:", error.message);
        return reply(res, 200, { mensal: [] }, origin);
      }
    }

    // Telemetria diária por talhão, usada pelos gráficos do painel.
    const telemetriaTalhaoMatch = route.match(/^\/telemetria\/talhao\/([^/]+)$/);
    if (telemetriaTalhaoMatch && req.method === "GET") {
      const codigoTalhao = decodeURIComponent(telemetriaTalhaoMatch[1]);

      const farms = await farmsForOrganization(c);
      if (!farms.length) return reply(res, 200, { talhao: codigoTalhao, metricas: {} }, origin);

      const plot = (await db(c, "talhao", "GET", undefined,
        `?codigo=eq.${encodeURIComponent(codigoTalhao)}&fazenda_id=in.(${farms.map((farm) => farm.id).join(",")})&arquivado_em=is.null&select=id,codigo&limit=1`))[0];
      if (!plot) return reply(res, 404, { mensagem: "Talhão não encontrado nesta organização." }, origin);

      const devices = await db(c, "dispositivo", "GET", undefined,
        `?talhao_id=eq.${encodeURIComponent(plot.id)}&status=neq.desativado&select=id`);
      const deviceIds = devices.map((device) => device.id);

      const sensors = deviceIds.length
        ? await db(c, "sensor", "GET", undefined,
          `?dispositivo_id=in.(${deviceIds.join(",")})&status=eq.ativo&select=id,codigo_metrica,unidade`)
        : [];
      const sensorIds = sensors.map((sensor) => sensor.id);

      const readings = sensorIds.length
        ? await db(c, "leitura_sensor", "GET", undefined,
          `?sensor_id=in.(${sensorIds.join(",")})&select=sensor_id,valor,unidade,qualidade,coletado_em&order=coletado_em.desc&limit=600`)
        : [];

      const metricaPorSensor = new Map(sensors.map((sensor) => [sensor.id, sensor]));
      const metricas = {};
      for (const sensor of sensors) {
        metricas[sensor.codigo_metrica] = { unidade: sensor.unidade, pontos: [] };
      }
      for (const reading of readings) {
        const sensor = metricaPorSensor.get(reading.sensor_id);
        if (!sensor) continue;
        metricas[sensor.codigo_metrica].pontos.push({
          em: reading.coletado_em,
          valor: Number(reading.valor),
          qualidade: reading.qualidade
        });
      }

      for (const metrica of Object.values(metricas)) metrica.pontos.reverse();

      return reply(res, 200, {
        talhao: plot.codigo,
        consultado_em: new Date().toISOString(),
        metricas
      }, origin);
    }

    // Rota de leitura CRUA por talhao, para os graficos de tempo real.
    // Nao confundir com /telemetria/diaria, logo abaixo: aquela agrega por dia
    // (valor_medio/minimo/maximo) e serve para historico. Um grafico de tempo real
    // com um ponto por dia nao mostraria nada acontecendo.





    if (req.method === "GET" && route === "/telemetria/diaria") {
      const agora = new Date();
      const desde = `${agora.getUTCFullYear()}-${String(agora.getUTCMonth() + 1).padStart(2, "0")}-01`;
      const inicioHistorico = new Date(Date.UTC(agora.getUTCFullYear(), agora.getUTCMonth() - 11, 1))
        .toISOString()
        .slice(0, 10);
      const [plots, readings] = await Promise.all([
        db(c, "talhao", "GET", undefined, "?select=id,codigo"),
        db(
          c,
          "v_telemetria_diaria_talhao",
          "GET",
          undefined,
          `?dia=gte.${inicioHistorico}&select=talhao_id,codigo_metrica,dia,valor_medio,valor_minimo,valor_maximo,leituras_contabilizadas&order=dia.desc&limit=10000`
        )
      ]);
      const plotCodes = new Map(plots.map((plot) => [plot.id, plot.codigo]));
      const monthly = new Map();
      readings.forEach((reading) => {
        const mes = reading.dia.slice(0, 7);
        const key = `${reading.talhao_id}:${reading.codigo_metrica}:${mes}`;
        const quantidade = Number(reading.leituras_contabilizadas);
        const item = monthly.get(key) || {
          talhao_id: reading.talhao_id,
          talhao: plotCodes.get(reading.talhao_id) || null,
          codigo_metrica: reading.codigo_metrica,
          mes,
          somaPonderada: 0,
          leituras_contabilizadas: 0,
          valor_minimo: Number(reading.valor_minimo),
          valor_maximo: Number(reading.valor_maximo)
        };
        item.somaPonderada += Number(reading.valor_medio) * quantidade;
        item.leituras_contabilizadas += quantidade;
        item.valor_minimo = Math.min(item.valor_minimo, Number(reading.valor_minimo));
        item.valor_maximo = Math.max(item.valor_maximo, Number(reading.valor_maximo));
        monthly.set(key, item);
      });
      const leiaDiaria = readings
        .filter((reading) => reading.dia >= desde)
        .map((reading) => ({
          ...reading,
          talhao: plotCodes.get(reading.talhao_id) || null
        }));
      const leiaMensal = [...monthly.values()]
        .map((item) => ({
          ...item,
          valor_medio: Number((item.somaPonderada / item.leituras_contabilizadas).toFixed(2))
        }))
        .sort((a, b) => b.mes.localeCompare(a.mes) || (a.talhao || "").localeCompare(b.talhao || "") || a.codigo_metrica.localeCompare(b.codigo_metrica));
      return reply(res, 200, { desde, leituras: leiaDiaria, mensal: leiaMensal }, origin);
    }

    if (req.method === "POST" && route === "/colheitas") {
      if (!["engenheiro", "admin"].includes(user.perfil)) {
        return reply(res, 403, { mensagem: "Somente Engenharia e Administração podem registrar colheitas." }, origin);
      }
      const d = await parseBody(req);
      const colhidoEm = date(d.colhidoEm);
      const quantidade = Number(d.quantidade);
      if (
        !text(d.talhao, 40) ||
        !colhidoEm ||
        !Number.isFinite(quantidade) ||
        quantidade <= 0 ||
        !["kg", "t", "sc", "cx"].includes(d.unidade)
      ) {
        return reply(res, 400, { mensagem: "Informe talhão, data, quantidade positiva e unidade valida." }, origin);
      }
      const plot = (await db(
        c,
        "talhao",
        "GET",
        undefined,
        `?codigo=eq.${encodeURIComponent(d.talhao)}&arquivado_em=is.null&select=id&limit=1`
      ))[0];
      if (!plot) return reply(res, 404, { mensagem: "Talhão não encontrado." }, origin);

      const cicloAtivo = (await db(
        c,
        "ciclo_cultura",
        "GET",
        undefined,
        `?talhao_id=eq.${encodeURIComponent(plot.id)}&status=eq.ativo&select=id&order=plantado_em.desc&limit=1`
      ))[0];
      const finalizarCiclo = d.finalizarCiclo === true || d.finalizarCiclo === "true";
      if (finalizarCiclo && !cicloAtivo) {
        return reply(res, 409, { mensagem: "Não há plantio ativo neste talhão para encerrar." }, origin);
      }
      if (finalizarCiclo) {
        await db(c, "ciclo_cultura", "PATCH", { status: "encerrado", encerrado_em: colhidoEm }, `?id=eq.${encodeURIComponent(cicloAtivo.id)}`);
      }

      let created;
      try {
        created = await db(c, "colheita", "POST", {
          ciclo_cultura_id: cicloAtivo?.id || null,
          talhao_id: plot.id,
          colhido_em: colhidoEm,
          quantidade,
          unidade: d.unidade,
          ano: Number(colhidoEm.slice(0, 4)),
          registrado_por: user.sub
        });
      } catch (erro) {
        if (finalizarCiclo) {
          await db(c, "ciclo_cultura", "PATCH", { status: "ativo", encerrado_em: null }, `?id=eq.${encodeURIComponent(cicloAtivo.id)}`);
        }
        throw erro;
      }
      const harvest = Array.isArray(created) ? created[0] : created;
      if (!harvest?.id) {
        if (finalizarCiclo) {
          await db(c, "ciclo_cultura", "PATCH", { status: "ativo", encerrado_em: null }, `?id=eq.${encodeURIComponent(cicloAtivo.id)}`);
        }
        throw new Error("O banco não confirmou a gravacao da colheita. Atualize o esquema e tente novamente.");
      }
      return reply(res, 201, { sucesso: true, colheita: harvest, cicloEncerrado: finalizarCiclo }, origin);
    }

    const reportMatch = route.match(/^\/relatorios-diarios(?:\/([^/]+))?$/);
    if (reportMatch) {
      const reportId = reportMatch[1] ? decodeURIComponent(reportMatch[1]) : null;

      if (req.method === "GET" && !reportId) {
        const ehTecnico = user.perfil === "tecnico";
        if (!ehTecnico && !["engenheiro", "admin"].includes(user.perfil)) {
          return reply(res, 403, { mensagem: "Sem permissão para consultar relatórios." }, origin);
        }
        const filtroAutor = ehTecnico ? `&usuario_id=eq.${encodeURIComponent(user.sub)}` : "";
        const reports = await db(
          c, "relatorio_campo_diario", "GET", undefined,
          `?select=id,usuario_id,tecnico_nome,data_relatorio,conteudo,status,criado_em,atualizado_em,arquivado_em&order=data_relatorio.desc,criado_em.desc&limit=500${filtroAutor}`
        );
        // A matrícula vem do cadastro atual do técnico; o relatório guarda o usuário autor pelo ID.
        const authorIds = [...new Set(reports.map((report) => report.usuario_id).filter(Boolean))];
        const authors = authorIds.length
          ? await db(c, "usuario", "GET", undefined, `?id=in.(${authorIds.map(encodeURIComponent).join(",")})&select=id,matricula`)
          : [];
        const matriculaPorAutor = new Map(authors.map((author) => [author.id, author.matricula]));
        const reportsWithAuthor = reports.map((report) => ({
          ...report,
          tecnico_matricula: matriculaPorAutor.get(report.usuario_id) || "Não informada"
        }));
        return reply(res, 200, { relatorios: reportsWithAuthor }, origin);
      }

      if (req.method === "POST" && !reportId) {
        if (user.perfil !== "tecnico") return reply(res, 403, { mensagem: "Somente o Técnico pode enviar relatórios diários." }, origin);
        const d = await parseBody(req);
        const dataRelatorio = date(d.data);
        const conteudo = text(d.conteudo, 6000);
        if (!dataRelatorio || !conteudo) {
          return reply(res, 400, { mensagem: "Informe uma data valida e um relatório de campo (até 6000 caracteres)." }, origin);
        }

        const existente = (await db(
          c,
          "relatorio_campo_diario",
          "GET",
          undefined,
          `?usuario_id=eq.${encodeURIComponent(user.sub)}&data_relatorio=eq.${dataRelatorio}&select=id&limit=1`
        ))[0];
        if (existente) return reply(res, 409, { mensagem: "Já existe um relatório enviado para esta data." }, origin);

        const created = await db(c, "relatorio_campo_diario", "POST", {
          usuario_id: user.sub,
          tecnico_nome: text(user.nome, 255) || user.matricula,
          data_relatorio: dataRelatorio,
          conteudo,
          status: "enviado"
        });
        const report = Array.isArray(created) ? created[0] : created;
        return reply(res, 201, { sucesso: true, relatorio: report }, origin);
      }

      if (req.method === "DELETE" && reportId) {
        if (!["engenheiro", "admin"].includes(user.perfil)) {
          return reply(res, 403, { mensagem: "Apenas Engenharia e Administração podem excluir relatórios." }, origin);
        }
        const report = (await db(
          c,
          "relatorio_campo_diario",
          "GET",
          undefined,
          `?id=eq.${encodeURIComponent(reportId)}&select=id&limit=1`
        ))[0];
        if (!report) return reply(res, 404, { mensagem: "Relatório não encontrado." }, origin);
        await db(
          c,
          "relatorio_campo_diario",
          "DELETE",
          undefined,
          `?id=eq.${encodeURIComponent(reportId)}`
        );
        return reply(res, 200, { sucesso: true, excluido: true }, origin);
      }

      if (req.method === "PATCH" && reportId) {
        if (!["engenheiro", "admin"].includes(user.perfil)) {
          return reply(res, 403, { mensagem: "Apenas Engenharia e Administração podem acompanhar relatórios." }, origin);
        }
        const d = await parseBody(req);
        const atualizarStatus = d.status !== undefined;
        const atualizarArquivo = typeof d.arquivado === "boolean";
        if ((atualizarStatus && !["em_analise", "concluido"].includes(d.status)) || (!atualizarStatus && !atualizarArquivo)) {
          return reply(res, 400, { mensagem: "Informe um status válido ou a situação de arquivamento." }, origin);
        }
        const report = (await db(
          c,
          "relatorio_campo_diario",
          "GET",
          undefined,
          `?id=eq.${encodeURIComponent(reportId)}&select=id&limit=1`
        ))[0];
        if (!report) return reply(res, 404, { mensagem: "Relatório não encontrado." }, origin);
        const atualizacao = {};
        if (atualizarStatus) atualizacao.status = d.status;
        if (atualizarArquivo) atualizacao.arquivado_em = d.arquivado ? new Date().toISOString() : null;
        await db(c, `relatorio_campo_diario?id=eq.${encodeURIComponent(reportId)}`, "PATCH", atualizacao);
        return reply(res, 200, { sucesso: true, arquivado: atualizarArquivo ? d.arquivado : undefined }, origin);
      }

      return reply(res, 405, { mensagem: "Método não permitido para esta rota." }, origin);
    }

    // 4. Rotas Granulares: Talhões
    if (req.method === "GET" && route === "/talhoes") {
      const farms = await farmsForOrganization(c);
      if (!farms.length) return reply(res, 503, { mensagem: "Fazenda não configurada." }, origin);
      const filtroFazendas = `fazenda_id=in.(${farms.map((farm) => farm.id).join(",")})`;
      const [plots, arquivados] = await Promise.all([
        listarTalhoesComTemperatura(
          c,
          `?${filtroFazendas}&arquivado_em=is.null&select=id,codigo,nome,area_hectares,coordenadas,temperatura_maxima&order=codigo`
        ),
        db(c, "talhao", "GET", undefined, `?${filtroFazendas}&arquivado_em=not.is.null&select=codigo&order=codigo`)
      ]);
      // Os códigos arquivados seguem ocupados no banco: o editor usa esta lista
      // para nunca gerar um código novo que colida com um talhão do histórico.
      return reply(
        res,
        200,
        { talhoes: plots, codigos_arquivados: arquivados.map((plot) => plot.codigo) },
        origin
      );
    }

    if (req.method === "PUT" && route === "/talhoes/geometrias") {
      if (!["engenheiro", "admin"].includes(user.perfil)) return reply(res, 403, { mensagem: "Somente Engenharia e Administração podem alterar geometrias e áreas dos talhões." }, origin);
      const d = await parseBody(req, 1048576);
      if (!Array.isArray(d.talhoes) || d.talhoes.length > 500 || !Array.isArray(d.removidos)) {
        return reply(res, 400, { mensagem: "Colecao de talhões inválida." }, origin);
      }

      const codigos = new Set();
      for (const feature of d.talhoes) {
        const codigo = text(feature?.properties?.codigo, 40);
        const areaTexto = feature?.properties?.area_hectares ?? feature?.properties?.area;
        const area = Number(String(areaTexto ?? "").replace(/[^\d,.-]/g, "").replace(",", "."));
        const pontos = feature?.geometry?.type === "Polygon" ? feature.geometry.coordinates?.[0] : null;
        if (
          !codigo ||
          codigos.has(codigo) ||
          !Number.isFinite(area) ||
          area <= 0 ||
          area > 1000000 ||
          !Array.isArray(pontos) ||
          pontos.length < 4 ||
          pontos.length > 1001
        ) {
          return reply(res, 400, { mensagem: `Geometria ou área inválida para o talhão ${codigo || "(sem codigo)"}.` }, origin);
        }
        codigos.add(codigo);
        for (const ponto of pontos) {
          if (
            !Array.isArray(ponto) ||
            ponto.length !== 2 ||
            !ponto.every(Number.isFinite) ||
            ponto[0] < 0 || ponto[0] > 500 ||
            ponto[1] < 0 || ponto[1] > 400
          ) {
            return reply(res, 400, { mensagem: `Coordenadas inválidas para o talhão ${codigo}.` }, origin);
          }
        }
        if (pontos[0][0] !== pontos[pontos.length - 1][0] || pontos[0][1] !== pontos[pontos.length - 1][1]) {
          return reply(res, 400, { mensagem: `O contorno do talhão ${codigo} deve ser fechado.` }, origin);
        }
        feature.properties.codigo = codigo;
        feature.properties.area_hectares = area;
      }

      const removidos = d.removidos.map((codigo) => text(codigo, 40));
      if (removidos.some((codigo) => !codigo || codigos.has(codigo)) || new Set(removidos).size !== removidos.length) {
        return reply(res, 400, { mensagem: "Lista de talhões removidos inválida." }, origin);
      }

      const farms = await farmsForOrganization(c);
      if (!farms.length) return reply(res, 503, { mensagem: "Fazenda não configurada." }, origin);

      const candidateCodes = [...new Set([
        ...d.talhoes.map((feature) => feature.properties.codigo),
        ...removidos
      ])];
      const existingPlots = candidateCodes.length
        ? await db(
          c,
          "talhao",
          "GET",
          undefined,
          `?fazenda_id=in.(${farms.map((farm) => farm.id).join(",")})&codigo=in.(${candidateCodes.map(encodeURIComponent).join(",")})&select=id,codigo,fazenda_id,arquivado_em`
        )
        : [];
      const plotsAtivos = existingPlots.filter((plot) => !plot.arquivado_em);
      const farmIds = new Set(plotsAtivos.map((plot) => plot.fazenda_id));
      if (farmIds.size > 1) {
        return reply(
          res,
          409,
          { mensagem: "Os talhões enviados pertencem a mais de uma fazenda. Edite e salve uma fazenda por vez." },
          origin
        );
      }
      const farmId = farmIds.values().next().value || farms[0].id;
      const farm = farms.find((item) => item.id === farmId);

      // O código só está realmente ocupado quando o talhão arquivado é da mesma
      // fazenda que está sendo salva. Antes qualquer homônimo de outra fazenda
      // bloqueava o mapa inteiro, mesmo sem nenhuma relação com a edição atual.
      const codigosArquivados = new Set(
        existingPlots
          .filter((plot) => plot.arquivado_em && plot.fazenda_id === farm.id)
          .map((plot) => plot.codigo)
      );
      const conflitos = d.talhoes
        .map((feature) => feature.properties.codigo)
        .filter((codigo) => codigosArquivados.has(codigo));
      if (conflitos.length) {
        return reply(
          res,
          409,
          {
            mensagem: `Já existe um talhão arquivado com o código ${conflitos.join(", ")}. Renomeie o talhão ou restaure o original no histórico antes de salvar o mapa.`,
            codigos_arquivados: conflitos
          },
          origin
        );
      }

      const result = await db(c, "rpc/salvar_geometrias_talhoes", "POST", {
        p_fazenda_id: farm.id,
        p_features: d.talhoes,
        p_removidos: removidos
      });
      if (result?.erro) return reply(res, 409, { mensagem: result.erro }, origin);
      const persistedPlots = await db(
        c,
        "talhao",
        "GET",
        undefined,
        `?fazenda_id=eq.${encodeURIComponent(farm.id)}&arquivado_em=is.null&select=id,codigo,nome,area_hectares,coordenadas&order=codigo`
      );
      const persistedByCode = new Map(persistedPlots.map((plot) => [plot.codigo, plot]));
      const geometryConfirmed = d.talhoes.every((feature) => {
        const saved = persistedByCode.get(feature.properties.codigo);
        return saved && JSON.stringify(saved.coordenadas) === JSON.stringify(feature.geometry.coordinates[0]);
      });
      const removalsConfirmed = removidos.every((codigo) => !persistedByCode.has(codigo));
      if (!geometryConfirmed || !removalsConfirmed) {
        return reply(
          res,
          502,
          { mensagem: "O banco não confirmou todas as geometrias. As alteracoes não foram consideradas salvas; atualize os dados e tente novamente." },
          origin
        );
      }
      return reply(res, 200, { sucesso: true, talhoes: persistedPlots }, origin);
    }

    // 5. Rotas Granulares: Sensores e Última Leitura
    if (req.method === "GET" && route === "/sensores") {
      const farms = await farmsForOrganization(c);
      if (!farms.length) return reply(res, 200, { sensores: [] }, origin);
      const plots = await db(
        c,
        "talhao",
        "GET",
        undefined,
        `?fazenda_id=in.(${farms.map((farm) => farm.id).join(",")})&arquivado_em=is.null&select=id,codigo`
      );
      if (!plots.length) return reply(res, 200, { sensores: [] }, origin);
      const plotIds = plots.map((plot) => plot.id);
      const devices = await db(
        c,
        "dispositivo",
        "GET",
        undefined,
        `?talhao_id=in.(${plotIds.join(",")})&select=id,id_externo,talhao_id,status,ultimo_sinal_em`
      );
      if (!devices.length) return reply(res, 200, { sensores: [] }, origin);
      const sensors = await db(
        c,
        "sensor",
        "GET",
        undefined,
        `?dispositivo_id=in.(${devices.map((device) => device.id).join(",")})&select=id,id_externo,dispositivo_id,codigo_metrica,unidade,status`
      );
      const readings = sensors.length
        ? await db(
          c,
          "v_ultima_leitura_sensor",
          "GET",
          undefined,
          `?sensor_id=in.(${sensors.map((sensor) => sensor.id).join(",")})&select=sensor_id,valor,unidade,coletado_em`
        )
        : [];
      const plotMap = new Map(plots.map((p) => [p.id, p.codigo]));
      const deviceById = new Map(devices.map((d) => [d.id, d]));
      const readingBySensor = new Map(readings.map((r) => [r.sensor_id, r]));

      const sensorRows = sensors.map((s) => {
        const d = deviceById.get(s.dispositivo_id);
        const r = readingBySensor.get(s.id);
        const comunicacao = dataMaisRecente(r?.coletado_em, d?.ultimo_sinal_em);
        return {
          id: s.id,
          sensor: s.id_externo,
          talhao: d ? plotMap.get(d.talhao_id) : null,
          tipo: s.codigo_metrica,
          unidade: s.unidade,
          status: estadoSensor({
            statusSensor: s.status,
            statusDispositivo: d?.status,
            ultimaComunicacao: comunicacao
          }),
          ativo: s.status === "ativo",
          leitura: r ? `${r.valor} ${r.unidade}` : "Sem leitura",
          valor: r?.valor,
          comunicacao,
          ultima_leitura_em: r?.coletado_em || null,
          dados_recentes: dadosRecentes(r?.coletado_em)
        };
      });
      return reply(res, 200, { sensores: sensorRows }, origin);
    }

    // 6. Rotas Granulares: Inspeções
    if (req.method === "GET" && route === "/inspecoes") {
      const [plots, inspections] = await Promise.all([
        db(c, "talhao", "GET", undefined, "?select=id,codigo"),
        db(c, "inspecao", "GET", undefined, "?select=*&order=inspecionado_em.desc&limit=100")
      ]);
      const plotMap = new Map(plots.map((p) => [p.id, p.codigo]));
      const rows = inspections.map((i) => ({
        id: i.id,
        talhao_id: i.talhao_id,
        talhao: plotMap.get(i.talhao_id) || null,
        data: i.inspecionado_em ? i.inspecionado_em.slice(0, 10) : null,
        situacao: i.status ? i.status[0].toUpperCase() + i.status.slice(1) : "Normal",
        problemas: i.descricao_problema,
        observacoes: i.observacoes,
        sensor_id: i.sensor_id || null,
        criado_em: i.criado_em
      }));
      return reply(res, 200, { inspecoes: rows }, origin);
    }

    // 7. Rotas Granulares: Ocorrências
    if (req.method === "GET" && route === "/ocorrencias") {
      const [plots, occurrences] = await Promise.all([
        db(c, "talhao", "GET", undefined, "?select=id,codigo"),
        db(c, "ocorrencia", "GET", undefined, "?select=*&order=registrado_em.desc&limit=100")
      ]);
      const plotMap = new Map(plots.map((p) => [p.id, p.codigo]));
      const rows = occurrences.map((o) => ({
        id: o.id,
        talhao_id: o.talhao_id,
        talhao: plotMap.get(o.talhao_id) || null,
        tipo: o.tipo,
        observacao: o.observacao,
        data: o.registrado_em ? o.registrado_em.slice(0, 10) : null,
        criado_em: o.criado_em
      }));
      return reply(res, 200, { ocorrencias: rows }, origin);
    }

    // 8. Rotas Granulares: Problemas de Sensor
    if (req.method === "GET" && route === "/sensores/problemas") {
      const [plots, sensors, problems] = await Promise.all([
        db(c, "talhao", "GET", undefined, "?select=id,codigo"),
        db(c, "sensor", "GET", undefined, "?select=id,id_externo"),
        db(c, "problema_sensor", "GET", undefined, "?select=*&order=data.desc&limit=100")
      ]);
      const plotMap = new Map(plots.map((p) => [p.id, p.codigo]));
      const sensorMap = new Map(sensors.map((s) => [s.id, s.id_externo]));
      const rows = problems.map((pr) => ({
        id: pr.id,
        talhao_id: pr.talhao_id,
        talhao: plotMap.get(pr.talhao_id) || null,
        sensor_id: pr.sensor_id,
        sensor: sensorMap.get(pr.sensor_id) || null,
        data: pr.data,
        problema: pr.problema,
        observacao: pr.observacao,
        criado_em: pr.criado_em
      }));
      return reply(res, 200, { problemas: rows }, origin);
    }

    // 9. Rotas Granulares: Alertas
    if (req.method === "GET" && route === "/alertas") {
      const alerts = await db(c, "alerta", "GET", undefined, "?select=*&order=aberto_em.desc&limit=50");
      return reply(res, 200, { alertas: alerts }, origin);
    }

    // 10. Rotas Granulares: Plantios e Ciclos de Cultura
    if (req.method === "GET" && route === "/plantios") {
      const [plots, cultivars, cultures, cycles] = await Promise.all([
        db(c, "talhao", "GET", undefined, "?select=id,codigo"),
        db(c, "cultivar", "GET", undefined, "?select=id,nome,cultura_id"),
        db(c, "cultura", "GET", undefined, "?select=id,nome_comum"),
        db(c, "ciclo_cultura", "GET", undefined, "?select=*&order=plantado_em.desc&limit=100")
      ]);
      const plotMap = new Map(plots.map((p) => [p.id, p.codigo]));
      const cultivarMap = new Map(cultivars.map((cv) => [cv.id, cv]));
      const cultureMap = new Map(cultures.map((cu) => [cu.id, cu.nome_comum]));

      const rows = cycles.map((cy) => {
        const cv = cultivarMap.get(cy.cultivar_id);
        const produto = cv ? cultureMap.get(cv.cultura_id) : "";
        return {
          id: cy.id,
          talhao_id: cy.talhao_id,
          talhao: plotMap.get(cy.talhao_id) || null,
          produto: produto || "",
          variedade: cv ? cv.nome : "",
          area: cy.area_plantada_hectares,
          solo: cy.solo,
          dataPlantio: cy.plantado_em,
          dataColheita: cy.previsao_colheita,
          status: cy.status
        };
      });
      return reply(res, 200, { plantios: rows }, origin);
    }

    // 11. Painéis Compostos (BFF - Backend for Frontend)
    /**
     * PATCH /admin/historico-operacao/:tipo/:id
     * Arquiva ou restaura um registro do histórico sem apagá-lo do banco.
     * Somente perfil admin. O :tipo aceita "talhao", "ciclo" ou "colheita".
     * Corpo esperado: { arquivado: boolean }.
     * Responde 200 { sucesso, arquivado, registro }; 400 se o corpo não trouxer
     * o booleano; 404 se o registro não existir ou for de outra organização;
     * 409 se tentar arquivar um ciclo que ainda está ativo.
     */
    const archiveMatch = route.match(/^\/admin\/historico-operacao\/(talhao|ciclo|colheita)\/([^/]+)$/);
    if (req.method === "PATCH" && archiveMatch) {
      if (user.perfil !== "admin") return reply(res, 403, { mensagem: "Sem permissao." }, origin);
      const [, type, rawId] = archiveMatch;
      const id = decodeURIComponent(rawId);
      const data = await parseBody(req);
      if (typeof data.arquivado !== "boolean") {
        return reply(res, 400, { mensagem: "Informe se o registro deve ser arquivado." }, origin);
      }
      const farms = await farmsForOrganization(c);
      const farmIds = farms.map((farm) => farm.id);
      if (!farmIds.length) return reply(res, 503, { mensagem: "Fazenda nao configurada." }, origin);
      // ATENCAO (Supabase/PostgREST): cada tabela tem colunas diferentes e o
      // PostgREST devolve 400 ("column ... does not exist") se pedirmos uma
      // coluna ausente. Antes isto pedia id,talhao_id,status para as tres
      // tabelas, o que quebrava "Arquivar colheita" (colheita nao tem status) e
      // "Arquivar talhao" (talhao nao tem status nem talhao_id). Ao mexer aqui,
      // confira o esquema real em supabase/schema_oficial_atualizado.sql.
      const recursos = {
        talhao: { tabela: "talhao", colunas: "id,arquivado_em" },
        ciclo: { tabela: "ciclo_cultura", colunas: "id,talhao_id,status,arquivado_em" },
        colheita: { tabela: "colheita", colunas: "id,talhao_id,arquivado_em" }
      };
      const { tabela: resource, colunas } = recursos[type];
      const record = (await db(c, resource, "GET", undefined, `?id=eq.${encodeURIComponent(id)}&select=${colunas}&limit=1`))[0];
      if (!record) return reply(res, 404, { mensagem: "Registro historico nao encontrado." }, origin);
      const plotId = type === "talhao" ? record.id : record.talhao_id;
      const plot = (await db(c, "talhao", "GET", undefined, `?id=eq.${encodeURIComponent(plotId)}&fazenda_id=in.(${farmIds.join(",")})&select=id&limit=1`))[0];
      if (!plot) return reply(res, 404, { mensagem: "Registro nao pertence a fazenda desta organizacao." }, origin);

      if (data.arquivado && type === "ciclo" && record.status === "ativo") {
        return reply(res, 409, { mensagem: "Encerre o ciclo antes de arquiva-lo." }, origin);
      }
      const updated = await db(c, `${resource}?id=eq.${encodeURIComponent(id)}`, "PATCH", {
        arquivado_em: data.arquivado ? new Date().toISOString() : null
      });
      return reply(res, 200, { sucesso: true, arquivado: data.arquivado, registro: updated[0] || null }, origin);
    }

    if (req.method === "GET" && route === "/admin/historico-operacao") {
      if (user.perfil !== "admin") return reply(res, 403, { mensagem: "Sem permissao." }, origin);
      const farms = await farmsForOrganization(c);
      if (!farms.length) return reply(res, 503, { mensagem: "Fazenda nao configurada." }, origin);

      const [plots, cycles, cultivars, cultures, devices, sensors, alerts, harvests] = await Promise.all([
        db(c, "talhao", "GET", undefined, `?fazenda_id=in.(${farms.map((farm) => farm.id).join(",")})&select=id,codigo,area_hectares,criado_em,arquivado_em&order=codigo`),
        db(c, "ciclo_cultura", "GET", undefined, "?select=id,talhao_id,cultivar_id,plantado_em,previsao_colheita,encerrado_em,area_plantada_hectares,solo,status,criado_em,arquivado_em&order=plantado_em.desc"),
        db(c, "cultivar", "GET", undefined, "?select=id,nome,cultura_id"),
        db(c, "cultura", "GET", undefined, "?select=id,nome_comum"),
        db(c, "dispositivo", "GET", undefined, "?select=id,id_externo,talhao_id,status"),
        db(c, "sensor", "GET", undefined, "?select=id,id_externo,dispositivo_id,codigo_metrica,status"),
        db(c, "alerta", "GET", undefined, "?select=id,talhao_id,sensor_id,status,severidade,titulo,mensagem,aberto_em,fechado_em&order=aberto_em.desc&limit=500"),
        db(c, "colheita", "GET", undefined, "?select=id,talhao_id,ciclo_cultura_id,colhido_em,quantidade,unidade,ano,arquivado_em&order=colhido_em.desc&limit=500")
      ]);

      const plotById = new Map(plots.map((plot) => [plot.id, plot]));
      const deviceById = new Map(devices.map((device) => [device.id, device]));
      const cultivarById = new Map(cultivars.map((cultivar) => [cultivar.id, cultivar]));
      const cultureById = new Map(cultures.map((culture) => [culture.id, culture.nome_comum]));
      const sensorsByPlot = new Map();
      for (const sensor of sensors) {
        const plotId = deviceById.get(sensor.dispositivo_id)?.talhao_id;
        if (!plotId) continue;
        if (!sensorsByPlot.has(plotId)) sensorsByPlot.set(plotId, []);
        sensorsByPlot.get(plotId).push({ id: sensor.id, identificador: sensor.id_externo, metrica: sensor.codigo_metrica, status: sensor.status });
      }
      const alertsByPlot = new Map();
      for (const alert of alerts) {
        if (!alert.talhao_id) continue;
        if (!alertsByPlot.has(alert.talhao_id)) alertsByPlot.set(alert.talhao_id, []);
        alertsByPlot.get(alert.talhao_id).push(alert);
      }
      const harvestsByCycle = new Map();
      for (const harvest of harvests) {
        if (!harvest.ciclo_cultura_id) continue;
        if (!harvestsByCycle.has(harvest.ciclo_cultura_id)) harvestsByCycle.set(harvest.ciclo_cultura_id, []);
        harvestsByCycle.get(harvest.ciclo_cultura_id).push(harvest);
      }

      const historico = cycles.flatMap((cycle) => {
        const plot = plotById.get(cycle.talhao_id);
        if (!plot) return [];
        const cultivar = cultivarById.get(cycle.cultivar_id);
        return [{
          id: cycle.id, registroId: cycle.id, tipo: "ciclo", talhao: plot.codigo, talhaoId: plot.id, talhaoArquivadoEm: plot.arquivado_em,
          talhaoCriadoEm: plot.criado_em, areaTalhao: plot.area_hectares,
          areaPlantada: cycle.area_plantada_hectares,
          produto: cultureById.get(cultivar?.cultura_id) || "Produto nao informado",
          variedade: cultivar?.nome || "", plantadoEm: cycle.plantado_em,
          previsaoColheita: cycle.previsao_colheita, encerradoEm: cycle.encerrado_em,
          solo: cycle.solo, status: cycle.status, arquivadoEm: cycle.arquivado_em,
          sensores: sensorsByPlot.get(plot.id) || [], alertas: alertsByPlot.get(plot.id) || [],
          colheitas: harvestsByCycle.get(cycle.id) || []
        }];
      });
      const plotsWithCycles = new Set(cycles.map((cycle) => cycle.talhao_id));
      const cycleIds = new Set(cycles.map((cycle) => cycle.id));
      for (const harvest of harvests) {
        if (harvest.ciclo_cultura_id && cycleIds.has(harvest.ciclo_cultura_id)) continue;
        const plot = plotById.get(harvest.talhao_id);
        if (!plot) continue;
        historico.push({
          id: `colheita:${harvest.id}`, registroId: harvest.id, tipo: "colheita", talhao: plot.codigo,
          talhaoId: plot.id, talhaoArquivadoEm: plot.arquivado_em, talhaoCriadoEm: plot.criado_em, areaTalhao: plot.area_hectares,
          areaPlantada: null, produto: "Registro de colheita", variedade: "",
          plantadoEm: null, previsaoColheita: null, encerradoEm: null, solo: "",
          status: "colheita registrada", arquivadoEm: harvest.arquivado_em,
          sensores: sensorsByPlot.get(plot.id) || [],
          alertas: alertsByPlot.get(plot.id) || [], colheitas: [harvest]
        });
      }
      for (const plot of plots) {
        if (plotsWithCycles.has(plot.id)) continue;
        historico.push({
          id: `talhao:${plot.id}`, registroId: plot.id, tipo: "talhao", talhao: plot.codigo, talhaoId: plot.id,
          talhaoCriadoEm: plot.criado_em, areaTalhao: plot.area_hectares, areaPlantada: null,
          produto: "Sem ciclo cadastrado", variedade: "", plantadoEm: null,
          previsaoColheita: null, encerradoEm: null, solo: "", status: "sem ciclo",
          arquivadoEm: plot.arquivado_em,
          sensores: sensorsByPlot.get(plot.id) || [], alertas: alertsByPlot.get(plot.id) || [],
          colheitas: harvests.filter((harvest) => harvest.talhao_id === plot.id)
        });
      }
      return reply(res, 200, { historico }, origin);
    }

    if (req.method === "GET" && ["/painel-tecnico", "/painel-engenheiro"].includes(route)) {
      if (
        (route === "/painel-tecnico" && !["tecnico", "admin"].includes(user.perfil)) ||
        (route === "/painel-engenheiro" && !["engenheiro", "admin"].includes(user.perfil))
      ) {
        return reply(res, 403, { mensagem: "Sem permissão." }, origin);
      }

      const farms = await farmsForOrganization(c);
      if (!farms.length) return reply(res, 503, { mensagem: "Fazenda não configurada." }, origin);
      const plots = await listarTalhoesComTemperatura(
        c,
        `?fazenda_id=in.(${farms.map((farm) => farm.id).join(",")})&arquivado_em=is.null&select=id,codigo,nome,area_hectares,coordenadas,temperatura_maxima&order=codigo`
      );
      const plotIds = plots.map((plot) => plot.id);
      const devices = plotIds.length
        ? await db(c, "dispositivo", "GET", undefined,
          `?talhao_id=in.(${plotIds.join(",")})&select=id,id_externo,talhao_id,status,ultimo_sinal_em`)
        : [];
      const deviceIds = devices.map((device) => device.id);
      const sensors = deviceIds.length
        ? await db(c, "sensor", "GET", undefined,
          `?dispositivo_id=in.(${deviceIds.join(",")})&select=id,id_externo,dispositivo_id,codigo_metrica,unidade,status`)
        : [];
      const sensorIds = sensors.map((sensor) => sensor.id);
      const [readings, inspections, cycles, occurrences, sensorProblems, alerts, cultivars, cultures] = await Promise.all([
        sensorIds.length
          ? db(c, "v_ultima_leitura_sensor", "GET", undefined,
            `?sensor_id=in.(${sensorIds.join(",")})&select=sensor_id,valor,unidade,coletado_em`)
          : Promise.resolve([]),
        plotIds.length
          ? db(c, "inspecao", "GET", undefined,
            `?talhao_id=in.(${plotIds.join(",")})&select=*&order=inspecionado_em.desc&limit=30`)
          : Promise.resolve([]),
        plotIds.length
          ? db(c, "ciclo_cultura", "GET", undefined,
            `?talhao_id=in.(${plotIds.join(",")})&status=eq.ativo&select=id,talhao_id,cultivar_id,area_plantada_hectares,plantado_em,previsao_colheita,solo`)
          : Promise.resolve([]),
        plotIds.length
          ? db(c, "ocorrencia", "GET", undefined,
            `?talhao_id=in.(${plotIds.join(",")})&select=*&order=registrado_em.desc&limit=100`)
          : Promise.resolve([]),
        plotIds.length
          ? db(c, "problema_sensor", "GET", undefined,
            `?talhao_id=in.(${plotIds.join(",")})&select=*&order=data.desc&limit=100`)
          : Promise.resolve([]),
        plotIds.length
          ? db(c, "alerta", "GET", undefined,
            `?talhao_id=in.(${plotIds.join(",")})&status=eq.aberto&select=*&order=aberto_em.desc&limit=100`)
          : Promise.resolve([]),
        db(c, "cultivar", "GET", undefined, "?select=id,nome,cultura_id"),
        db(c, "cultura", "GET", undefined, "?select=id,nome_comum")
      ]);

      const readingBySensor = new Map(readings.map((r) => [r.sensor_id, r]));
      const deviceById = new Map(devices.map((d) => [d.id, d]));
      const cultivarById = new Map(cultivars.map((cultivar) => [cultivar.id, cultivar]));
      const cultureById = new Map(cultures.map((culture) => [culture.id, culture.nome_comum]));

      // Quem fez a inspecao. A tela do Engenheiro mostrava "Tecnico
      // responsavel: --" fixo no codigo porque este nome nunca chegava ate
      // la: o engenheiro via o problema apontado mas nao com quem falar
      // sobre ele -- e numa fazenda com mais de um tecnico isso custa uma
      // ligacao a cada duvida.
      //
      // So busca os usuarios realmente citados pelas inspecoes, em vez da
      // tabela inteira: a lista de funcionarios nao tem por que trafegar num
      // painel de campo.
      const autorIds = [...new Set(inspections.map((i) => i.usuario_id).filter(Boolean))];
      const autores = autorIds.length
        ? await db(c, "usuario", "GET", undefined, `?id=in.(${autorIds.join(",")})&select=id,nome_completo`)
        : [];
      const autorById = new Map(autores.map((u) => [u.id, u.nome_completo]));
      const sensorRows = sensors.map((s) => {
        const d = deviceById.get(s.dispositivo_id);
        const r = readingBySensor.get(s.id);
        const comunicacao = dataMaisRecente(r?.coletado_em, d?.ultimo_sinal_em);
        return {
          sensor: s.id_externo,
          talhao: d && plots.find((p) => p.id === d.talhao_id)?.codigo,
          status: estadoSensor({
            statusSensor: s.status,
            statusDispositivo: d?.status,
            ultimaComunicacao: comunicacao
          }),
          leitura: r ? `${r.valor} ${r.unidade}` : "Sem leitura",
          comunicacao,
          ultima_leitura_em: r?.coletado_em || null,
          dados_recentes: dadosRecentes(r?.coletado_em),
          id: s.id,
          tipo: s.codigo_metrica,
          ativo: s.status === "ativo",
          valor: r?.valor,
          unidade: s.unidade
        };
      });

      const ciclosOrdenados = [...cycles].sort((a, b) =>
        String(b.plantado_em || "").localeCompare(String(a.plantado_em || ""))
      );
      const cicloAtivoPorTalhao = new Map();
      for (const cycle of ciclosOrdenados) {
        if (!cicloAtivoPorTalhao.has(cycle.talhao_id)) cicloAtivoPorTalhao.set(cycle.talhao_id, cycle);
      }
      const talhoes = plots.map((p) => {
        const sensoresDoTalhao = sensorRows.filter((item) => item.talhao === p.codigo);
        const sensoresAtivos = sensoresDoTalhao.filter((item) => item.ativo);
        const s = sensoresAtivos.find((item) => item.tipo === "umidadeSolo" && item.valor !== null && item.valor !== undefined)
          || sensoresAtivos.find((item) => item.valor !== null && item.valor !== undefined)
          || sensoresAtivos[0]
          || sensoresDoTalhao[0];
        const sensorDoSolo = sensoresAtivos.find((item) => item.tipo === "umidadeSolo");
        const valorSolo = Number(sensorDoSolo?.valor);
        const leituraSoloValida = sensorDoSolo?.valor !== null
          && sensorDoSolo?.valor !== undefined
          && sensorDoSolo?.dados_recentes
          && Number.isFinite(valorSolo);
        const semSensor = sensoresDoTalhao.length === 0;
        const semSensorAtivo = !semSensor && sensoresAtivos.length === 0;
        const semComunicacao = sensoresAtivos.some((item) =>
          ["Offline", "Manutencao", "Desativado", "Sem comunicação"].includes(item.status)
        );
        const semLeitura = sensoresAtivos.length === 0
          || sensoresAtivos.every((item) => item.valor === null || item.valor === undefined);
        const temDadosRecentes = sensoresAtivos.some((item) => item.dados_recentes);
        const ultimaLeituraEm = sensoresDoTalhao
          .map((item) => item.ultima_leitura_em)
          .filter(Boolean)
          .sort((a, b) => Date.parse(b) - Date.parse(a))[0] || null;
        const critical = leituraSoloValida && valorSolo < 30;
        const attention = leituraSoloValida && valorSolo >= 30 && valorSolo < 40;
        const cycle = cicloAtivoPorTalhao.get(p.id);
        const cultivar = cycle && cultivarById.get(cycle.cultivar_id);
        const produto = cultivar ? cultureById.get(cultivar.cultura_id) : null;
        const culturaLabel = [produto, cultivar?.nome].filter(Boolean).join(" / ");
        return {
          id: p.codigo,
          cultura: culturaLabel || "Sem plantio ativo",
          area: `${p.area_hectares} hectares`,
          sensor: s?.sensor,
          leitura: s?.leitura || "Sem leitura",
          dados_recentes: temDadosRecentes,
          ultima_leitura_em: ultimaLeituraEm,
          situacao: semSensor ? "Sem sensor"
            : semSensorAtivo ? "Sensor inativo"
              : semComunicacao ? "Sem comunicação"
                : critical ? "Critico"
                  : semLeitura ? "Sem leitura"
                    : !temDadosRecentes ? "Dados desatualizados"
                      : attention ? "Atencao"
                        : "Normal",
          prioridade: semSensor ? "Cadastre um sensor para habilitar o monitoramento"
            : semSensorAtivo ? "Ative um sensor para habilitar o monitoramento"
              : semComunicacao ? "Verifique a comunicação do sensor"
                : critical ? "Umidade do solo abaixo de 30%"
                  : semLeitura ? "Aguardando leitura de sensor"
                    : !temDadosRecentes ? "Última leitura há mais de 5 minutos"
                      : attention ? "Verifique a umidade do solo"
                        : "Rotina de acompanhamento"
        };
      });

      return reply(
        res,
        200,
        {
          talhoes,
          sensores: sensorRows,
          inspecoes: inspections.map((i) => ({
            id: i.id,
            data: i.inspecionado_em?.slice(0, 10),
            criado_em: i.criado_em,
            talhao: plots.find((p) => p.id === i.talhao_id)?.codigo,
            situacao: i.status ? i.status[0].toUpperCase() + i.status.slice(1) : "Normal",
            problemas: i.descricao_problema,
            observacoes: i.observacoes,
            sensor_id: i.sensor_id || null,
            sensor: sensors.find((s) => s.id === i.sensor_id)?.id_externo || null,
            tecnico: autorById.get(i.usuario_id) || null
          })),
          plantios: cycles.map((cycle) => {
            const cultivar = cultivarById.get(cycle.cultivar_id);
            return {
              ...cycle,
              talhao: plots.find((plot) => plot.id === cycle.talhao_id)?.codigo,
              produto: cultivar ? cultureById.get(cultivar.cultura_id) : "",
              variedade: cultivar?.nome || ""
            };
          }),
          ocorrencias: occurrences.map((o) => ({
            id: o.id,
            data: o.registrado_em?.slice(0, 10),
            criado_em: o.criado_em,
            talhao: plots.find((p) => p.id === o.talhao_id)?.codigo,
            tipo: o.tipo,
            observacao: o.observacao
          })),
          problemasSensores: sensorProblems.map((problem) => ({
            id: problem.id,
            data: problem.data,
            talhao: plots.find((p) => p.id === problem.talhao_id)?.codigo,
            sensor: sensors.find((s) => s.id === problem.sensor_id)?.id_externo,
            problema: problem.problema,
            observacao: problem.observacao
          })),
          tarefas: talhoes
            .filter((p) => p.situacao !== "Normal")
            .map((p) => ({
              talhao: p.id,
              prioridade: p.situacao === "Critico" ? "Critica" : "Atencao",
              atividade: p.prioridade
            })),
          alertas: alerts
        },
        origin
      );
    }

    if (req.method === "POST" && route === "/plantios/encerrar-ciclo") {
      if (!["engenheiro", "admin"].includes(user.perfil)) {
        return reply(res, 403, { mensagem: "Somente Engenharia e Administração podem encerrar ciclos." }, origin);
      }
      const d = await parseBody(req);
      const codigoTalhao = text(d.talhao, 40);
      if (!codigoTalhao) return reply(res, 400, { mensagem: "Selecione um talhão." }, origin);

      const plot = (await db(c, "talhao", "GET", undefined, `?codigo=eq.${encodeURIComponent(codigoTalhao)}&arquivado_em=is.null&select=id&limit=1`))[0];
      if (!plot) return reply(res, 404, { mensagem: "Talhão não encontrado." }, origin);
      const ciclo = (await db(
        c,
        "ciclo_cultura",
        "GET",
        undefined,
        `?talhao_id=eq.${encodeURIComponent(plot.id)}&status=eq.ativo&select=id&order=plantado_em.desc&limit=1`
      ))[0];
      if (!ciclo) return reply(res, 409, { mensagem: "Este talhão não possui ciclo ativo para encerrar." }, origin);
      if (d.cicloId && d.cicloId !== ciclo.id) {
        return reply(res, 409, { mensagem: "O ciclo ativo deste talhão mudou. Atualize a página e confira os dados antes de encerrar." }, origin);
      }

      const encerradoEm = date(d.encerradoEm) || new Date().toISOString().slice(0, 10);
      await db(c, "ciclo_cultura", "PATCH", { status: "encerrado", encerrado_em: encerradoEm }, `?id=eq.${encodeURIComponent(ciclo.id)}`);
      return reply(res, 200, { sucesso: true, talhao: codigoTalhao, encerradoEm }, origin);
    }

    // 12. Cadastro de Plantio (Engenheiro / Admin)
    if (req.method === "POST" && route === "/plantios") {
      if (!["engenheiro", "admin"].includes(user.perfil)) return reply(res, 403, { mensagem: "Sem permissão." }, origin);
      const d = await parseBody(req);
      if (
        !["produto", "variedade", "talhao", "solo"].every((k) => text(d[k])) ||
        !date(d.dataPlantio) ||
        !date(d.dataColheita)
      ) {
        return reply(res, 400, { mensagem: "Dados de plantio inválidos." }, origin);
      }

      const plot = (await db(c, "talhao", "GET", undefined, `?codigo=eq.${encodeURIComponent(d.talhao)}&arquivado_em=is.null&select=id,area_hectares&limit=1`))[0];
      if (!plot) return reply(res, 404, { mensagem: "Talhão não encontrado." }, origin);
      const areaPlantada = Number(plot.area_hectares);
      const temperaturaMaxima = Number(String(d.temperaturaMaxima ?? "").replace(",", "."));
      if (!Number.isFinite(temperaturaMaxima) || temperaturaMaxima < 0 || temperaturaMaxima > 100) {
        return reply(res, 400, { mensagem: "Informe uma temperatura máxima entre 0 e 100 C." }, origin);
      }
      if (!Number.isFinite(areaPlantada) || areaPlantada <= 0) {
        return reply(res, 409, { mensagem: "Defina uma área valida para o talhão antes de cadastrar o produto." }, origin);
      }

      const cicloAtivo = (await db(
        c,
        "ciclo_cultura",
        "GET",
        undefined,
        `?talhao_id=eq.${encodeURIComponent(plot.id)}&status=eq.ativo&select=id&limit=1`
      ))[0];
      if (cicloAtivo) {
        return reply(res, 409, { mensagem: "Este talhao possui um ciclo ativo. Encerre-o em Detalhes do Talhao antes de cadastrar outro produto." }, origin);
      }

      try {
        await db(c, "talhao", "PATCH", { temperatura_maxima: temperaturaMaxima }, `?id=eq.${encodeURIComponent(plot.id)}`);
      } catch (erro) {
        if (String(erro.message).includes("temperatura_maxima")) {
          return reply(res, 503, { mensagem: "Aplique a migration supabase/migration_temperatura_maxima_talhao.sql no banco para salvar o limite de temperatura." }, origin);
        }
        throw erro;
      }

      let cultura = (await db(c, "cultura", "GET", undefined, `?nome_comum=eq.${encodeURIComponent(d.produto)}&select=id&limit=1`))[0];
      if (!cultura) {
        const created = await db(c, "cultura", "POST", { nome_comum: text(d.produto) });
        cultura = Array.isArray(created) ? created[0] : created;
      }

      let cultivar = (
        await db(c, "cultivar", "GET", undefined, `?cultura_id=eq.${cultura.id}&nome=eq.${encodeURIComponent(d.variedade)}&select=id&limit=1`)
      )[0];
      if (!cultivar) {
        const created = await db(c, "cultivar", "POST", { cultura_id: cultura.id, nome: text(d.variedade) });
        cultivar = Array.isArray(created) ? created[0] : created;
      }

      await db(c, "ciclo_cultura", "POST", {
        talhao_id: plot.id,
        cultivar_id: cultivar.id,
        area_plantada_hectares: areaPlantada,
        solo: text(d.solo),
        plantado_em: d.dataPlantio,
        previsao_colheita: d.dataColheita,
        usuario_id: user.sub,
        status: "ativo"
      });
      return reply(res, 201, { sucesso: true }, origin);
    }

    // 13. Registros de Campo do Técnico (Inspeções, Ocorrências, Problemas em Sensores)
    if (req.method === "POST" && ["/inspecoes", "/ocorrencias", "/sensores/problemas"].includes(route)) {
      if (!["tecnico", "admin"].includes(user.perfil)) return reply(res, 403, { mensagem: "Sem permissão." }, origin);
      const d = await parseBody(req);

      if (route === "/inspecoes") {
        if (!text(d.talhao) || !date(d.data) || !["Normal", "Atencao", "Critico"].includes(d.situacao)) {
          return reply(res, 400, { mensagem: "Dados de inspeção inválidos." }, origin);
        }
        if (d.data > hojeNoBrasil()) {
          return reply(res, 400, { mensagem: "A data da inspeção não pode ser futura." }, origin);
        }
        const plot = (await db(c, "talhao", "GET", undefined, `?codigo=eq.${encodeURIComponent(d.talhao)}&arquivado_em=is.null&select=id&limit=1`))[0];
        if (!plot) return reply(res, 404, { mensagem: "Talhão não encontrado." }, origin);

        const sensorId = text(d.sensor_id, 80);
        let linkedSensorId = null;
        if (sensorId) {
          if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(sensorId)) {
            return reply(res, 400, { mensagem: "Identificador do sensor inválido." }, origin);
          }
          const sensor = (await db(
            c,
            "sensor",
            "GET",
            undefined,
            `?id=eq.${encodeURIComponent(sensorId)}&status=eq.ativo&select=id,dispositivo_id&limit=1`
          ))[0];
          if (!sensor) return reply(res, 404, { mensagem: "O sensor selecionado não está ativo ou não existe." }, origin);
          const device = (await db(
            c,
            "dispositivo",
            "GET",
            undefined,
            `?id=eq.${encodeURIComponent(sensor.dispositivo_id)}&select=talhao_id&limit=1`
          ))[0];
          if (!device || device.talhao_id !== plot.id) {
            return reply(res, 400, { mensagem: "O sensor selecionado não pertence ao talhão informado." }, origin);
          }
          linkedSensorId = sensor.id;
        }

        await db(c, "inspecao", "POST", {
          talhao_id: plot.id,
          usuario_id: user.sub,
          sensor_id: linkedSensorId,
          inspecionado_em: d.data,
          status: d.situacao.toLowerCase(),
          descricao_problema: text(d.problemas) || null,
          observacoes: text(d.observacoes) || null
        });
        return reply(res, 201, { sucesso: true }, origin);
      }

      if (route === "/ocorrencias") {
        if (!text(d.talhao) || !text(d.tipo)) {
          return reply(res, 400, { mensagem: "Dados de ocorrência inválidos." }, origin);
        }
        const plot = (await db(c, "talhao", "GET", undefined, `?codigo=eq.${encodeURIComponent(d.talhao)}&arquivado_em=is.null&select=id&limit=1`))[0];
        if (!plot) return reply(res, 404, { mensagem: "Talhão não encontrado." }, origin);

        await db(c, "rpc/registrar_ocorrencia_com_alerta", "POST", {
          p_talhao_id: plot.id,
          p_usuario_id: user.sub,
          p_talhao_codigo: text(d.talhao),
          p_tipo: text(d.tipo),
          p_observacao: text(d.observacao) || null
        });
        return reply(res, 201, { sucesso: true }, origin);
      }

      if (route === "/sensores/problemas") {
        if (!text(d.talhao) || !date(d.data) || !text(d.problema)) {
          return reply(res, 400, { mensagem: "Dados de problema de sensor inválidos." }, origin);
        }
        const plot = (await db(c, "talhao", "GET", undefined, `?codigo=eq.${encodeURIComponent(d.talhao)}&arquivado_em=is.null&select=id&limit=1`))[0];
        if (!plot) return reply(res, 404, { mensagem: "Talhão não encontrado." }, origin);

        const sensorCodigo = text(d.sensor, 80);
        let sensor = null;
        if (sensorCodigo) {
          sensor = (await db(c, "sensor", "GET", undefined, `?id_externo=eq.${encodeURIComponent(sensorCodigo)}&status=eq.ativo&select=id,dispositivo_id&limit=1`))[0];
          if (!sensor) return reply(res, 404, { mensagem: "Sensor não encontrado." }, origin);
          const device = (await db(c, "dispositivo", "GET", undefined, `?id=eq.${encodeURIComponent(sensor.dispositivo_id)}&select=talhao_id&limit=1`))[0];
          if (!device || device.talhao_id !== plot.id) {
            return reply(res, 400, { mensagem: "O sensor selecionado não pertence ao talhão informado." }, origin);
          }
        }
        await db(c, "rpc/registrar_problema_sensor_com_alerta", "POST", {
          p_sensor_id: sensor?.id || null,
          p_talhao_id: plot.id,
          p_usuario_id: user.sub,
          p_talhao_codigo: text(d.talhao),
          p_sensor_codigo: sensorCodigo || "não cadastrado",
          p_data: d.data,
          p_problema: text(d.problema),
          p_observacao: text(d.observacao) || null
        });
        return reply(res, 201, { sucesso: true }, origin);
      }
    }

    // 14. Gestão Administrativa de Funcionários (Admin)
    const employeeMatch = route.match(/^\/funcionarios\/([^/]+)$/);
    if (employeeMatch && ["PUT", "PATCH", "DELETE"].includes(req.method)) {
      if (user.perfil !== "admin") return reply(res, 403, { mensagem: "Sem permissão." }, origin);
      const employeeId = decodeURIComponent(employeeMatch[1]);
      if (employeeId === String(user.sub)) {
        return reply(res, 400, { mensagem: "Não e permitido alterar ou excluir o proprio usuário." }, origin);
      }
      const employee = (await db(
        c,
        "usuario",
        "GET",
        undefined,
        `?id=eq.${encodeURIComponent(employeeId)}&select=id,status,profissao&limit=1`
      ))[0];
      if (!employee) return reply(res, 404, { mensagem: "Funcionário não encontrado." }, origin);
      if (req.method === "PUT") {
        const d = await parseBody(req);
        const status = d.status === undefined ? employee.status : d.status;
        const profissao = d.profissao === undefined
          ? employee.profissao || ""
          : typeof d.profissao === "string" ? d.profissao.trim() : null;
        if (
          !text(d.nome) ||
          !text(d.cargo) ||
          profissao === null ||
          profissao.length > 160 ||
          !ROLES.includes(d.perfil) ||
          !["ativo", "inativo"].includes(status) ||
          (d.senha !== undefined && d.senha !== "" && (typeof d.senha !== "string" || d.senha.length < 8 || d.senha.length > 10))
        ) {
          return reply(res, 400, { mensagem: "Dados inválidos para atualizar funcionário." }, origin);
        }
        const updates = {
          nome_completo: text(d.nome),
          cargo: text(d.cargo),
          profissao,
          perfil: d.perfil === "admin" ? "administrador" : d.perfil,
          status
        };
        if (d.senha) {
          updates.senha_hash = hashPassword(d.senha);
          updates.senha_temporaria = true;
        }
        await db(c, `usuario?id=eq.${encodeURIComponent(employeeId)}`, "PATCH", updates);
        return reply(res, 200, { sucesso: true }, origin);
      }
      if (req.method === "PATCH") {
        const d = await parseBody(req);
        if (!["ativo", "inativo"].includes(d.status)) {
          return reply(res, 400, { mensagem: "Status de funcionário inválido." }, origin);
        }
        await db(c, `usuario?id=eq.${encodeURIComponent(employeeId)}`, "PATCH", { status: d.status });
        return reply(res, 200, { sucesso: true, status: d.status }, origin);
      }
      await db(c, `usuario?id=eq.${encodeURIComponent(employeeId)}`, "DELETE");
      return reply(res, 200, { sucesso: true }, origin);
    }

    if (["/funcionarios", "/admin/usuarios"].includes(route)) {
      if (req.method === "GET") {
        if (user.perfil !== "admin") return reply(res, 403, { mensagem: "Sem permissão." }, origin);
        const rows = await db(
          c,
          "usuario",
          "GET",
          undefined,
          "?select=id,matricula,nome_completo,perfil,cargo,profissao,status,criado_em&order=matricula"
        );
        return reply(
          res,
          200,
          {
            usuarios: rows.map((r) => ({
              id: r.id,
              matricula: r.matricula,
              nome: r.nome_completo,
              perfil: r.perfil === "administrador" ? "admin" : r.perfil,
              cargo: r.cargo,
              profissao: r.profissao || "",
              status: r.status,
              ativo: r.status === "ativo",
              created_at: r.criado_em
            }))
          },
          origin
        );
      }

      if (req.method === "POST") {
        if (user.perfil !== "admin") return reply(res, 403, { mensagem: "Sem permissão." }, origin);
        const d = await parseBody(req);
        const perfil = d.perfil === undefined ? "tecnico" : d.perfil;
        const status = d.status === undefined ? "ativo" : d.status;
        const profissao = d.profissao === undefined
          ? ""
          : typeof d.profissao === "string" ? d.profissao.trim() : null;
        if (
          !text(d.nome) ||
          !text(d.cargo) ||
          profissao === null ||
          profissao.length > 160 ||
          !ROLES.includes(perfil) ||
          !["ativo", "inativo"].includes(status)
        ) {
          return reply(res, 400, { mensagem: "Dados inválidos para cadastrar funcionário." }, origin);
        }
        if (typeof d.senha !== "string" || d.senha.length < 8 || d.senha.length > 10) {
          return reply(res, 400, { mensagem: "A senha temporária deve possuir entre 8 e 10 caracteres." }, origin);
        }

        const org = (await db(c, "organizacao", "GET", undefined, "?select=id&order=criado_em&limit=1"))[0];
        if (!org) return reply(res, 503, { mensagem: "Organizacao não configurada." }, origin);

        const matriculaResponse = await db(c, "rpc/proxima_matricula_funcionario", "POST", {});
        const matricula = typeof matriculaResponse === "string" ? matriculaResponse : matriculaResponse?.matricula;
        if (!text(matricula, 40)) {
          throw new Error("Falha ao gerar matrícula para o funcionário.");
        }

        const created = await db(c, "usuario", "POST", {
          organizacao_id: org.id,
          matricula,
          nome_completo: text(d.nome),
          cargo: text(d.cargo),
          profissao,
          perfil: perfil === "admin" ? "administrador" : perfil,
          status,
          senha_hash: hashPassword(d.senha),
          senha_temporaria: true
        });
        const employee = Array.isArray(created) ? created[0] : created;
        if (!employee?.id) {
          throw new Error("O banco não confirmou a gravacao do funcionário. Atualize o esquema e tente novamente.");
        }
        return reply(res, 201, { sucesso: true, matricula, id: employee?.id }, origin);
      }
    }

    const sensorMatch = route.match(/^\/sensores\/([^/]+)$/);
    if (sensorMatch && ["PATCH", "DELETE"].includes(req.method)) {
      if (user.perfil !== "admin") return reply(res, 403, { mensagem: "Sem permissão." }, origin);
      const sensorId = decodeURIComponent(sensorMatch[1]);
      const sensor = (await db(
        c,
        "sensor",
        "GET",
        undefined,
        `?id=eq.${encodeURIComponent(sensorId)}&select=id&limit=1`
      ))[0];
      if (!sensor) return reply(res, 404, { mensagem: "Sensor não encontrado." }, origin);
      if (req.method === "PATCH") {
        const d = await parseBody(req);
        if (!["ativo", "inativo"].includes(d.status)) {
          return reply(res, 400, { mensagem: "Status de sensor inválido." }, origin);
        }
        await db(c, `sensor?id=eq.${encodeURIComponent(sensorId)}`, "PATCH", { status: d.status });
        return reply(res, 200, { sucesso: true }, origin);
      }
      await db(c, `sensor?id=eq.${encodeURIComponent(sensorId)}`, "DELETE");
      return reply(res, 200, { sucesso: true }, origin);
    }

    if (req.method === "POST" && route === "/sensores") {
      if (user.perfil !== "admin") return reply(res, 403, { mensagem: "Sem permissão." }, origin);
      const d = await parseBody(req);
      const idExterno = text(d.sensor, 80);
      const codigoMetrica = d.tipo;
      const unidade = text(d.unidade, 20);
      const codigoTalhao = text(d.talhao, 40);
      if (!idExterno || !unidade || !codigoTalhao || !TYPES.includes(codigoMetrica)) {
        return reply(res, 400, { mensagem: "Dados inválidos para cadastro do sensor." }, origin);
      }

      const plot = (await db(
        c,
        "talhao",
        "GET",
        undefined,
        `?codigo=eq.${encodeURIComponent(codigoTalhao)}&arquivado_em=is.null&select=id&limit=1`
      ))[0];
      if (!plot) return reply(res, 404, { mensagem: "Talhão não encontrado." }, origin);

      const org = (await db(c, "organizacao", "GET", undefined, "?select=id&order=criado_em&limit=1"))[0];
      if (!org) return reply(res, 503, { mensagem: "Organizacao não configurada." }, origin);

      let device = (await db(
        c,
        "dispositivo",
        "GET",
        undefined,
        `?organizacao_id=eq.${encodeURIComponent(org.id)}&id_externo=eq.${encodeURIComponent(idExterno)}&select=id,talhao_id&limit=1`
      ))[0];
      if (device && device.talhao_id !== plot.id) {
        return reply(res, 409, { mensagem: "O identificador do dispositivo já está associado a outro talhão." }, origin);
      }
      if (!device) {
        const created = await db(c, "dispositivo", "POST", {
          organizacao_id: org.id,
          talhao_id: plot.id,
          id_externo: idExterno,
          status: "offline"
        });
        device = Array.isArray(created) ? created[0] : created;
      }

      const duplicate = (await db(
        c,
        "sensor",
        "GET",
        undefined,
        `?dispositivo_id=eq.${encodeURIComponent(device.id)}&id_externo=eq.${encodeURIComponent(idExterno)}&select=id&limit=1`
      ))[0];
      if (duplicate) return reply(res, 409, { mensagem: "Já existe um sensor com esse identificador." }, origin);

      const createdSensor = await db(c, "sensor", "POST", {
        dispositivo_id: device.id,
        id_externo: idExterno,
        codigo_metrica: codigoMetrica,
        unidade,
        status: "ativo"
      });
      const savedSensor = Array.isArray(createdSensor) ? createdSensor[0] : createdSensor;
      return reply(res, 201, { sucesso: true, sensor: savedSensor }, origin);
    }

    return reply(res, 404, { mensagem: "Rota não encontrada." }, origin);
  } catch (error) {
    console.error(`Erro ${req.method} ${route}:`, error.message);
    const isDbError = error.message.startsWith("Falha no banco de dados:");
    return reply(
      res,
      500,
      {
        mensagem: isDbError ? error.message : "Erro interno no servidor.",
        detalhes: process.env.NODE_ENV !== "production" ? error.message : undefined
      },
      origin
    );
  }
};
